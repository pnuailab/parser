
#pragma once

//wchar_t

#ifndef KLTAGGERMA_API
#ifdef KLTMA_EXPORTS
#		define KLTAGGERMA_API __declspec(dllexport)
#else
#		define KLTAGGERMA_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	KLTAGGERMA_API
#		define	KLTAGGERMA_API
#endif
//
//#ifdef	LINUX_PORTING
//#		include "../stdafx.h"
//#		include "../MacOSIncludes/mac_inc.h"
//#else
//#		include <Windows.h>
//#endif

#include "include/PnuNlp/PnuNlpAddon.h"
#include "include/PnuNlp/PnuNlpAddon.h"//"
#include "include/HString/HString.h"


class MorpFuncs
{
	PnuNlp* m_pPnuNlp; // ���¼� �м��� �ϱ� ���� �ʿ�
public:
	MorpFuncs(PnuNlp* _pnunlp) { m_pPnuNlp = _pnunlp; }

	int DeleteJosaEnding(const char* _szInput, char* result_str, char* josa);
	int DeleteJosaEnding(const char* _szInput, char* result_str, char* josa,PnuNlpMorpList& _ml);
	int DeleteJubSa(const char* _szInput,char* result_str,char* jubsa);
	int DeleteJubSa(const char* _szInput, char* result_str, char* jubsa, PnuNlpMorpList& _ml);


	int IsSep(PnuNlpMorpList& _ml,int _pos,int _offset);
	int GetMorpIndex(PnuNlpMorpList& _ml,int _pos,int _offset);
	void Compression(PnuNlpMorpResult& _mr);

	int IsJosaEnding(const char* _szInput,const char* josa); // ���� �Ǻ� (���ϰ� 1:����, 2:���) - �����
	int IsJosaEndingNew(	//const char* str,
						const char* josa); // ���� �Ǻ� (���ϰ� 1:����, 2:���, 3:����� ��� ���) - �����
//	int GetMaxLengthOfJosa(const char* str, int &isStartJong);
	int GetMaxLengthOfJosa(const HCHAR* _hchs, int &_isStartJong, int _numOfMaxLenOfTail=-1);
//	int GetMaxLengthOfEnding(const char* str, int &isStartJong);
	int GetMaxLengthOfEnding(const HCHAR* _hchs, int &_isStartJong, int _numOfMaxLenOfTail=-1);
};

static char Ex_Josa_Dic[100][20] = {
"�̶�",
};
static char Ex_Eomi_Dic[100][20] = {
"����",
};




