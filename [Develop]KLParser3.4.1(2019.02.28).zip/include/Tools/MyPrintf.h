
#ifndef MY_PRINTF_H
#define MY_PRINTF_H

#include <wchar.h>

//int write(int fd,char*buf,size_t len);

#define MYPRINTF_LENGTH 64
const char MYPRINTF_UDIGIT[17] = "0123456789ABCDEF";
const char MYPRINTF_LDIGIT[17] = "0123456789abcdef";

typedef struct{
	int fd;	
	char* pBuf;
	int bufSize;
	int len;	
	const char *digits;
}dataForMyprintf;

class myprintf
{	
	static void flush(dataForMyprintf &data) ;
	static inline void eputc(dataForMyprintf &data, int c) ;
	static inline void eputwc(dataForMyprintf &data, wint_t c) ;
	static void eputws(dataForMyprintf &data, wchar_t *s) ;
	static void eputs(dataForMyprintf &data, char *s) ;
	static char * uimaxtoa(dataForMyprintf &data, unsigned long n, int base);
	static char * pcvt(void *p) ;
	static char * tcvt(time_t t) ;
	
	static void myprintf2(int fd, char *buf, int bufsize, const char *fmt, va_list &ap) ;

public:	
	static void myprintf0(const char *fmt, ...) ;
	static void mysprintf1(char *buf, int bufsize, const char *fmt, ...) ;
	static void mysprintf1(va_list &ap, char *buf, int bufsize, const char *fmt) ;
	static void myfprintf1(int fd, const char *fmt, ...) ;	
	static void myfprintf1(va_list &ap, int fd, const char *fmt) ;	

};



#endif