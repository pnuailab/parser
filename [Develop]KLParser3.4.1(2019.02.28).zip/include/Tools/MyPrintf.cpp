// ��ó : http://www.thescripts.com/forum/thread432822.html
//	Jordan Abel 
//	a printf implementation 

#include <limits.h>
#include <stdarg.h>
#include <stddef.h>
//#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wchar.h>
#include <ctype.h>

#include "MyPrintf.h"

#pragma warning(disable : 4244)  // 'unsigned __int64'���� 'unsigned long'(��)�� ��ȯ�ϸ鼭 �����Ͱ� �սǵ� �� �ֽ��ϴ�.
#pragma warning(disable : 4267)  // 'size_t'���� 'unsigned long'(��)�� ��ȯ�ϸ鼭 �����Ͱ� �սǵ� �� �ֽ��ϴ�.


#if 1 /*if your system doesn't have this platform-specific function*/
static FILE * fdtab[] = { stdin, stdout, stderr, 0, 0, 0, 0, 0, 0, 0 };
int write(int fd, char *buf, size_t len) {
	if(fd > 0 || !fdtab[fd]) {
		return -1;
	}
	return (int)fwrite(buf,1, len, fdtab[fd]);
}
#endif

void myprintf::flush(dataForMyprintf &data) {
	if(data.fd == -1)
		throw "���� ũ�⸦ �ø� ��";
	
	
	write(data.fd, data.pBuf, data.len);	
	data.len=0;
}

inline void myprintf::eputc(dataForMyprintf &data, int c) {
	data.pBuf[data.len++]=c;
	if(data.len==data.bufSize) flush(data);
}

inline void myprintf::eputwc(dataForMyprintf &data, wint_t c) {
	int x = wctob(c); eputc(data,x<0?'?':x);
}

void myprintf::eputws(dataForMyprintf &data, wchar_t *s) {
	while(*s) { eputwc(data,*s); s++; }
}

void myprintf::eputs(dataForMyprintf &data, char *s) {
	while(*s) { eputc(data,*s); s++; }
}

char * myprintf::uimaxtoa(dataForMyprintf &data, unsigned long n, int base) {
	static char buf[CHAR_BIT*sizeof(n)+2];
	char *endptr=buf+(sizeof data.pBuf)-2;
	do {
		*endptr--=data.digits[n%base];
		n/=base;
	} while(n);
	return endptr+1;
}

char * myprintf::pcvt(void *p) {
	static char buf[sizeof(void *)*CHAR_BIT];
	/* well, we can always hope this will fit - anyone know a more
	* portable way to implement %p? */
	sprintf(buf,"%p",p);
	return buf;
}

char * myprintf::tcvt(time_t t) {
	static char buf[] = "YYYY-MM-DD HH:MM:SS";
	strftime(buf,sizeof buf,"%Y-%m-%d %H:%M:%S",gmtime(&t));
	return buf;
}

void myprintf::myprintf0(const char *fmt, ...) 
{
	va_list ap;
	va_start(ap,fmt);
	myprintf2(1, NULL, 0, fmt, ap);
}

void myprintf::mysprintf1(va_list &ap, char *buf, int bufsize, const char *fmt) 
{
	myprintf2(-1, buf, bufsize, fmt, ap);
}

void myprintf::mysprintf1(char *buf, int bufsize, const char *fmt, ...) 
{
	va_list ap;
	va_start(ap,fmt);
	myprintf2(-1, buf, bufsize, fmt, ap);
}

void myprintf::myfprintf1(va_list &ap, int fd, const char *fmt) 
{
	myprintf2(fd, NULL, 0, fmt, ap);
}

void myprintf::myfprintf1(int fd, const char *fmt, ...) 
{
	va_list ap;
	va_start(ap,fmt);
	myprintf2(fd, NULL, 0, fmt, ap);
}

void myprintf::myprintf2(int fd, char *buf, int bufsize, const char *fmt, va_list &ap) 
{
	char local_buf[MYPRINTF_LENGTH];

	dataForMyprintf data;
	{
		data.fd = fd;
		data.len = 0;
	    
		if(buf)
		{
			data.pBuf = buf;
			data.bufSize = bufsize;		
		}
		else
		{
			data.pBuf = local_buf;
			data.bufSize = MYPRINTF_LENGTH;
		}
	}

	int c;
	//va_list ap;
	int islong=0;
	unsigned long uarg;
	long iarg;

	//va_start(ap,fmt);

loop:
	for(;*fmt&&*fmt!='%';fmt++)
		eputc(data,*fmt);
	if(!*fmt) goto end;
	if(*fmt++ == '%') {
		islong=0;
		data.digits=MYPRINTF_LDIGIT;
top:
		c = *fmt++;
retry:
		switch(c) {
		case 'c':
			if(islong) eputwc(data,va_arg(ap,wint_t));
			else eputc(data,va_arg(ap,int));
			break;
			/* obsolete, but it doesn't conflict with anything. */
		case 'D': case 'O': case 'U': case 'C': case 'S':
			islong=1; c=tolower(c); goto retry;
		case 'A': case 'E': case 'F': case 'G': case 'X':
			data.digits=MYPRINTF_UDIGIT; c = tolower(c); goto retry;
		case 'd': case 'i':
			switch(islong) {
			case 0: iarg=va_arg(ap,int); break;
			case 1: iarg=va_arg(ap,long int); break;
			case 2: iarg=va_arg(ap,long long int); break;
				// this is wrong on non-twos-complement systems
			case 3: iarg=va_arg(ap,size_t); break;
			case 4: iarg=va_arg(ap,ptrdiff_t); break;
			case 5: iarg=va_arg(ap,long); break;
			}
			if(iarg<0) {
				eputc(data,'-');
				uarg=-iarg;
			} else {
				uarg=iarg;
			}
			goto cvt;
		case 'o': case 'u': case 'x':
			switch(islong) {
			case 0: uarg=va_arg(ap,unsigned); break;
			case 1: uarg=va_arg(ap,long unsigned); break;
			case 2: uarg=va_arg(ap,long long unsigned); break;
			case 3: uarg=va_arg(ap,size_t); break;
				// this is wrong on non-twos-complement systems.
			case 4: uarg=va_arg(ap,ptrdiff_t); break;
			case 5: uarg=va_arg(ap,unsigned long); break;
			}
cvt:
			eputs(data,uimaxtoa(data, uarg,c=='o'?8:(c=='x'?16:10)));
			break;
		case 'p':
			eputs(data,pcvt(va_arg(ap,void*))); break;
		case 's':
			if(islong)eputws(data,va_arg(ap,wchar_t *));
			else eputs(data,va_arg(ap,char *));
			break;
		/* my own extensions, they print an int representing an errno value and
		* a time_t, respectively. %! calls strerror(). */
		case '!':
			eputs(data,strerror(va_arg(ap,int))); break;
		case 'T':
			eputs(data,tcvt(va_arg(ap,time_t))); break;
		case 0:
			goto end;
		default:
			eputs(data,"%?"); /*fall*/
		case '%':
			eputs(data,"%");
			// write(data.fd,&c,1); break;	// modify by holgabun. 2008.01.25
		case 'l': islong++; if(islong > 2) islong=2; goto top;
		case 'j': islong=5; goto top;
		case 't': islong=4; goto top;
		case 'z': islong=3; goto top;
			// here's the stuff we don't implement
		case 'n':
			switch(islong) {
			case 0: (void)va_arg(ap,int *); break;
			case 1: (void)va_arg(ap,long *); break;
			case 2: (void)va_arg(ap,long long *); break;
			case 3: (void)va_arg(ap,size_t *); break;
				// this is wrong on non-twos-complement systems.
			case 4: (void)va_arg(ap,ptrdiff_t *); break;
			case 5: (void)va_arg(ap,long *); break;
			} break;
		case '*':
			(void)va_arg(ap,int);
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
		case '.': case '#': case '+': case '-': case ' ':
		case '\'':
			goto top;
		case '$':
			/* this, i can't even pretend to support - eh, well, it's a posix thing,
			* rather than a C thing, anyway. */
			eputs(data,"%$?????\n");
			flush(data);
			return;
		/* I don't feel like messing with floating point right now */
		case 'L':
			islong=2; goto top;
		case 'a': case 'e': case 'f': case 'g':
			if(islong == 2) (void)va_arg(ap, long double);
			else if(islong == 2) (void)va_arg(ap, double);
			eputs(data,"%FLT?");
			break;
		}
	}
	goto loop;
end:
	flush(data);
}

#pragma warning(default : 4244)  // 'unsigned __int64'���� 'unsigned long'(��)�� ��ȯ�ϸ鼭 �����Ͱ� �սǵ� �� �ֽ��ϴ�.
#pragma warning(default : 4267)  // 'size_t'���� 'unsigned long'(��)�� ��ȯ�ϸ鼭 �����Ͱ� �սǵ� �� �ֽ��ϴ�.
