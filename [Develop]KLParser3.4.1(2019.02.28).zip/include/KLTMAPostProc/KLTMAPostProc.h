// MAPostProc.h : KLTMAPostProc DLL�� �⺻ ��� �����Դϴ�.
//


#pragma once

#ifndef KLTAGGERMA_POSTPROC_API
#ifdef MA_POSTPROC_EXPORTS
#		define KLTAGGERMA_POSTPROC_API __declspec(dllexport)
#else
#		define KLTAGGERMA_POSTPROC_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	KLTAGGERMA_POSTPROC_API
#		define	KLTAGGERMA_POSTPROC_API
#endif

#include "include/KLTTypeMng/TagString.h"
#include "include/KLTMA/KLTMA.h"
#include "include/PnuNlp/PnuNlpAddon.h"


class KLTAGGERMA_POSTPROC_API KLTMAPostProc
{
	void* m_pMAPostProc;	
public:
	string m_strExceptionMsg;
public:
	KLTMAPostProc(PnuNlp *_pPnuNlp, KLTMA* _pKMA, const TaggingOption* _pOpt=NULL);
	~KLTMAPostProc();
	void SetOption(const TaggingOption* _pOpt);
	void DoMAPostProc(TagString* _pTokenString, int _idxOfStartToken, const TaggingOption* _pOpt);
	void DoMAPostProc(int _idxOfStartToken);	
	static void DoSplitNounAffix(MAList &malist, KLTMA &_KMA);
	static void DoSplitNounAffix(Token &token, KLTMA &_KMA);
};



 