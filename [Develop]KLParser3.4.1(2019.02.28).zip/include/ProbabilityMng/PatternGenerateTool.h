
#pragma once

#include "include/KLTTypeMng/TagString.h"
#include "ProbabilityDef.h"

class PatternGenerate
{
public:
	static void SetCore(const MAList& sourceMA0, const MAList& sourceMA1, tMAListArray &result_tMAListArray, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng, COUNTING_MODE mode);
	static int SetTypicalRoot( const MAList& sourceMA1, tMAListArray &result_tMAListArray, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng);
	//static void AddMorpFor_D_FTP_VER0(const MAList& sourceMA0, const MAList& sourceMA1, tMAListArray &result_tMAListArray, TagPOSMng &tagPOSMng, int idxOfTypicalMorp);
	static void AddMorpFor_D_FTP_VER1( const MAList& sourceMA1, tMAListArray &result_tMAListArray, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng, int idxOfTypicalMorp);
	static void AddMorpFor_D_FTP_VER2( const MAList& sourceMA1, tMAListArray &result_tMAListArray, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng);
	static void AddMorpFor_D_FTP_VER3( const MAList& sourceMA1, tMAListArray &result_tMAListArray, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng);
	static void AddMorpFor_D_FTP_VER4( const MAList& sourceMA1, tMAListArray &result_tMAListArray, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng, bool bPOSEx);

	static void AddMorpFor_D_FTP_VER1( const MAList& sourceMA1, tMAList &result_tMAList, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng, int idxOfTypicalMorp);
	static void AddMorpFor_D_FTP_VER3( const MAList& sourceMA1, tMAList &result_tMAList, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng);
	static void AddMorpFor_D_FTP_VER4( const MAList& sourceMA1, tMAList &result_tMAList, TagPOSMng &tagPOSMng, const TagPOSMergingMng &mergingMng, bool bPOSEx);
};
