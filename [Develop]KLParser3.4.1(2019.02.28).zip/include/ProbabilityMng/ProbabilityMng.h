
#pragma once

#ifndef PROBABILITYMNG_API 
#ifdef PROBMNG_EXPORTS
#		define PROBABILITYMNG_API __declspec(dllexport)
#else
#		define PROBABILITYMNG_API __declspec(dllimport)
//#		define PROBABILITYMNG_EXPIMP_TEMPLATE extern
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	PROBABILITYMNG_API
#		define	PROBABILITYMNG_API
#endif

#include "include/KLTTypeMng/TagString.h"
#include <include/KLTTypeMng/TagTypeDefs.h>
#include <map>
using namespace std;

class PROBABILITYMNG_API ProbabilityMng
{
	//map<string, map<string, float>> mUnigramDic;
	map<string, map<string, float> > mUnigramDic;
	TagPOSMng *mTagPOSMng;
public:
	ProbabilityMng(string rootDicPath, TagPOSMng *tagPOSMng);
	~ProbabilityMng();
	
	int LoadUnigramDic(string dicPath);
	void GetUnigramProb(Token *token);
};