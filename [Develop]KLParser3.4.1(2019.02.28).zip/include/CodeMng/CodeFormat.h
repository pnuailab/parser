#pragma once




class CodeFormat
{
public:
	static void FilteringStr(unsigned char tmp_buf[], char buf[]);
	static void Hex2Johap(char Hex[],unsigned char Dec[]);
	static void Hex2Wan(unsigned char hex[],unsigned char wan[]);
	static void Oct2Wan(unsigned char oct[],unsigned char wan[]);
	static void Wan2Oct(unsigned char wan[],unsigned char oct[]);
	static void Wan2Hex(unsigned char wan[],unsigned char hex[]);
	static void Oct2Johap(unsigned char oct[],unsigned char Dec[]);
	static void Ten2Hex(int num,unsigned char H_buf[]);
	static char conv_char(int n);
};

