// GlobalMemory.cpp: implementation of the GlobalMemory class.
//
//////////////////////////////////////////////////////////////////////

//#include "stdafx.h"
#include "StdMemory.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>


//////////////////////////////////////////////////////////////////////////
//	class StdMemory  
//////////////////////////////////////////////////////////////////////////

StdMemory::StdMemory():m_pMemory(NULL), m_nDataSize(0), m_nAllocSize(0)
{
}

StdMemory::~StdMemory()
{
	FreeAll();
}

void* StdMemory::LoadFromFile(const char* _szFileName)
{
	if(_szFileName==NULL)	return NULL;
	//assert(_szFileName);

	FILE* fp;


	// fopen
	fp = fopen(_szFileName, "rb");
	if(fp==NULL)
	{
		fprintf(stderr, "file open fail:%s\n", _szFileName);
		return NULL;
	}

	// file size
	fseek(fp, 0, SEEK_END);
	m_nDataSize = ftell(fp);
	if(m_nDataSize==0)	return NULL;

	// malloc
	if(m_nDataSize>m_nAllocSize)
	{
		m_nAllocSize = m_nDataSize;
		if(m_pMemory)	free(m_pMemory);
		m_pMemory = malloc(m_nAllocSize+1);
	}

	// fread
	fseek(fp, 0, SEEK_SET);
	fread(m_pMemory, 0x01, m_nDataSize, fp);
	((char*)m_pMemory)[m_nDataSize] = 0;	// �ؽ�Ʈ ������ ����

	// fclose
	fclose(fp);

	return m_pMemory;
}

int	StdMemory::CopyToFile(const char* _szFileName)
{
	assert(_szFileName);

	FILE* fp;


	// fopen
	fp = fopen(_szFileName, "wb");
	if(fp==NULL)
	{
		fprintf(stderr, "file open fail:%s\n", _szFileName);
		return NULL;
	}

	// fwrite
	fwrite(m_pMemory, 0x01, m_nDataSize, fp);

	// fclose
	fclose(fp);

	return 1;
}

int	StdMemory::FreeAll()
{
	if(m_pMemory)	free(m_pMemory);
	m_pMemory = NULL;
	m_nDataSize = 0;
	m_nAllocSize = 0;
	return 1;
}

