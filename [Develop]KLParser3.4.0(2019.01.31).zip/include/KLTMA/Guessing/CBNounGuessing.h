
#pragma once

#ifndef KLTAGGERMA_API
#ifdef KLTMA_EXPORTS
#		define KLTAGGERMA_API __declspec(dllexport)
#else
#		define KLTAGGERMA_API __declspec(dllimport)
#endif
#endif


#ifdef	LINUX_PORTING
#		undef	KLTAGGERMA_API
#		define	KLTAGGERMA_API
#endif
//
//#ifdef	LINUX_PORTING
//#		include "../stdafx.h"
//#		include "../MacOSIncludes/mac_inc.h"
//#else
//#		include <Windows.h>
//#endif

#include "include/KLTTypeMng/TagTypeDefs.h"
#include "include/KLTTypeMng/TagString.h"
#include "CBNounGuessing.h"
//#include <vector>

//using namespace std;
class Token;
//class Tokenizer;
class HCHAR;

//////////////////////////////////////////////////////////////////////////
//	class CBNounGuessing
//////////////////////////////////////////////////////////////////////////
#define CBNG CBNounGuessing

class KLTAGGERMA_API CBNounGuessing
{
	
	Token *m_pCurrToken;
	const char* m_szSource;
	int m_numOfBytes;
	const Token *m_pPrevToken;
	const Token *m_pNextToken;
	static const char* m_szDicPath;
	
public:
	CBNounGuessing(Token &_currToken, const char* _szSource, int _numOfBytes=-1, const Token *_pPrevToken=NULL, const Token *_pNextToken=NULL);
	void DoGuessing();
	static void SetDicPath(const char *_szDicPath){m_szDicPath = _szDicPath;}

	bool GuessPersonName();
	bool GuessPlaceName();
	bool GuessPlaceNameByPlaceName();
	bool GuessPlaceNameByBackNoun();
	bool GuessPlaceNameByFrontNoun();
	bool GuessPlaceNameByPostfix();
	bool GuessPlaceNameByPrefix();
	bool GuessMechineName();  
};

void DoCBNounGuessing(Token &_currToken, const HCHAR* _hszSource, int _numOfHChar=-1, const Token *_pPrevToken=NULL, const Token *_pNextToken=NULL);
void DoCBNounGuessing(Token &_currToken, const char* _szSource, int _numOfBytes=-1, const Token *_pPrevToken=NULL, const Token *_pNextToken=NULL);


