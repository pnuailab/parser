#pragma once

#define HString HString_KLT	// ���������� libPnuNlp.so���� HCHAR�� �ҷ� �� ��, �°��� HCHAR�� �ҷ��Ἥ ������ ����. �� ���� �ذ��� ���� ��Ī�� ������


#ifndef HSTRING_LIB_API
#ifdef HSTRING_LIB_EXPORTS
#		define HSTRING_LIB_API __declspec(dllexport)
#else
#		define HSTRING_LIB_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	HSTRING_LIB_API
#		define	HSTRING_LIB_API
#endif


#include "HCHAR.h"




class HSTRING_LIB_API HString
{
private:
	int ConvertToHString(const char *strWord, HCHAR *hsWord);

public:
	int m_nLength;
	int m_nBufferLength;
	HCHAR* m_phsData;

	HString(void);
	HString(const wchar_t* wcsUnicode, bool bToJongSung=false);
	HString(const char* pstrInput, bool bToJohap=false, bool bToJongSung=false);
	HString(const HString& hsInput);
	HString(const HCHAR* hsInput);
	HString(DWORD nHelpNum, const char* pstrInput);	//���򸻰� ����� ��ġ� ���յ� ���¸� ����� ���ؼ� - saebi
	~HString(void);


	void SetString(const wchar_t* wcsUnicode, bool bToJongSung=false);
	void SetString(const char* pstrInput,bool bToJohap=false,bool bToJongSung=false);
	void SetString(const HString& phsInput);
	void SetString(const HCHAR* hsInput, int _startPos=0, int _len=-1);
	void SetStringPos(const HString& phsInput,int posStart);
	void SetStringPosLen(const HString& phsInput,int posStart,int Len);

	int IsJohabHangul() const;
	int IsJohabHanja() const;
	int IsOnlyBlank() const;
	int IsBlankExist() const;
	int IsPnuWord() const;

	long ToLong() const;
	int CountHcharData( WORD nSearchData ) const;
	int ReplaceHcharData( WORD nSearchData, WORD nReplaceData );
	void ReplacePosLen( int posStart, int nLength, const HString& hsReplace);
	void RemoveDoubleHCHAR( DWORD hcData );
	void Trim();
	void Reverse();
	void MakeBuffer(int nNewSize);
	void MakeNullString();
	void InsertNull(int posNull);
	char* ConvertToString(char* pstrOutput=NULL, bool convertToWansung=false) const;
	void ConvertToWString(wchar_t* pwcsOutput) const;
	int Compare(const HString& phsCompare ) const;
	int CompareLenJong
	(
		const HString& phsCompare,
		int nCompareLen,
		int bOnlyStartJong,
		int bRemoveEndJong
	) const;
	int CompareLen(const HString& phsCompare, int nCompareLen) const;
	int CompareLenReverse(const HString& hsCompare, int nCompareLen) const;
	int Compare(const char* phsCompare ) const;
	int CompareLen(const char* phsCompare, int nCompareLen ) const;
	int CompareLenReverse(const char* phsCompare, int nCompareLen) const;

	void PrintString(std::ostream& os_input) const;
	void PrintString
	(
		std::ostream& os_input,
		int posStart,
		int bRemoveStartJong,
		int nLen,
		int bRemoveEndJong,
		int bConv
	) const;

	void CopyString
	(
		HString& hsDestine,
		int posStart,
		int bRemoveStartJong,
		int nLen,
		int bRemoveEndJong
	) const;


	void Init();
	void ToLower();
	void ToJongsung();
	void ToJongsungFirstOnly();
	void ToPrintJongsung();
	void AddHchar(HCHAR hcInput);
	void AddHcharData(WORD UINT16Value);
	void Append(const HString& phsAppend );
	void AppendPosLen(const HString& hsAppend, int nPos, int nLen );

	void GetSpacingEncodeHCHAR( int posOffset, HCHAR* hcLeft, HCHAR* hcRight ) const;
	int SearchHcharData( DWORD hcSearchData ) const;
	const HCHAR* SearchHString( const HString& hsSearch ) const;

 	bool operator==(const HString& phsCompare ) const;
 	bool operator>(const HString& phsCompare ) const;
	bool operator<(const HString& phsCompare ) const;
	HString& operator=(const HString& phsSource );
	HString& operator=(const char* pstrSource );

 	friend std::ostream& operator<<( std::ostream& os_input , const HString& hsString);
	const HCHAR& operator[](int nIndex ) const;
	HCHAR& operator[](int nIndex ) ;
};


