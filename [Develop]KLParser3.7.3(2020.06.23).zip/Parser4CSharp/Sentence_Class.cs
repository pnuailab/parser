﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parser4CSharp
{
    class Sentence_Class
    {
        //멤버 변수
        String sentence = "";
        

        //List<Rank_Class> rc;  // 필드가 사용되지 않았습니다. : 주석처리 : 2016.10.16. 류재민
        List<String> rank;


        List<List<Morpheme_Relation>> Parse_Tree;

        List<List<String>> sentence_information;
        List<int> POS_information;


        //입력 받은 문장 정보 저장
        public List<List<Morpheme_Relation>> input(String _szSetence)
        {          

            sentence = _szSetence; //문장 저장                      

            Parse_Tree = new List<List<Morpheme_Relation>>();

            
            //하나의 Parse Tree Rank정보를 모두 저장
            rank = new List<string>();

            Rank_Class rc = new Rank_Class();
            sentence_information = new List<List<string>>();
            POS_information = new List<int>();
            
            // 2016.09.23.
            int Relation_information = 0;
            int Particle_information = 0;

            RegistryKey key = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\BCD_Parser");            
            for (int i = 0; i < key.SubKeyCount; i++)
            {
                RegistryKey sub_key = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\BCD_Parser").OpenSubKey(i.ToString());
                rank.Add("ROOT");
                for (int j = 1; j <= sub_key.ValueCount; j++)
                {
                    rank.Add(sub_key.GetValue(j.ToString()).ToString());
                }//Rank 하나의 어절 정보들 전부 저장
                
                if (rank.Count > 0)
                {
                    sentence_information.Add(Word_infromation(rank));//형태소 정보 저장

                    POS_information.Add(rc.POS_weight(rank));
                    Relation_information = rc.Relation_weight(rank);
                    //2019.01.11
                    Particle_information = rc.Particle_weight(rank);
                    Parse_Tree.Add(rc.Rank(rank));
                    rank.Clear();
                }
                Parse_Tree[i][0].POS_Weight = POS_information[i];
                Parse_Tree[i][0].rule_Weight = Relation_information;
                //2019.01.12
                Parse_Tree[i][0].weight = Particle_information;
            }        
            return Parse_Tree;         

        }//end input



        public List<List<Morpheme_Relation>> corpus_input(String _szSetence,String path)
        {

            sentence = _szSetence; //문장 저장                      
            String line = "";

            Parse_Tree = new List<List<Morpheme_Relation>>();            

            //하나의 Parse Tree Rank정보를 모두 저장
            rank = new List<string>();

            Rank_Class rc = new Rank_Class();
        
            System.IO.StreamReader file = new System.IO.StreamReader(path, System.Text.Encoding.Default);

            //한 문장의 문서 파일에 대한 While문
            while ((line = file.ReadLine()) != null)
            {
                rank.Clear();
                if (line.Contains("ROOT-ROOT"))
                {
                    
                    rank.Add(line);                  
                    while ((line = file.ReadLine()) != null && !line.Equals(""))
                    {
                        rank.Add(line);
                    }
                }//Rank 하나의 어절 정보들 전부 저장

                //하나의 Rank 정보를 전달
                if (rank.Count > 0)
                {
                    Parse_Tree.Add(rc.Corpus_Rank(rank));
                    rank.Clear();
                }

            }//end whild

            

            return Parse_Tree;

        }//end input



        public List<string> Word_infromation(List<string> value)
        {
            List<String> Morpheme_information = new List<string>();
            for (int i = value.Count()-1; i >= 0; i--)
            {
                String[] str = value[i].Split('#');
                if (!str[0].Equals("ROOT"))
                {
                    String word = str[1] + "#" + str[2];
                    Morpheme_information.Add(word);
                }
            }

            return Morpheme_information;

        }




        //getting
        public List<List<String>> get_sentence_information()
        {
            return sentence_information;
        }

        public List<int> get_POS_information()
        {
            return POS_information;
        }

    }
}
