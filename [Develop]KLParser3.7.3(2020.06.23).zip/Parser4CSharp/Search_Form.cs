﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Parser4CSharp
{
    public partial class Search_Form : Form
    {
        // Global Variable
        main_form mf;
        List<List<Morpheme_Relation>> Parse_Tree;

        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @brif : Initialize (초기화)
         */
        public Search_Form(main_form _MainForm)
        {
            InitializeComponent();

            mf = _MainForm;

            // item 추가
            AddListItem();

            // Rank view 초기화
            Init_SearchGridView();

            // PT view 초기화
            SearchPTView.Nodes.Clear();
        }



        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @brif : Combobox에 item 넣기
         */
        public void AddListItem()
        {
            // 의존소, 지배소 초기화
            DepInfo.Items.Clear();
            GovInfo.Items.Clear();

            // 레지스트리 접근
            RegistryKey key = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\BCD_Parser");

            // 레지스트리 읽기
            String savedMorph = key.GetValue("Morph", "").ToString();

            // 형태소 할당
            List<String> morphList = new List<String>();
            String[] bucket = savedMorph.Split('#');

            // Combobox에 item 추가
            for (int i = 0; i < bucket.Count() - 1; i++)
            {
                DepInfo.Items.Add(bucket[i]);
                GovInfo.Items.Add(bucket[i]);
            }
        }



        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @brif : [검색]버튼 눌렀을 때 Event
         */
        private void Search_SearchButton_Click(object sender, EventArgs e)
        {
            // 초기화
            SearchGridView.Rows.Clear();
            SearchPTView.Nodes.Clear();

            String strDep, strGov;

            strDep = "";
            strGov = "";

            // 의존소, 지배소 항목 선택
            try
            {
                strDep = DepInfo.SelectedItem.ToString();
                strGov = GovInfo.SelectedItem.ToString();

                // 선택된 Item에 대해 전처리 수행
                strDep = preprocessing(strDep);
                strGov = preprocessing(strGov);

                String[] infoDep = strDep.Split('\t');
                String[] infoGov = strGov.Split('\t');

                Search(infoDep, infoGov);
            }

            catch
            {
                label_SearchResult.Text = "검색결과 : 0개";
                System.Windows.Forms.MessageBox.Show("해당 조건의 파스트리 없음", "검색 결과", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }



        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @caller : Search_SearchButton_Click()
         * @brif : 선택된 Item에 대해 전처리를 수행한다.
         */
        private String preprocessing(String strTarget)
        {
            if (strTarget.Equals("((+이다))(지정사)"))
            {
                strTarget = "((+이다))\t지정사";
            }

            else
            {
                // 전처리 : 닫는괄호
                if (!strTarget.Contains("닫는괄호"))
                {
                    strTarget = strTarget.Replace(")", "");
                }
                else
                {
                    strTarget = strTarget.Replace("닫는괄호)", "닫는괄호");
                }

                // 전처리 : 여는괄호
                if (!strTarget.Contains("여는괄호"))
                {
                    strTarget = strTarget.Replace("(", "\t");
                }
                else
                {
                    strTarget = strTarget.Replace("(여", "\t여");
                }
            }
            return strTarget;
        }



        /**
         * @date : 2016.12.06.
         * @author : 류재민
         * @caller : Search_SearchButton_Click()
         * @brif : 검색을 수행한다.
         */
        public void Search(String[] infoDep, String[] infoGov)
        {
            Parse_Tree = mf.getParse_Tree();
            int numOfSearchResult = 0;

            int first = -1;
            // Search 수행
            for (int i = 0; i < Parse_Tree.Count; i++)
            {
                int rank_num = i + 1;
                for (int j = 0; j < Parse_Tree[i].Count; j++)
                {
                    //if (Parse_Tree[i][j].dependency_word.Contains(infoDep[0])
                    //    && Parse_Tree[i][j].dependency_POS.Contains(infoDep[1]))
                    if (Parse_Tree[i][j].dependency_word.Equals(infoDep[0])
                        && Parse_Tree[i][j].dependency_POS.Equals(infoDep[1]))
                    {
                        if (Parse_Tree[i][j].gover_word.Equals(infoGov[0])
                            && Parse_Tree[i][j].gover_POS.Equals(infoGov[1]))
                        //if (Parse_Tree[i][j].gover_word.Contains(infoGov[0])
                        //    && Parse_Tree[i][j].gover_POS.Contains(infoGov[1]))
                        {
                            // 해당 조건에 맞는 트리만 추가
                            string[] searchRow = new string[] { "[Rank " + rank_num.ToString() + "]" };
                            SearchGridView.Rows.Add(searchRow);
                            if (first < 0) first = i;
                            numOfSearchResult++;
                            break;
                        }
                    }
                }   // end j
            }   // end i

            if (first < 0)
            {
                label_SearchResult.Text = "검색결과 : 0개";
                System.Windows.Forms.MessageBox.Show("해당 조건의 파스트리 없음", "검색 결과", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                label_SearchResult.Text = "검색결과 : " + numOfSearchResult + "개";
                ShowPTInSearch(first);
            }
        }



        /**
         * @date : 2016.12.06.
         * @author : 류재민
         * @caller : Search_Form();
         * @brif : SearchGridView를 초기화 한다.
         */
         public void Init_SearchGridView()
        {
            SearchGridView.ColumnCount = 3;
            SearchGridView.Columns[0].Name = "Parse Tree";
            SearchGridView.Columns[0].Width = 160;
            SearchGridView.Columns[0].Frozen = true;
            SearchGridView.ColumnHeadersDefaultCellStyle.Font = new Font("맑은고딕", 10);

            //cell 가운데 정렬
            this.SearchGridView.Columns[0].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            SearchGridView.AutoGenerateColumns = true;
            SearchGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Font 설정
            SearchGridView.Columns[0].DefaultCellStyle.Font = new Font("맑은고딕", 11);

            //옵션
            SearchGridView.AllowUserToAddRows = false;
            SearchGridView.AllowUserToDeleteRows = false;
            SearchGridView.ReadOnly = true;
            SearchGridView.MultiSelect = false;
            SearchGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        }



        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @brif : 해당 랭크의 파스트리 출력
         */
        private void ShowPTInSearch(int _rank)
        {
            int Rank_Number = _rank;

            SearchPTView.Nodes.Clear();
            
            if(Rank_Number > -1)
            {
                SearchPTView.Nodes.Add(Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_position,
                    Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_word);

                //Tree 모양 출력
                for (int i = Parse_Tree[Rank_Number].Count - 1; i >= 0; i--)    //dependency loop
                {
                    //Root-끝어절 연결
                    if (Parse_Tree[Rank_Number][i].gover_position.Equals(Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_position))
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_position, true)[0].Nodes
                            .Add(Parse_Tree[Rank_Number][i].dependency_position,
                            Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ")");

                        continue;
                    }
  
                    if (Parse_Tree[Rank_Number][i].dependency_subcatInfo == 0)
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ")");
                    }
                    else if (Parse_Tree[Rank_Number][i].dependency_subcatInfo == 1)
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ") - 목적어");
                    }
                    else if (Parse_Tree[Rank_Number][i].dependency_subcatInfo == 2)
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ") - 주어");
                    }
                    else if (Parse_Tree[Rank_Number][i].dependency_subcatInfo == -2)
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ") - 부사어");
                    }
                    else if (Parse_Tree[Rank_Number][i].dependency_subcatInfo >= 3 && Parse_Tree[Rank_Number][i].dependency_subcatInfo <100)
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ") - Subcat 용언");
                    }
                    else if (Parse_Tree[Rank_Number][i].dependency_subcatInfo >= 100 && Parse_Tree[Rank_Number][i].dependency_subcatInfo <200)
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ") - Subcat [명사-명사]");
                    }
                    else if (Parse_Tree[Rank_Number][i].dependency_subcatInfo >= 200)
                    {
                        SearchPTView.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ") - Subcat [명사-동사]");
                    }
                }
                SearchPTView.ExpandAll();

            }

            // 비문복원, 에지연결오류 표시
            // 범위로 표현하지만, C++과 C#에서 Error code로 넣어야 할듯!
            if (Parse_Tree[Rank_Number][0].rule_Weight > 900 && Parse_Tree[Rank_Number][0].rule_Weight < 1100)
            {
                SearchPTView.Nodes[0].Text = "ROOT : 비문 복원";
                SearchPTView.Nodes[0].ForeColor = Color.White;
                SearchPTView.Nodes[0].BackColor = Color.Crimson;
            }
            else if (Parse_Tree[Rank_Number][0].rule_Weight > 9900 && Parse_Tree[Rank_Number][0].rule_Weight < 10100)
            {
                SearchPTView.Nodes[0].Text = "ROOT : 에지 연결 오류";
                SearchPTView.Nodes[0].ForeColor = Color.White;
                SearchPTView.Nodes[0].BackColor = Color.Indigo;
            }
        }



        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @brif : 랭크 선택 시 파스트리 출력
         */
        private void SearchGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Parse_Tree == null)
                return;

            String RowInfo = SearchGridView.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
            RowInfo = RowInfo.Replace("]", "");
            RowInfo = RowInfo.Replace("[Rank ", "");

            int rank = Convert.ToInt32(RowInfo);

            rank = rank - 1;
            if (rank >= 0 && rank < Parse_Tree.Count())
            {
                ShowPTInSearch(rank);
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("해당 조건의 파스트리 없음", "검색 결과", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }



        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @brif : Rank 그리드 뷰에서 (위/아래) 방향키 눌렀을 때 Event
         */
        private void SearchGridView_KeyUp(object sender, KeyEventArgs e)
        {
            // Up arrow : 38 / Down arrow : 40
            if (e.KeyValue == (char)38 || e.KeyValue == (char)40)
            {
                String RowInfo = SearchGridView.Rows[this.SearchGridView.CurrentCellAddress.Y].Cells[0].FormattedValue.ToString();
                RowInfo = RowInfo.Replace("]", "");
                RowInfo = RowInfo.Replace("[Rank ", "");

                int rank = Convert.ToInt32(RowInfo);
                rank = rank - 1;
                
                ShowPTInSearch(rank);
            }
        }

        private void Search_Form_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }
    }

}
