﻿namespace Parser4CSharp
{
    partial class main_form
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main_form));
            this.tab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ruleComment = new System.Windows.Forms.GroupBox();
            this.comment = new System.Windows.Forms.Label();
            this.ReLoad_Dic = new System.Windows.Forms.Button();
            this.Save_Button = new System.Windows.Forms.Button();
            this.상태 = new System.Windows.Forms.GroupBox();
            this.Parsing_Weight = new System.Windows.Forms.Label();
            this.Parsing_Time = new System.Windows.Forms.Label();
            this.Rank_Count = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.POS_GridView = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.GOV_GridView = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.Verb_radioButton_False = new System.Windows.Forms.RadioButton();
            this.Verb_radioButton_True = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.SpellCheck_radioButton_False = new System.Windows.Forms.RadioButton();
            this.SpellCheck_radioButtion_True = new System.Windows.Forms.RadioButton();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.SubcatCheck_radioButton_False = new System.Windows.Forms.RadioButton();
            this.SubcatCheck_radioButtion_True = new System.Windows.Forms.RadioButton();
            this.label_SpellCheck = new System.Windows.Forms.Label();
            this.label_SubcatCheck = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox_WeightInfo = new System.Windows.Forms.GroupBox();
            this.label_lengthSum = new System.Windows.Forms.Label();
            this.label_ParticleWeight = new System.Windows.Forms.Label();
            this.label_RelationWeight = new System.Windows.Forms.Label();
            this.label_POSWeight = new System.Windows.Forms.Label();
            this.ParseTree_View = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Create_ParseTree = new System.Windows.Forms.Button();
            this.Input_Sentence = new System.Windows.Forms.RichTextBox();
            this.Rank_GridView = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.Total_RESULT_BOX = new System.Windows.Forms.RichTextBox();
            this.result_box = new System.Windows.Forms.RichTextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.Evaluation_Grid = new System.Windows.Forms.DataGridView();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.log = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.stop = new System.Windows.Forms.Button();
            this.Corpus_Path = new System.Windows.Forms.TextBox();
            this.Load_Corpus = new System.Windows.Forms.Button();
            this.Run_evaluation = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Sentence_GridView = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.File_Path = new System.Windows.Forms.TextBox();
            this.Execute_Button = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.tab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.ruleComment.SuspendLayout();
            this.상태.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.POS_GridView)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GOV_GridView)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox_WeightInfo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Rank_GridView)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Evaluation_Grid)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Sentence_GridView)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabPage1);
            this.tab.Controls.Add(this.tabPage3);
            this.tab.Controls.Add(this.tabPage2);
            this.tab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab.Location = new System.Drawing.Point(0, 0);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(1265, 658);
            this.tab.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ruleComment);
            this.tabPage1.Controls.Add(this.ReLoad_Dic);
            this.tabPage1.Controls.Add(this.Save_Button);
            this.tabPage1.Controls.Add(this.상태);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.Rank_GridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1257, 628);
            this.tabPage1.TabIndex = 1;
            this.tabPage1.Text = "Parsing";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // ruleComment
            // 
            this.ruleComment.Controls.Add(this.comment);
            this.ruleComment.Location = new System.Drawing.Point(854, 291);
            this.ruleComment.Name = "ruleComment";
            this.ruleComment.Size = new System.Drawing.Size(390, 67);
            this.ruleComment.TabIndex = 12;
            this.ruleComment.TabStop = false;
            this.ruleComment.Text = "지배-의존 제약 규칙 설명";
            // 
            // comment
            // 
            this.comment.AutoSize = true;
            this.comment.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.comment.Location = new System.Drawing.Point(6, 20);
            this.comment.Name = "comment";
            this.comment.Size = new System.Drawing.Size(52, 20);
            this.comment.TabIndex = 7;
            this.comment.Text = "설명 : ";
            this.comment.TextChanged += new System.EventHandler(this.comment_TextChanged);
            // 
            // ReLoad_Dic
            // 
            this.ReLoad_Dic.Location = new System.Drawing.Point(3, 562);
            this.ReLoad_Dic.Name = "ReLoad_Dic";
            this.ReLoad_Dic.Size = new System.Drawing.Size(183, 26);
            this.ReLoad_Dic.TabIndex = 11;
            this.ReLoad_Dic.Text = "사전 다시 불러오기";
            this.ReLoad_Dic.UseVisualStyleBackColor = true;
            this.ReLoad_Dic.Click += new System.EventHandler(this.ReLoad_Dic_Click);
            // 
            // Save_Button
            // 
            this.Save_Button.Location = new System.Drawing.Point(3, 594);
            this.Save_Button.Name = "Save_Button";
            this.Save_Button.Size = new System.Drawing.Size(183, 26);
            this.Save_Button.TabIndex = 1;
            this.Save_Button.Text = "저장";
            this.Save_Button.UseVisualStyleBackColor = true;
            this.Save_Button.Click += new System.EventHandler(this.Save_Button_Click);
            // 
            // 상태
            // 
            this.상태.Controls.Add(this.Parsing_Weight);
            this.상태.Controls.Add(this.Parsing_Time);
            this.상태.Controls.Add(this.Rank_Count);
            this.상태.Location = new System.Drawing.Point(852, 492);
            this.상태.Name = "상태";
            this.상태.Size = new System.Drawing.Size(392, 128);
            this.상태.TabIndex = 10;
            this.상태.TabStop = false;
            this.상태.Text = "상태";
            // 
            // Parsing_Weight
            // 
            this.Parsing_Weight.AutoSize = true;
            this.Parsing_Weight.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.Parsing_Weight.Location = new System.Drawing.Point(4, 89);
            this.Parsing_Weight.Name = "Parsing_Weight";
            this.Parsing_Weight.Size = new System.Drawing.Size(110, 20);
            this.Parsing_Weight.TabIndex = 11;
            this.Parsing_Weight.Text = "Total Weight  :";
            // 
            // Parsing_Time
            // 
            this.Parsing_Time.AutoSize = true;
            this.Parsing_Time.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.Parsing_Time.Location = new System.Drawing.Point(6, 54);
            this.Parsing_Time.Name = "Parsing_Time";
            this.Parsing_Time.Size = new System.Drawing.Size(94, 20);
            this.Parsing_Time.TabIndex = 10;
            this.Parsing_Time.Text = "Paing Time :";
            // 
            // Rank_Count
            // 
            this.Rank_Count.AutoSize = true;
            this.Rank_Count.Font = new System.Drawing.Font("맑은 고딕", 11F);
            this.Rank_Count.Location = new System.Drawing.Point(6, 20);
            this.Rank_Count.Name = "Rank_Count";
            this.Rank_Count.Size = new System.Drawing.Size(87, 20);
            this.Rank_Count.TabIndex = 7;
            this.Rank_Count.Text = "Parse Tree :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.POS_GridView);
            this.groupBox5.Location = new System.Drawing.Point(854, 195);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(390, 90);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "의존소";
            // 
            // POS_GridView
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.POS_GridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.POS_GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.POS_GridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.POS_GridView.Location = new System.Drawing.Point(6, 23);
            this.POS_GridView.Name = "POS_GridView";
            this.POS_GridView.RowHeadersVisible = false;
            this.POS_GridView.RowTemplate.Height = 23;
            this.POS_GridView.Size = new System.Drawing.Size(378, 50);
            this.POS_GridView.TabIndex = 4;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.GOV_GridView);
            this.groupBox4.Location = new System.Drawing.Point(854, 99);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(390, 90);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "지배소";
            // 
            // GOV_GridView
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GOV_GridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.GOV_GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GOV_GridView.DefaultCellStyle = dataGridViewCellStyle4;
            this.GOV_GridView.Location = new System.Drawing.Point(6, 23);
            this.GOV_GridView.Name = "GOV_GridView";
            this.GOV_GridView.RowHeadersVisible = false;
            this.GOV_GridView.RowTemplate.Height = 23;
            this.GOV_GridView.Size = new System.Drawing.Size(378, 50);
            this.GOV_GridView.TabIndex = 5;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox16);
            this.groupBox3.Controls.Add(this.groupBox17);
            this.groupBox3.Controls.Add(this.groupBox18);
            this.groupBox3.Controls.Add(this.label_SpellCheck);
            this.groupBox3.Controls.Add(this.label_SubcatCheck);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(854, 354);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(390, 132);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Option";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.Verb_radioButton_False);
            this.groupBox16.Controls.Add(this.Verb_radioButton_True);
            this.groupBox16.Location = new System.Drawing.Point(160, 23);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(226, 36);
            this.groupBox16.TabIndex = 18;
            this.groupBox16.TabStop = false;
            // 
            // Verb_radioButton_False
            // 
            this.Verb_radioButton_False.AutoSize = true;
            this.Verb_radioButton_False.Location = new System.Drawing.Point(101, 12);
            this.Verb_radioButton_False.Name = "Verb_radioButton_False";
            this.Verb_radioButton_False.Size = new System.Drawing.Size(55, 21);
            this.Verb_radioButton_False.TabIndex = 12;
            this.Verb_radioButton_False.TabStop = true;
            this.Verb_radioButton_False.Text = "False";
            this.Verb_radioButton_False.UseVisualStyleBackColor = true;
            // 
            // Verb_radioButton_True
            // 
            this.Verb_radioButton_True.AutoSize = true;
            this.Verb_radioButton_True.Location = new System.Drawing.Point(17, 12);
            this.Verb_radioButton_True.Name = "Verb_radioButton_True";
            this.Verb_radioButton_True.Size = new System.Drawing.Size(53, 21);
            this.Verb_radioButton_True.TabIndex = 11;
            this.Verb_radioButton_True.TabStop = true;
            this.Verb_radioButton_True.Text = "True";
            this.Verb_radioButton_True.UseVisualStyleBackColor = true;
            this.Verb_radioButton_True.CheckedChanged += new System.EventHandler(this.Verb_radioButton_True_CheckedChanged);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.SpellCheck_radioButton_False);
            this.groupBox17.Controls.Add(this.SpellCheck_radioButtion_True);
            this.groupBox17.Location = new System.Drawing.Point(160, 56);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(226, 36);
            this.groupBox17.TabIndex = 21;
            this.groupBox17.TabStop = false;
            // 
            // SpellCheck_radioButton_False
            // 
            this.SpellCheck_radioButton_False.AutoSize = true;
            this.SpellCheck_radioButton_False.Location = new System.Drawing.Point(101, 12);
            this.SpellCheck_radioButton_False.Name = "SpellCheck_radioButton_False";
            this.SpellCheck_radioButton_False.Size = new System.Drawing.Size(55, 21);
            this.SpellCheck_radioButton_False.TabIndex = 12;
            this.SpellCheck_radioButton_False.TabStop = true;
            this.SpellCheck_radioButton_False.Text = "False";
            this.SpellCheck_radioButton_False.UseVisualStyleBackColor = true;
            // 
            // SpellCheck_radioButtion_True
            // 
            this.SpellCheck_radioButtion_True.AutoSize = true;
            this.SpellCheck_radioButtion_True.Location = new System.Drawing.Point(17, 12);
            this.SpellCheck_radioButtion_True.Name = "SpellCheck_radioButtion_True";
            this.SpellCheck_radioButtion_True.Size = new System.Drawing.Size(53, 21);
            this.SpellCheck_radioButtion_True.TabIndex = 11;
            this.SpellCheck_radioButtion_True.TabStop = true;
            this.SpellCheck_radioButtion_True.Text = "True";
            this.SpellCheck_radioButtion_True.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.SubcatCheck_radioButton_False);
            this.groupBox18.Controls.Add(this.SubcatCheck_radioButtion_True);
            this.groupBox18.Location = new System.Drawing.Point(160, 89);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(226, 36);
            this.groupBox18.TabIndex = 22;
            this.groupBox18.TabStop = false;
            // 
            // SubcatCheck_radioButton_False
            // 
            this.SubcatCheck_radioButton_False.AutoSize = true;
            this.SubcatCheck_radioButton_False.Location = new System.Drawing.Point(101, 12);
            this.SubcatCheck_radioButton_False.Name = "SubcatCheck_radioButton_False";
            this.SubcatCheck_radioButton_False.Size = new System.Drawing.Size(55, 21);
            this.SubcatCheck_radioButton_False.TabIndex = 12;
            this.SubcatCheck_radioButton_False.Text = "False";
            this.SubcatCheck_radioButton_False.UseVisualStyleBackColor = true;
            // 
            // SubcatCheck_radioButtion_True
            // 
            this.SubcatCheck_radioButtion_True.AutoSize = true;
            this.SubcatCheck_radioButtion_True.Location = new System.Drawing.Point(17, 12);
            this.SubcatCheck_radioButtion_True.Name = "SubcatCheck_radioButtion_True";
            this.SubcatCheck_radioButtion_True.Size = new System.Drawing.Size(53, 21);
            this.SubcatCheck_radioButtion_True.TabIndex = 11;
            this.SubcatCheck_radioButtion_True.TabStop = true;
            this.SubcatCheck_radioButtion_True.Text = "True";
            this.SubcatCheck_radioButtion_True.UseVisualStyleBackColor = true;
            // 
            // label_SpellCheck
            // 
            this.label_SpellCheck.AutoSize = true;
            this.label_SpellCheck.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.label_SpellCheck.Location = new System.Drawing.Point(2, 66);
            this.label_SpellCheck.Name = "label_SpellCheck";
            this.label_SpellCheck.Size = new System.Drawing.Size(84, 19);
            this.label_SpellCheck.TabIndex = 20;
            this.label_SpellCheck.Text = "맞춤법 교정";
            // 
            // label_SubcatCheck
            // 
            this.label_SubcatCheck.AutoSize = true;
            this.label_SubcatCheck.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.label_SubcatCheck.Location = new System.Drawing.Point(2, 98);
            this.label_SubcatCheck.Name = "label_SubcatCheck";
            this.label_SubcatCheck.Size = new System.Drawing.Size(168, 19);
            this.label_SubcatCheck.TabIndex = 23;
            this.label_SubcatCheck.Text = "Subcat 정보 활용(미완성)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.label6.Location = new System.Drawing.Point(2, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 19);
            this.label6.TabIndex = 19;
            this.label6.Text = "격조사 규칙 추가";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox_WeightInfo);
            this.groupBox2.Controls.Add(this.ParseTree_View);
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.groupBox2.Location = new System.Drawing.Point(192, 99);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(656, 521);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Parse Tree";
            // 
            // groupBox_WeightInfo
            // 
            this.groupBox_WeightInfo.Controls.Add(this.label_lengthSum);
            this.groupBox_WeightInfo.Controls.Add(this.label_ParticleWeight);
            this.groupBox_WeightInfo.Controls.Add(this.label_RelationWeight);
            this.groupBox_WeightInfo.Controls.Add(this.label_POSWeight);
            this.groupBox_WeightInfo.Location = new System.Drawing.Point(10, 463);
            this.groupBox_WeightInfo.Name = "groupBox_WeightInfo";
            this.groupBox_WeightInfo.Size = new System.Drawing.Size(640, 52);
            this.groupBox_WeightInfo.TabIndex = 1;
            this.groupBox_WeightInfo.TabStop = false;
            this.groupBox_WeightInfo.Text = "가중치 정보";
            // 
            // label_lengthSum
            // 
            this.label_lengthSum.AutoSize = true;
            this.label_lengthSum.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.label_lengthSum.Location = new System.Drawing.Point(437, 21);
            this.label_lengthSum.Name = "label_lengthSum";
            this.label_lengthSum.Size = new System.Drawing.Size(77, 21);
            this.label_lengthSum.TabIndex = 15;
            this.label_lengthSum.Text = "Length : ";
            // 
            // label_ParticleWeight
            // 
            this.label_ParticleWeight.AutoSize = true;
            this.label_ParticleWeight.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.label_ParticleWeight.Location = new System.Drawing.Point(287, 21);
            this.label_ParticleWeight.Name = "label_ParticleWeight";
            this.label_ParticleWeight.Size = new System.Drawing.Size(80, 21);
            this.label_ParticleWeight.TabIndex = 14;
            this.label_ParticleWeight.Text = "Particle : ";
            // 
            // label_RelationWeight
            // 
            this.label_RelationWeight.AutoSize = true;
            this.label_RelationWeight.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.label_RelationWeight.Location = new System.Drawing.Point(126, 21);
            this.label_RelationWeight.Name = "label_RelationWeight";
            this.label_RelationWeight.Size = new System.Drawing.Size(86, 21);
            this.label_RelationWeight.TabIndex = 13;
            this.label_RelationWeight.Text = "Relation : ";
            // 
            // label_POSWeight
            // 
            this.label_POSWeight.AutoSize = true;
            this.label_POSWeight.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.label_POSWeight.Location = new System.Drawing.Point(6, 21);
            this.label_POSWeight.Name = "label_POSWeight";
            this.label_POSWeight.Size = new System.Drawing.Size(56, 21);
            this.label_POSWeight.TabIndex = 12;
            this.label_POSWeight.Text = "POS : ";
            // 
            // ParseTree_View
            // 
            this.ParseTree_View.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.ParseTree_View.Indent = 30;
            this.ParseTree_View.ItemHeight = 30;
            this.ParseTree_View.Location = new System.Drawing.Point(10, 23);
            this.ParseTree_View.Name = "ParseTree_View";
            this.ParseTree_View.Size = new System.Drawing.Size(640, 434);
            this.ParseTree_View.TabIndex = 0;
            this.ParseTree_View.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.ParseTree_View_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Create_ParseTree);
            this.groupBox1.Controls.Add(this.Input_Sentence);
            this.groupBox1.Location = new System.Drawing.Point(192, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1052, 87);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sentence";
            // 
            // Create_ParseTree
            // 
            this.Create_ParseTree.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            this.Create_ParseTree.Location = new System.Drawing.Point(921, 23);
            this.Create_ParseTree.Name = "Create_ParseTree";
            this.Create_ParseTree.Size = new System.Drawing.Size(125, 50);
            this.Create_ParseTree.TabIndex = 2;
            this.Create_ParseTree.Text = "Parse Tree 생성";
            this.Create_ParseTree.UseVisualStyleBackColor = true;
            this.Create_ParseTree.Click += new System.EventHandler(this.Create_ParseTree_Click);
            // 
            // Input_Sentence
            // 
            this.Input_Sentence.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Input_Sentence.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.Input_Sentence.Location = new System.Drawing.Point(10, 23);
            this.Input_Sentence.Multiline = false;
            this.Input_Sentence.Name = "Input_Sentence";
            this.Input_Sentence.Size = new System.Drawing.Size(905, 50);
            this.Input_Sentence.TabIndex = 1;
            this.Input_Sentence.Text = "";
            this.Input_Sentence.TextChanged += new System.EventHandler(this.Input_Sentence_TextChanged);
            this.Input_Sentence.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Input_Sentence_KeyPress);
            // 
            // Rank_GridView
            // 
            this.Rank_GridView.AllowUserToResizeColumns = false;
            this.Rank_GridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Rank_GridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Rank_GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.Rank_GridView.Location = new System.Drawing.Point(6, 6);
            this.Rank_GridView.MultiSelect = false;
            this.Rank_GridView.Name = "Rank_GridView";
            this.Rank_GridView.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Rank_GridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.Rank_GridView.RowHeadersVisible = false;
            this.Rank_GridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Rank_GridView.RowTemplate.Height = 23;
            this.Rank_GridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.Rank_GridView.Size = new System.Drawing.Size(180, 550);
            this.Rank_GridView.TabIndex = 0;
            this.Rank_GridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Rank_Click);
            this.Rank_GridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Rank_GridView_CellContentClick);
            this.Rank_GridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Rank_DoubleClick);
            this.Rank_GridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Rank_GridView_KeyUp);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox12);
            this.tabPage3.Controls.Add(this.groupBox11);
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1257, 628);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Evaluation";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.Total_RESULT_BOX);
            this.groupBox12.Controls.Add(this.result_box);
            this.groupBox12.Location = new System.Drawing.Point(828, 112);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(420, 502);
            this.groupBox12.TabIndex = 5;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "결과";
            // 
            // Total_RESULT_BOX
            // 
            this.Total_RESULT_BOX.Location = new System.Drawing.Point(6, 164);
            this.Total_RESULT_BOX.Name = "Total_RESULT_BOX";
            this.Total_RESULT_BOX.Size = new System.Drawing.Size(408, 102);
            this.Total_RESULT_BOX.TabIndex = 1;
            this.Total_RESULT_BOX.Text = "";
            // 
            // result_box
            // 
            this.result_box.Location = new System.Drawing.Point(6, 28);
            this.result_box.Name = "result_box";
            this.result_box.Size = new System.Drawing.Size(408, 130);
            this.result_box.TabIndex = 0;
            this.result_box.Text = "";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.Evaluation_Grid);
            this.groupBox11.Location = new System.Drawing.Point(8, 112);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(810, 508);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Sentence";
            // 
            // Evaluation_Grid
            // 
            this.Evaluation_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Evaluation_Grid.DefaultCellStyle = dataGridViewCellStyle7;
            this.Evaluation_Grid.Location = new System.Drawing.Point(6, 23);
            this.Evaluation_Grid.Name = "Evaluation_Grid";
            this.Evaluation_Grid.RowTemplate.Height = 23;
            this.Evaluation_Grid.Size = new System.Drawing.Size(798, 479);
            this.Evaluation_Grid.TabIndex = 0;
            this.Evaluation_Grid.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Evaluation_Sentence_Parsing);
            this.Evaluation_Grid.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dataGridView_CellPainting);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.log);
            this.groupBox10.Controls.Add(this.button2);
            this.groupBox10.Location = new System.Drawing.Point(828, 13);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(421, 93);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Log";
            // 
            // log
            // 
            this.log.Location = new System.Drawing.Point(6, 43);
            this.log.Name = "log";
            this.log.ReadOnly = true;
            this.log.Size = new System.Drawing.Size(302, 24);
            this.log.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(314, 23);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 54);
            this.button2.TabIndex = 0;
            this.button2.Text = "Corpus 생성";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.stop);
            this.groupBox9.Controls.Add(this.Corpus_Path);
            this.groupBox9.Controls.Add(this.Load_Corpus);
            this.groupBox9.Controls.Add(this.Run_evaluation);
            this.groupBox9.Location = new System.Drawing.Point(8, 13);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(810, 93);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Path";
            // 
            // stop
            // 
            this.stop.Location = new System.Drawing.Point(711, 31);
            this.stop.Name = "stop";
            this.stop.Size = new System.Drawing.Size(93, 38);
            this.stop.TabIndex = 7;
            this.stop.Text = "정지";
            this.stop.UseVisualStyleBackColor = true;
            this.stop.Click += new System.EventHandler(this.stop_Click);
            // 
            // Corpus_Path
            // 
            this.Corpus_Path.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.Corpus_Path.Location = new System.Drawing.Point(6, 39);
            this.Corpus_Path.Name = "Corpus_Path";
            this.Corpus_Path.ReadOnly = true;
            this.Corpus_Path.Size = new System.Drawing.Size(485, 25);
            this.Corpus_Path.TabIndex = 6;
            // 
            // Load_Corpus
            // 
            this.Load_Corpus.Location = new System.Drawing.Point(497, 31);
            this.Load_Corpus.Name = "Load_Corpus";
            this.Load_Corpus.Size = new System.Drawing.Size(101, 38);
            this.Load_Corpus.TabIndex = 1;
            this.Load_Corpus.Text = "불러오기";
            this.Load_Corpus.UseVisualStyleBackColor = true;
            this.Load_Corpus.Click += new System.EventHandler(this.Load_Corpus_Click);
            // 
            // Run_evaluation
            // 
            this.Run_evaluation.Location = new System.Drawing.Point(604, 31);
            this.Run_evaluation.Name = "Run_evaluation";
            this.Run_evaluation.Size = new System.Drawing.Size(101, 38);
            this.Run_evaluation.TabIndex = 0;
            this.Run_evaluation.Text = "실행";
            this.Run_evaluation.UseVisualStyleBackColor = true;
            this.Run_evaluation.Click += new System.EventHandler(this.Run_evaluation_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1257, 628);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "File Parsing";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.richTextBox);
            this.groupBox8.Location = new System.Drawing.Point(736, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(506, 83);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Parsing 상태";
            // 
            // richTextBox
            // 
            this.richTextBox.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.richTextBox.Location = new System.Drawing.Point(6, 23);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.ReadOnly = true;
            this.richTextBox.Size = new System.Drawing.Size(494, 49);
            this.richTextBox.TabIndex = 0;
            this.richTextBox.Text = "";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Sentence_GridView);
            this.groupBox7.Controls.Add(this.label5);
            this.groupBox7.Location = new System.Drawing.Point(8, 95);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1234, 475);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Sentence";
            // 
            // Sentence_GridView
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Sentence_GridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.Sentence_GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Sentence_GridView.Location = new System.Drawing.Point(10, 23);
            this.Sentence_GridView.Name = "Sentence_GridView";
            this.Sentence_GridView.RowTemplate.Height = 23;
            this.Sentence_GridView.Size = new System.Drawing.Size(1218, 446);
            this.Sentence_GridView.TabIndex = 4;
            this.Sentence_GridView.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dataGridView_CellPainting);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.label5.Location = new System.Drawing.Point(6, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 19);
            this.label5.TabIndex = 3;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button1);
            this.groupBox6.Controls.Add(this.File_Path);
            this.groupBox6.Controls.Add(this.Execute_Button);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Location = new System.Drawing.Point(8, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(722, 83);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "File Path";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(508, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 54);
            this.button1.TabIndex = 6;
            this.button1.Text = "불러오기";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Load_file);
            // 
            // File_Path
            // 
            this.File_Path.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.File_Path.Location = new System.Drawing.Point(12, 34);
            this.File_Path.Name = "File_Path";
            this.File_Path.ReadOnly = true;
            this.File_Path.Size = new System.Drawing.Size(482, 25);
            this.File_Path.TabIndex = 5;
            // 
            // Execute_Button
            // 
            this.Execute_Button.Location = new System.Drawing.Point(615, 18);
            this.Execute_Button.Name = "Execute_Button";
            this.Execute_Button.Size = new System.Drawing.Size(101, 54);
            this.Execute_Button.TabIndex = 4;
            this.Execute_Button.Text = "실행";
            this.Execute_Button.UseVisualStyleBackColor = true;
            this.Execute_Button.Click += new System.EventHandler(this.Execute_Button_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 10F);
            this.label4.Location = new System.Drawing.Point(6, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 19);
            this.label4.TabIndex = 3;
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog_FileOk);
            // 
            // main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1265, 658);
            this.Controls.Add(this.tab);
            this.Font = new System.Drawing.Font("맑은 고딕", 9.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "main_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KLParser 3.7.2(2020.05.19)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_form_FormClosing);
            this.Load += new System.EventHandler(this.main_form_Load);
            this.tab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ruleComment.ResumeLayout(false);
            this.ruleComment.PerformLayout();
            this.상태.ResumeLayout(false);
            this.상태.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.POS_GridView)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GOV_GridView)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox_WeightInfo.ResumeLayout(false);
            this.groupBox_WeightInfo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Rank_GridView)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Evaluation_Grid)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Sentence_GridView)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView Rank_GridView;
        private System.Windows.Forms.Button Create_ParseTree;
        private System.Windows.Forms.RichTextBox Input_Sentence;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView POS_GridView;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TreeView ParseTree_View;
        private System.Windows.Forms.Label Rank_Count;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView GOV_GridView;
        private System.Windows.Forms.GroupBox 상태;
        private System.Windows.Forms.Label Parsing_Time;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView Sentence_GridView;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Execute_Button;
        private System.Windows.Forms.TextBox File_Path;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button Load_Corpus;
        private System.Windows.Forms.Button Run_evaluation;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox Corpus_Path;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.DataGridView Evaluation_Grid;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button stop;
        private System.Windows.Forms.Button Save_Button;
        private System.Windows.Forms.TextBox log;
        private System.Windows.Forms.RichTextBox result_box;
        private System.Windows.Forms.RichTextBox Total_RESULT_BOX;
        private System.Windows.Forms.Button ReLoad_Dic;
        private System.Windows.Forms.Label Parsing_Weight;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.RadioButton Verb_radioButton_False;
        private System.Windows.Forms.RadioButton Verb_radioButton_True;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox_WeightInfo;
        private System.Windows.Forms.Label label_POSWeight;
        private System.Windows.Forms.Label label_RelationWeight;
        private System.Windows.Forms.Label label_ParticleWeight;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RadioButton SpellCheck_radioButton_False;
        private System.Windows.Forms.RadioButton SpellCheck_radioButtion_True;
        private System.Windows.Forms.RadioButton SubcatCheck_radioButton_False;
        private System.Windows.Forms.RadioButton SubcatCheck_radioButtion_True;
        private System.Windows.Forms.Label label_SpellCheck;
        private System.Windows.Forms.Label label_SubcatCheck;
        private System.Windows.Forms.Label label_lengthSum;
        private System.Windows.Forms.GroupBox ruleComment;
        private System.Windows.Forms.Label comment;
    }
}

