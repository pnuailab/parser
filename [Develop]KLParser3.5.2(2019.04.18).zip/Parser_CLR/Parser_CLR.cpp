#include "stdafx.h"
#include "Parser_CLR.h"
#include <msclr\marshal_cppstd.h>
#include <msclr\marshal.h>
#include <cliext\list> 


using namespace System::Runtime::InteropServices;

namespace managed_Pasrser
{
	Parser_CLR::Parser_CLR() : m_parser(new Parser)
	{
		//m_parser = new Parser();
	}

	Parser_CLR::~Parser_CLR()
	{
		if (m_parser)
		{
			delete m_parser;
			m_parser = 0;
		}
	}


	void Parser_CLR::loadDic()
	{
		m_parser->loadDic();
	}
	void Parser_CLR::loadDLLDic()
	{
		m_parser->loadDLLDic();
	}

	void Parser_CLR::loadModule()
	{
		m_parser->loadModule();
	}
	
	int Parser_CLR::getParseTree(String^ _szSentence, bool _isFile, bool spell)
	{
		pin_ptr<const wchar_t> wch = PtrToStringChars(_szSentence);
		std::wstring nativeWstr(wch);
		//if you want to convert to std::string without manual resource cleaning
		std::string nativeStr(CW2A(nativeWstr.c_str()));

		System::String^ sentence = _szSentence;
		char* str = (char*)(Marshal::StringToHGlobalAnsi(sentence)).ToPointer();
		ParseTree *mPT = new ParseTree();
		mPT->clear();

		return m_parser->CSharp_ParseTree(str, _isFile, spell);
	}
}