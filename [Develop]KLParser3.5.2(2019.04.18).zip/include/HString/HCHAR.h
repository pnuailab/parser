#pragma once


#define HCHAR HCHAR_KLT	// ���������� libPnuNlp.so���� HCHAR�� �ҷ� �� ��, �°��� HCHAR�� �ҷ��Ἥ ������ ����. �� ���� �ذ��� ���� ��Ī�� ������


#ifndef HSTRING_LIB_API
#ifdef HSTRING_LIB_EXPORTS
#		define HSTRING_LIB_API __declspec(dllexport)
#else
#		define HSTRING_LIB_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	HSTRING_LIB_API
#		define	HSTRING_LIB_API
#endif


#include <ostream>

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
#ifdef LINUX_PORTING
typedef unsigned int		DWORD;
#else
typedef unsigned long		DWORD;
#endif

#define JONGBOOL_NOT_REMOVE		0
#define JONGBOOL_REMOVE			1
#define JONGBOOL_ONLY_JONGSUNG	1



class HSTRING_LIB_API HCHAR
{
public:
	union{
		WORD data;
		struct {
			WORD end	: 5;		//����
			WORD mid	: 5;		//�߼�
			WORD sts	: 5;		//�ʼ�
			WORD fill	: 1;		//fill code (�̰��� 1�̸� �ѱ��̴�)
		}g;
		struct {
			BYTE rear;	 // �ι�° ����Ʈ
			BYTE front;	 // ù��° ����Ʈ
		}c;
	};
	//HCHAR(void);
	//~HCHAR(void);

	int IsJohabHangul() const;
	inline int IsJohabHanja() const	{ return ((c.front > 0xDF && c.front < 0xFA)
							&& (c.rear > 0x30 && c.rear < 0xFF)); }
	inline int IsDigit() const	{ return (0x0030 <= data && data <= 0x0039); }
	inline int IsUpper() const	{ return (0x0041 <= data && data <= 0x005a); }
	inline int IsLower() const	{ return (0x0061 <= data && data <= 0x007a); }
	inline int IsAlpha() const	{ return ( IsUpper() || IsLower() ); };
	inline int IsAlnum() const	{ return ( IsAlpha() || IsDigit() ); };
	inline int IsYangsungMoeum() const
	{
		return ( (g.mid > 2 && g.mid < 7) || (g.mid > 12 && g.mid < 20) );
	}
	inline int IsYangsungMoeumEomi() const
	{
		return ( g.mid==0x3 || g.mid==0x5 || g.mid==0xd || g.mid==0x13);
	}
	inline int IsYusungEum() const
	{
		return ( g.end==0x5 || g.end==0x9 || g.end==0x11 || g.end==0x17 || g.end==0x1 );
	}
	inline int IsGyeongEum() const
	{
		return ( g.sts==2 || g.sts==4 || g.sts==5 || g.sts==8 || g.sts==9 || g.sts==11 || g.sts==13 || g.sts==14 );
	}


	int IsWordHCHAR();
	void ToJongsung();
	void ToPrintJongsung();
	void ToLower();
	int IsSpacingEncodeHCHAR();
	int IsURLDelim();

 	int operator==( HCHAR phcCompare ) const;
 	int operator!=( HCHAR phcCompare ) const;
 	int operator>( HCHAR phcCompare ) const;
 	int operator>=( HCHAR phcCompare ) const;
	int operator<( HCHAR phcCompare ) const;
	int operator<=( HCHAR phcCompare ) const;
	void operator=( HCHAR phcAssign ) ;

	friend std::ostream& operator<<( std::ostream& os_input, HCHAR& hcInput );

};
