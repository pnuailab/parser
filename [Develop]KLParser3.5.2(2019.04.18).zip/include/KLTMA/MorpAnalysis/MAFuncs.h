
#pragma once

//wchar_t

#ifndef KLTAGGERMA_API
#ifdef KLTMA_EXPORTS
#		define KLTAGGERMA_API __declspec(dllexport)
#else
#		define KLTAGGERMA_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	KLTAGGERMA_API
#		define	KLTAGGERMA_API
#endif
//
//#ifdef	LINUX_PORTING
//#		include "../stdafx.h"
//#		include "../MacOSIncludes/mac_inc.h"
//#else
//#		include <Windows.h>
//#endif

#include "include/HString/HString.h"
#include "include/KLTTypeMng/TagString.h"

//
//
//#include "include/PnuNlpAddon.h"//"



class KLTAGGERMA_API MAFuncs
{
	//PnuNlp* myPnuNlp; // ���¼� �м��� �ϱ� ���� �ʿ�
public:
	static bool PushbackMA(int _POS, Token& _token, const char* _szInput, int _numOfBytes=-1);
	static bool PushbackMA(int _POS, Token& _token, int _numOfHCharForAttach=-1);
	static bool PushbackMorpForEach(unsigned int _POS, Token &_token, int _numOfHCharForAttach=-1, const HCHAR* _hszStr=NULL, bool _bUseDecompStr=false, bool _isStartJong=false);
	static bool PushbackMorp(unsigned int _POS, Token& _token, int _idxOfMA=-1, int _numOfHCharForAttach=-1, const HCHAR* _hszStr=NULL, bool _bUseDecompStr=false, bool _isStartJong=false, int _nTotalHCHAROfEllipsis=0);
	static bool SetMorpStr(Token& _token, int _maidx, int _morpidx, const HCHAR* _hszOtherStr=NULL, bool _isDecompMorp=false, int *_pTtotalLenOfEllipsis=NULL);

	static void RegenerateDocompStr(Token &token);
	static bool GetSuitableStr(HString &_hstrResult, const char* _szSoruce, const HCHAR* _hszOtherStr, unsigned int _numOfHCHAR);
	static bool RepairOrgStr(char* szSrc, Token& token, int maidx, int morpidx, bool isDecompMorp, HString &hstr);	


};
