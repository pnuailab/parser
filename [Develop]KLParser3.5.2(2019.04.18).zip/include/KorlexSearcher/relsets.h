#ifndef __RELSETS_H__
#define __RELSETS_H__

#define ADJ_REL									\
	"Pointer symbol for Adjectives :\n"			\
	"!\t: Antonym\n" 							\
	"&\t: Similar to\n"							\
	"^\t: Also see\n"							\
	"=\t: Attribute\n"							\
	"\\\t: Pertainym (pertains to noun)\n"		\
	"-c\t: Domain of Synset - TOPIC\n"			\
	"-r\t: Domain of Synset - REGION\n"			\
	"-u\t: Domain of Synset - USAGE\n"			

#define ADV_REL									\
	"Pointer symbol for Adverb :\n"				\
	"!\t: Antonym\n"							\
	"\\\t: Derived from Adjective\n"			\
	"-c\t: Domain of Synset - TOPIC\n"			\
	"-r\t: Domain of Synset - REGION\n"			\
	"-u\t: Domain of Synset - USAGE\n"			
	
#define VERB_REL								\
	"Pointer symbol for Verb :\n"				\
	"!\t: Antonym\n"							\
	"$\t: Verb Group\n"							\
	"*\t: Entailment\n"							\
	"@\t: Hypernym\n"							\
	"^\t: Also see\n"							\
	"~\t: Hyponym\n"							\
	"+\t: Derivationally related form\n"		\
	"<\t: \n"									\
	">\t: Cause\n"								\
	"acc\t: \n"									\
	"inacc\t: \n"								\
	"child\t: child\n"							\
	"parent\t: parent\n"						\
	"-c\t: Domain of Synset - TOPIC\n"			\
	"-r\t: Domain of Synset - REGION\n"			\
	"-u\t: Domain of Synset - USAGE\n"			

#define NOUN_REL								\
	"Pointer symbol for Noun :\n"				\
	"!\t: Antonym\n"							\
	"#m\t: Member Holonym\n"					\
	"#p\t: Part Holonym\n"						\
	"#s\t: Substance Holonym\n"					\
	"%%m\t: Member meronym\n"					\
	"%%p\t: Part meronym\n"						\
	"%%s\t: Substance meronym\n"				\
	";c\t: Domain of synset - TOPIC\n"			\
	";r\t: Domain of synset - REGION\n"			\
	";u\t: Domain of synset - USAGE\n"			\
	"@\t: Hypernym\n"							\
	"~\t: Hyponym\n"							\
	"+\t: Derivationally related form\n"		\
	"=\t: Attribute\n"							\
	"\\\t: Pertainym (pertains to noun)\n"		\
	"acc\t: \n"									\
	"inacc\t: \n"								\
	"child\t: child\n"							\
	"parent\t: parent\n"						\
	"-c\t: Domain of Synset - TOPIC\n"			\
	"-r\t: Domain of Synset - REGION\n"			\
	"-u\t: Domain of Synset - USAGE\n"			
	
#endif
