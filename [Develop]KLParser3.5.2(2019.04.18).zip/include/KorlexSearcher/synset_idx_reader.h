/// This file contains EUC-KR(aka UHC, CP949) Character set.
/// 
/// 2008 (C) Pusan National University, Artificial Intelligence Lab.
/// First code Written by Shin Jong hun, 2008. 02.
/// @file			synset_idx_reader.h
/// Last Update		2008-02-27, v0.1.0
/// 
/// @brief 
/// 	synset_idx_reader.cpp �� ��� ����.

#ifndef __SYNSET_IDX_READER_H__
#define __SYNSET_IDX_READER_H__

#include <vector>
#include <list>

#ifdef WIN32
#ifdef LOAD_PERFORMANCE_CHECK
#include <Windows.h>
#endif
#endif

#include "fmemread_layer.h"

#ifdef __GNUC__
#include <stdint.h>
#else
#if _MSC_VER > 1800
#include <stdint.h>
#else
#include "inttypes.h"
#endif
#endif // __GNUC__

using namespace std;

class synItem {
public:
	uint32_t		synnum;
	vector<int32_t>	f_offset_list;

	/// @brief �� ������. ��� ���� �׸��� ���Ѵ�.
	bool operator== (const synItem& oper) const {
		if (synnum != oper.synnum)
		{
			return false;
		}
		return true;
	}

	/// @brief ���� ������.
	synItem& operator= (const synItem &rhs) {
		if (this != &rhs)
		{
			synnum = rhs.synnum;
			f_offset_list = rhs.f_offset_list;
		}

		return *this;
	}

	/// @brief <������ �����ε�. synset ��ȣ�� ũ�⸦ ���Ѵ�.
	bool operator< (const synItem& oper) const {
		return (synnum < oper.synnum);
	}
	bool operator< (const uint32_t oper) const {
		return (synnum < oper);
	}
	/// @brief >������ �����ε�. synset ��ȣ�� ũ�⸦ ���Ѵ�.
	bool operator> (const synItem& oper) const {
		return (synnum > oper.synnum);
	}

	bool operator()(const synItem &lhs, const synItem &rhs) const
	{	
		return (lhs.synnum < rhs.synnum);
	}
	bool operator()(const synItem &lhs, const uint32_t k) const
	{	
		return (lhs.synnum < k);
	}
	bool operator()(const uint32_t k, const synItem &rhs) const
	{
		return (k < rhs.synnum);
	}
};

using namespace std;

class synsetIdxReader {
private:
	char *INDEX_FILENAME;			///< �ε��� ���� ��. (ex. krx_synset.idx)

	vector<synItem> syn_vec;

	bool idx_loaded;

	int identify_index_file (fmemlayer *fmemstr);
public:
	int idx_load_with_name (const char *filename);
	list<int32_t> query_word (uint32_t);
	int load ();
	void destroy ();

	// Constructor & Destructor
	synsetIdxReader ();
	synsetIdxReader (const char *);
	~synsetIdxReader ();
};

#endif
