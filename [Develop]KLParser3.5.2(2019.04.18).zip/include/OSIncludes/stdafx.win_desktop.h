

#pragma once

#ifdef WIN32

#define WIN_DESKTOP


#define WIN32_LEAN_AND_MEAN		// ���� ������ �ʴ� ������ Windows ������� �����մϴ�.

#include <malloc.h>
#include <time.h>
#include <string.h>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
//#include <cstring>
#include <cctype>
#include <cwchar>
#include <fstream>
#include <iostream>
#include <bitset>
#include <list>
#include <ostream>
#include <stack>
#include <strstream>
#include <string>

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#include <windows.h>

using namespace std;

#define DEFAULT_PACK_SIZE 1

// 
#ifndef __LITTLE_ENDIAN__
#	define __LITTLE_ENDIAN__
#endif
#define ENDIAN_ITOS(s)		(s)		// reverse: unsigned short(16 bit)
#define ENDIAN_ITOL(l)		(l)		// reverse: unsigned long(32 bit)
#define ENDIAN_ITOLL(ll)	(ll)	// reverse: unsigned long long(64 bit)

#define MAC_PATH(path)	(path)

//#define EnterCS(__cs) printf("%s:%s()::%d: EnterCS:%s\n", __FILE__, __FUNCTION__, __LINE__, #__cs);EnterCriticalSection((CRITICAL_SECTION*)__cs)
//#define LeaveCS(__cs) printf("%s:%s()::%d: LeaveCS:%s\n", __FILE__, __FUNCTION__, __LINE__, #__cs);LeaveCriticalSection((CRITICAL_SECTION*)__cs)
#define EnterCS(__cs)	EnterCriticalSection((CRITICAL_SECTION*)__cs)
#define LeaveCS(__cs)	LeaveCriticalSection((CRITICAL_SECTION*)__cs)



#ifndef UAssert
#define UAssert(__x)	assert(__x)
#endif


#endif // WIN32

