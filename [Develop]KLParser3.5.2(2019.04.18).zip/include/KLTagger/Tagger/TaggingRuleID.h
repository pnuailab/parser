
#pragma once

//////////////////////////////////////////////////////////////////////////
//
//	TaggingRuleID
//
//////////////////////////////////////////////////////////////////////////

#define DUMMY_ID _SID.unused
#define _ID1 _SID._SID1
#define _ID2 _SID._SID2
#define _ID3 _SID._SID3
#define _ID4 _SID._SID4
#define _ID5 _SID._SID5

//�°ſ� ǰ��ü�踦	���� id
class TaggingRuleID
{
public:
	union{
		WORD _IID;
		struct{
			//WORD	unused:3;
			WORD	_SID3:4;	
			WORD	_SID2:8;
			WORD	_SID1:4;
		} _SID;
	};
	
	


	//TaggingRuleID(unsigned	int	ma_ID) :_ID1((ma_ID>>12)&0x000f), _ID2((ma_ID>>9)&0x0007), _ID3((ma_ID>>4)&0x001f), _ID4((ma_ID	)&0x000f) {}
	TaggingRuleID(WORD ma_ID) :_IID(ma_ID) {}
	TaggingRuleID() :_IID(0) {}
	TaggingRuleID(unsigned	int	ID1,	unsigned int ID2, unsigned	int	ID3) {_ID1=ID1; _ID2=ID2; _ID3=ID3;}
	TaggingRuleID(char* str){Set(str);};

	//"1.2.1.0 XXX..."�� ���°�	����
	// ���� �����δ� "TagPOSID.cpp�� �ϴܺκ����� �ȱ�"
	char*	Set(char*	str);
	operator unsigned	int()	const{return _IID;}
	bool IsSimilarWith(const TaggingRuleID	&otherID) const;
	bool IsSame(const	TaggingRuleID &otherID)	const;
	char* ToStr() const;

};






