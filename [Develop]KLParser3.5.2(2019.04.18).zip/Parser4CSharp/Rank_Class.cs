﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Parser4CSharp
{    
    class Rank_Class
    {
        //하나의 지배-의존 관계 저장
        List<Morpheme_Relation> Relation_information;
        Morpheme_Relation morpheme;

        //해당 Rank의 morpheme 정보 저장
        List<String[]> Morpheme_information;



        //하나의 Rank 정보를 받는다
        public List<Morpheme_Relation> Rank(List<String> rank)
        {            
            Morpheme_information = new List<string[]>();
            Relation_information = new List<Morpheme_Relation>();
            
            if (rank.Count() > 0)
            {


                //"#" 기준을 split
                for (int i = 0; i < rank.Count; i++)
                {
                    /* 
                     [0] = \t 숫자                     
                     [1] = id
                     [2] = 단어
                     [3] = 품사
                     [4] = 품사번호
                     */
                    String[] mor = new String[8];
                    if (rank[i].Contains("ROOT"))
                    {
                        mor[0] = "0";//tab 숫자
                        mor[1] = "0";//고유 ID
                        mor[2] = "ROOT";//단어
                        mor[3] = "ROOT";//품사
                        mor[4] = "0";//품사번호
                        mor[5] = "0";//weight 값
                        mor[6] = "0";//POS_weight 값
                        mor[7] = "0";//particle_weight 값
                    }
                    else
                    {
                        //한 어절을 # 기준으로 분리                
                        String[] rank_mor = rank[i].Split('#');

                        mor[0] = rank_mor[0];//tab 숫자
                        mor[1] = i.ToString();//id
                        mor[2] = rank_mor[1];//단어
                        mor[3] = rank_mor[2];//품사
                        mor[4] = rank_mor[3];//품사 번호                                       
                        mor[5] = rank_mor[5];//weight 값
                        mor[6] = rank_mor[6];//POS_weight 값
                        mor[7] = rank_mor[7];//particle_weight 값


                    }
                    //Rank 정보 전달
                    Morpheme_information.Add(mor);
                }                
            }
            return Relation(Morpheme_information);
        }


        public int POS_weight(List<String> rank)
        {

             int POS_Weight_Sum = 0;
            if (rank.Count() > 0)
            {
                //"#" 기준을 split
                for (int i = 0; i < rank.Count; i++)
                {
                    /* 
                     [0] = \t 숫자                     
                     [1] = id
                     [2] = 단어
                     [3] = 품사
                     [4] = 품사번호
                     */
                     //2019.01.11
                    String[] mor = new String[8];
                    if (rank[i].Contains("ROOT"))
                    {
                        mor[0] = "0";//tab 숫자
                        mor[1] = "0";//고유 ID
                        mor[2] = "ROOT";//단어
                        mor[3] = "ROOT";//품사
                        mor[4] = "0";//품사번호
                        mor[5] = "0";//weight 값
                        mor[6] = "0";//POS_weight 값
                        mor[7] = "0";//particle 값
                    }
                    else
                    {
                        //한 어절을 # 기준으로 분리                
                        String[] rank_mor = rank[i].Split('#');

                        mor[0] = rank_mor[0];//tab 숫자
                        mor[1] = i.ToString();//id
                        mor[2] = rank_mor[1];//단어
                        mor[3] = rank_mor[2];//품사
                        mor[4] = rank_mor[3];//품사 번호                                       
                        mor[5] = rank_mor[5];//weight 값
                        mor[6] = rank_mor[6];//POS_weight 값
                        mor[7] = rank_mor[7];//POS_weight 값

                        POS_Weight_Sum += Convert.ToInt32(mor[6]);
                    }
                   
                }
                
            }
            return POS_Weight_Sum;
        }

        public int Relation_weight(List<String> rank)
        {

            int R_Weight = 0;
            if (rank.Count() > 0)
            {
                //"#" 기준을 split
                for (int i = 0; i < rank.Count; i++)
                {
                    if (!rank[i].Contains("ROOT"))
                    {
                        // tab숫자 # id # 단어 # 품사 # 품사번호 # relation weight # pos weight
                        String[] rank_mor = rank[i].Split('#');
                        R_Weight += Convert.ToInt32(rank_mor[5]);
                        //break;
                    }

                }

            }
            return R_Weight;
        }
        public int Particle_weight(List<String> rank)
        {

            int R_Weight = 0;
            if (rank.Count() > 0)
            {
                //"#" 기준을 split
                for (int i = 0; i < rank.Count; i++)
                {
                    if (rank[i].Contains("온점"))
                    {
                        // tab숫자 # id # 단어 # 품사 # 품사번호 # relation weight # pos weight
                        String[] rank_mor = rank[i].Split('#');
                        R_Weight += Convert.ToInt32(rank_mor[7]);
                        break;
                    }

                }

            }
            return R_Weight;
        }





        //저장된 정보로 지배-의존 관계 파악
        public List<Morpheme_Relation> Relation(List<String[]> Morpheme_information)
        {
            //String[] str = { "0", "0-1", "ROOT", "ROOT", "0" };
            //Morpheme_information.Add(str);
            //문장 첫 어절부터 체크
            for (int i = Morpheme_information.Count - 1; i >= 0; i--)
            {
                //Root일 경우 패스
                if (Morpheme_information[i][2].Equals("ROOT"))
                    continue;

                //끝 어절부터 돌면서 지배-의존관계 확인
                else
                {
                    for (int j = i - 1; j >= 0; j--)
                    {

                        int gover = Int32.Parse(Morpheme_information[j][0]);
                        int dependency = Int32.Parse(Morpheme_information[i][0]);

                        /* 
                     [0] = \t 숫자                     
                     [1] = id
                     [2] = 단어
                     [3] = 품사
                     [4] = 품사번호
                     */

                        //Root-끝 어절 지배-의존 관계
                        if (gover == 0 && dependency == 1)
                        {
                            morpheme = new Morpheme_Relation();
                            morpheme.gover_set(
                               Morpheme_information[j][1], Morpheme_information[j][2], Morpheme_information[j][3], Int32.Parse(Morpheme_information[j][4]));
                            morpheme.depency_set(
                                Morpheme_information[i][1], Morpheme_information[i][2], Morpheme_information[i][3], Int32.Parse(Morpheme_information[i][4]));
                            morpheme.weight = Convert.ToInt32(Morpheme_information[j][5]);
                            morpheme.POS_Weight = Convert.ToInt32(Morpheme_information[j][6]);
                            Relation_information.Add(morpheme);
                            break;
                        }


                        // "\t" count가 하나 차이면 지배-의존 관계
                        else if (dependency - gover == 1)
                        {
                            //String gover_position, String gover_word, String gover_POS, int gover_POS_num
                            morpheme = new Morpheme_Relation();
                            morpheme.gover_set(
                                Morpheme_information[j][1], Morpheme_information[j][2], Morpheme_information[j][3], Int32.Parse(Morpheme_information[j][4]));
                            morpheme.depency_set(
                                Morpheme_information[i][1], Morpheme_information[i][2], Morpheme_information[i][3], Int32.Parse(Morpheme_information[i][4]));

                            morpheme.weight = Convert.ToInt32(Morpheme_information[j][5]);//격조사구 값
                            morpheme.POS_Weight = Convert.ToInt32(Morpheme_information[j][6]);//태깅 우선 순위 값
                            //지배-의존 관계 정보 전부 저장
                            Relation_information.Add(morpheme);
                            break;
                        }
                    }
                }
            }
            return Relation_information;

        }//end Relaction methode


        //Corpus 전용
        public List<Morpheme_Relation> Corpus_Rank(List<String> rank)
        {
            Morpheme_information = new List<string[]>();
            Relation_information = new List<Morpheme_Relation>();


            if (rank.Count() > 0)
            {


                //"#" 기준을 split
                for (int i = 0; i < rank.Count; i++)
                {
                    /* 
                     [0] = \t 숫자
                     [1] = ID
                     [2] = word
                     [3] = 품사                     
                     */

                    //Corpus용 2016.04.12 추가
                    String[] mor = new String[4];
                    if (rank[i].Contains("ROOT-ROOT"))
                    {
                        mor[0] = "0";//tab 숫자
                        mor[1] = "0";//고유 ID
                        mor[2] = "ROOT";//단어
                        mor[3] = "ROOT";//품사
                    }
                    if (rank[i].Contains("((+이다))"))
                    {
                        MatchCollection matches = Regex.Matches(rank[i], "\t");
                        int tab_count = matches.Count;
                        mor[0] = tab_count.ToString(); //tab 숫자
                        String remove_tab = rank[i].Replace('\t', ' ').Trim();

                        mor[1] = (i).ToString(); //고유 ID
                        mor[2] = "((+이다))";//단어
                        mor[3] = "지정사";//품사
                    }

                    else
                    {
                        MatchCollection matches = Regex.Matches(rank[i], "\t");
                        int tab_count = matches.Count;
                        mor[0] = tab_count.ToString(); //tab 숫자
                        String remove_tab = rank[i].Replace('\t', ' ').Trim();

                        mor[1] = (i).ToString(); //고유 ID

                        String[] split = remove_tab.Split('(');
                        mor[2] = split[0];//단어

                        String[] pos = split[1].Split('-');
                        mor[3] = pos[0];//품사
                        
                    }


                    //Rank 정보 전달
                    Morpheme_information.Add(mor);
                }
            }
            return Corpus_Relation(Morpheme_information);
        }


        public List<Morpheme_Relation> Corpus_Relation(List<String[]> Morpheme_information)
        {                       
            //문장 첫 어절부터 체크
            for (int i = Morpheme_information.Count-1; i >= 0; i--)
            {
                //Root일 경우 패스
                if (Morpheme_information[i][2].Equals("ROOT"))
                    continue;

                //다음 어절부터 돌면서 지배-의존관계 확인
                else
                {
                    for (int j = i - 1; j >=0; j--)
                    {

                        int gover = Int32.Parse(Morpheme_information[j][0]);
                        int dependency = Int32.Parse(Morpheme_information[i][0]);



                        //Root-끝 어절 지배-의존 관계
                        if (gover == 0 && dependency == 1)
                        {
                            morpheme = new Morpheme_Relation();
                            morpheme.Corpus_gover_set(
                               Morpheme_information[j][1], Morpheme_information[j][2], Morpheme_information[j][3]);
                            morpheme.Corpus_depency_set(
                                Morpheme_information[i][1], Morpheme_information[i][2], Morpheme_information[i][3]);
                            Relation_information.Add(morpheme);
                            break;
                        }


                        // "\t" count가 하나 차이면 지배-의존 관계
                        else if (dependency - gover == 1)
                        {
                            morpheme = new Morpheme_Relation();
                            morpheme.Corpus_gover_set(
                                Morpheme_information[j][1], Morpheme_information[j][2], Morpheme_information[j][3]);
                            morpheme.Corpus_depency_set(
                                Morpheme_information[i][1], Morpheme_information[i][2], Morpheme_information[i][3]);

                            //지배-의존 관계 정보 전부 저장
                            Relation_information.Add(morpheme);
                            break;
                        }
                    }
                }
            }
            return Relation_information;

        }//end Relaction methode

    }
}
