﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parser4CSharp
{
    public partial class Corret_Form : Form
    {
        public Corret_Form()
        {
            InitializeComponent();
        }

        public void Parse_Tree(int _Rank, List<List<Morpheme_Relation>> Parse_Tree)
        {
            if (_Rank > -1)
            {
                Corret_ParseTree_View.Nodes.Add(Parse_Tree[_Rank][Parse_Tree[_Rank].Count - 1].gover_position,
                    Parse_Tree[_Rank][Parse_Tree[_Rank].Count - 1].gover_word);




                //Tree 모양 출력          
                for (int i = Parse_Tree[_Rank].Count - 1; i >= 0; i--)//dependency loop           
                {
                    //Root-끝어절 연결
                    if (Parse_Tree[_Rank][i].gover_position.Equals(Parse_Tree[_Rank][Parse_Tree[_Rank].Count - 1].gover_position))
                    {
                        Corret_ParseTree_View.Nodes.Find(Parse_Tree[_Rank][Parse_Tree[_Rank].Count - 1].gover_position, true)[0].Nodes
                            .Add(Parse_Tree[_Rank][i].dependency_position,
                            Parse_Tree[_Rank][i].dependency_word + "(" + Parse_Tree[_Rank][i].dependency_POS + ")");

                        continue;
                    }
                    Corret_ParseTree_View.Nodes.Find(Parse_Tree[_Rank][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[_Rank][i].dependency_position,
                           Parse_Tree[_Rank][i].dependency_word + "(" + Parse_Tree[_Rank][i].dependency_POS + ")");

                }

                Corret_ParseTree_View.ExpandAll();
                Corret_ParseTree_View.SelectedNode = null;

            }

        }
        
    }

    
}
