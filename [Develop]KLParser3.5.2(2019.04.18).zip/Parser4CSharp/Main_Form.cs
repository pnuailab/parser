﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using managed_Pasrser;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;
using System.Threading;


namespace Parser4CSharp
{
    public partial class main_form : Form
    {

        Parser_CLR cl; //CLR 호출
        List<List<Morpheme_Relation>> Parse_Tree; //Parse Tree 정보 저장
        Stopwatch sw = new Stopwatch();//Parsing Time 체크

        Dictionary<String, int> Result_Sentence;

        List<List<String>> word_morpheme;

        int Rank_Number = 0;

        private ThreadStart _ts = null;                          //  ThreadStart 선언
        private Thread _t = null;                                  //  Thread 선언        
        public delegate void GridUpdateDelegate(String input_sentence, String Parsing_Tree_List, String rank);     //  델리게이트 선언


        bool Rank_DoubleClick_bool = false; //Rank 클릭 여부 체크
        int rank = 0; //Rank 값 저장


        //Parsing evaluation 결과
        int Rank = 0; //정답 Rank 체크

        int total_sentence = 0; //총 Pasing 문장
        int answer_sentence = 0; //정답이 존재하는 문장 수
        int no_answer_sentence = 0; //정답이 존재하지 않는 문장 수
        int rank_one = 0; //Rank 1인 정답 문장 수



        double total_parse_tree = 0;    //총 Parse Tree 수 합
        double total_rank_one = 0; //총 rank 합



        //Attachment scores 계산
        double total_as_count = 0; //총 Attachment 
        double correct_as_count = 0; //맞는 attachment 숫자


        /** 
         * 2016.06.26. 류재민 주석 추가
         * C# Interface 초기화 하는 부분
         */
        public main_form()
        {
            InitializeComponent();

            cl = new Parser_CLR();

            //초기화 
            Load_Dictionary(); //사전 로드
            Rank_dataGridView(); //Rank 초기화
            POS_dataGridView(); //POS 초기화
            GOV_dataGridView(); //GOV 초기화
            ParseTree_View.Nodes.Clear();//초기화
            Evaluation_dataGridView();//초기화

            //tab2
            Sentence_dataGridView();
            
            Verb_radioButton_True.Checked = true;          // 격조사 규칙
            SpellCheck_radioButtion_True.Checked = true;    // 맞춤법 교정
        }

        //필요한 사전 로드
        public void Load_Dictionary()
        {        
            cl.loadDLLDic();
            cl.loadModule();
        }

        private void ReLoad_Dic_Click(object sender, EventArgs e)
        {            
            //2016.12.02. 수정
            Load_Dictionary();
            //Load_Relation_Rule_Dic();
            sw.Reset();
            sw.Start();
            Create_ParseTree_function();
        }
        
        //Rank 출력 위한 gridview
        public void Rank_dataGridView()
        {
            Rank_GridView.ColumnCount = 1;
            Rank_GridView.Columns[0].Name = "Parse Tree";
            Rank_GridView.Columns[0].Width = 177;
            Rank_GridView.Columns[0].Frozen = true;
            Rank_GridView.ColumnHeadersDefaultCellStyle.Font = new Font("맑은고딕", 10);

            //cell 가운데 정렬
            this.Rank_GridView.Columns[0].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            Rank_GridView.AutoGenerateColumns = true;
            Rank_GridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Font 설정
            Rank_GridView.Columns[0].DefaultCellStyle.Font = new Font("맑은고딕", 11);

            //옵션
            Rank_GridView.AllowUserToAddRows = false;
            Rank_GridView.AllowUserToDeleteRows = false;
            Rank_GridView.ReadOnly = true;
            Rank_GridView.MultiSelect = false;
            Rank_GridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        }


        //POS 정보를 취한 gridview
        public void POS_dataGridView()
        {
            POS_GridView.ColumnCount = 3;
            POS_GridView.Columns[0].Name = "형태소";
            POS_GridView.Columns[0].Width = 140;

            POS_GridView.Columns[1].Name = "품사";
            POS_GridView.Columns[1].Width = 140;

            POS_GridView.Columns[2].Name = "세부정보";
            POS_GridView.Columns[2].Width = 95;



            POS_GridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            POS_GridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            POS_GridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Font 설정
            POS_GridView.Columns[0].DefaultCellStyle.Font = new Font("맑은고딕", 11);
            POS_GridView.Columns[1].DefaultCellStyle.Font = new Font("맑은고딕", 11);
            POS_GridView.Columns[2].DefaultCellStyle.Font = new Font("맑은고딕", 11);

            //cell 가운데 정렬
            this.POS_GridView.Columns[0].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POS_GridView.Columns[1].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POS_GridView.Columns[2].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            POS_GridView.AutoGenerateColumns = true;


            //옵션
            POS_GridView.AllowUserToAddRows = false;
            POS_GridView.AllowUserToDeleteRows = false;
            POS_GridView.ReadOnly = true;
            POS_GridView.MultiSelect = false;
            POS_GridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;


        }


        public void GOV_dataGridView()
        {
            GOV_GridView.ColumnCount = 3;
            GOV_GridView.Columns[0].Name = "형태소";
            GOV_GridView.Columns[0].Width = 140;

            GOV_GridView.Columns[1].Name = "품사";
            GOV_GridView.Columns[1].Width = 140;

            GOV_GridView.Columns[2].Name = "세부정보";
            GOV_GridView.Columns[2].Width = 95;



            GOV_GridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            GOV_GridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            GOV_GridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Font 설정
            GOV_GridView.Columns[0].DefaultCellStyle.Font = new Font("맑은고딕", 11);
            GOV_GridView.Columns[1].DefaultCellStyle.Font = new Font("맑은고딕", 11);
            GOV_GridView.Columns[2].DefaultCellStyle.Font = new Font("맑은고딕", 11);

            //cell 가운데 정렬
            this.GOV_GridView.Columns[0].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GOV_GridView.Columns[1].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GOV_GridView.Columns[2].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            GOV_GridView.AutoGenerateColumns = true;


            //옵션
            GOV_GridView.AllowUserToAddRows = false;
            GOV_GridView.AllowUserToDeleteRows = false;
            GOV_GridView.ReadOnly = true;
            GOV_GridView.MultiSelect = false;
            GOV_GridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;


        }





        //Parse Tree 생성 버튼
        private void Create_ParseTree_Click(object sender, EventArgs e)
        {
            sw.Reset();
            sw.Start();

            Create_ParseTree_function();
        }

        //Parse Tree 생성 Enter
        private void Input_Sentence_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {

                sw.Start();
                Create_ParseTree_function();

            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            Keys key = keyData & ~(Keys.Control);

            switch(key)
            {
                case Keys.F:    // 파스트리 내 찾기
                    if((keyData & Keys.Control) != 0)
                    {
                        // 파스트리 내 일정한 패턴을 찾는다.
                        SearchInParseTree();
                    }
                    break;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        public void SearchInParseTree()
        {
            RegistryKey checkKey = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\BCD_Parser", true);
            if(checkKey == null)
            {
                MessageBox.Show("문장을 먼저 입력해 주세요.", "검색 오류", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                Search_Form sf = new Search_Form(this);
                sf.Show();
            }
        }

        /* Parse Tree 생성 버튼 클릭 or Enter 했을 때 실행되는 함수 */
        public void Create_ParseTree_function()
        {
            Parsing_Time.Text = "Paing Time :";

            String str = Input_Sentence.Text.ToString();
            int length = str.Length - 1;
            String end = str.Substring(length);
            int error;
            //온점이 없을 경우 추가
            if (end.Equals("다"))
                str += ".";


            //Parser 생성
            error = cl.getParseTree(str, true, SpellCheck_radioButtion_True.Checked);

            // Core 측에서 에러 발생 시 에러 메시지 출력
            switch (error)
            {
                case -2:    // 형태소 분석 후보 모두 제거
                    System.Windows.Forms.MessageBox.Show(" 파스트리 생성 불가[Error:-2]\n    : 형태소 분석 후보가 없는 어절 존재", "전처리 오류", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                case -1:    // 전처리 문제 (isAbleToParse == false 인 경우)
                    System.Windows.Forms.MessageBox.Show(" 파스트리 생성 불가[Error:-1]\n    : isAbletoParse = false", "전처리 오류", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                case 0:     // 에지 생성 안되는 경우 (Parse Tree 0개)
                    System.Windows.Forms.MessageBox.Show(" 파스트리 생성 불가[Error:0]\n   : 에지 생성 불가", "파싱 오류", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
            }

            //Sentence정보 전달
            Sentence_Class sc = new Sentence_Class();
            Parse_Tree = new List<List<Morpheme_Relation>>();
            word_morpheme = new List<List<string>>();


            //레지스트리에서 값 읽기
            RegistryKey key = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\BCD_Parser");
            String reg_Sentence = key.GetValue("Sentence").ToString();//문장



            //Tree 정보 저장 (문장 전달)
            Parse_Tree = sc.input(reg_Sentence);
            word_morpheme = sc.get_sentence_information();
            List<List<Morpheme_Relation>> Parsing_Tree_List = new List<List<Morpheme_Relation>>();
            List<List<Morpheme_Relation>> Answer_Tree_List = Parse_Tree;
            double value = 0;
            for(int kkk = 0; kkk < Parse_Tree.Count(); kkk++)
            {
                value = Parse_Tree[kkk][0].rule_Weight;
            }
     
            //Length_Sum(ref Parse_Tree);//2018.10.09 김성태 주석 처리
            //Custom_Predicate_Rule(ref Parse_Tree);//2018.07.11. 김성태 추가
            //particle2(ref Parse_Tree);//격조사구 추가 (Tree[i][0]만 사용)
            //particle(ref Parse_Tree);// 2018.08.13. 추가 김성태
            //Gwan_Near_Myung(ref Parse_Tree);//2018.07.11. 김성태 추가
            //Bojosa_Jijungsa(ref Parse_Tree); // 2018.07.12. 추가 김성태
            Sorting(ref Parse_Tree);    //weight 값으로 Sorting            
            Distance_Sorting(ref Parse_Tree);   // 2017.01.03. 추가 (같은 weight에 대해 거리 짧은 순 정렬)    

            //초기화
            Rank_GridView.Rows.Clear();//행 초기화
            POS_GridView.Rows.Clear();
            ParseTree_View.Nodes.Clear();//초기화

            //Rank 출력
            Rank_Write();
            Show_ParseTree(0);
            Parsing_Weight.Text = "Rank Weight : " + Parse_Tree[0][0].total_weight;
            
            label_POSWeight.Text = "POS : " + Parse_Tree[0][0].POS_Weight;
            label_RelationWeight.Text = "Relation : " + Parse_Tree[0][0].rule_Weight;
            label_ParticleWeight.Text = "Particle : " + Parse_Tree[0][0].weight;
            label_lengthSum.Text = "Length : " + Parse_Tree[0][0].Relation_length;  // 2017.01.03. 류재민
        }

        //저장 버튼 클릭 이벤트
        private void Save_Button_Click(object sender, EventArgs e)
        {
            String save_path = "..\\RESULT\\";

            if (Rank_DoubleClick_bool && Parse_Tree != null)
            {
                String save_sentence = Input_Sentence.Text.ToString().Replace('.', ' ').Trim();
                //save_sentence = save_sentence.Replace('?', ' ').Trim();

                // 2016.10.17. 파일명으로 쓸 수 없는 문자 처리
                // \ / : * ? " < > | 는 파일명으로 쓰지 못함
                save_sentence = save_sentence.Replace('\\', ' ');
                save_sentence = save_sentence.Replace('/', ' ');
                save_sentence = save_sentence.Replace(':', ' ');
                save_sentence = save_sentence.Replace('*', ' ');
                save_sentence = save_sentence.Replace('?', ' ');
                save_sentence = save_sentence.Replace('\"', '\'');
                save_sentence = save_sentence.Replace('<', '(');
                save_sentence = save_sentence.Replace('>', ')');
                save_sentence = save_sentence.Replace('|', ' ');

                using (System.IO.StreamWriter file = new System.IO.StreamWriter(save_path + save_sentence + ".txt", true))
                {
                    file.WriteLine("<Sentence >" + Input_Sentence.Text.ToString());
                    for (int i = 0; i < Parse_Tree[rank].Count; i++)
                    {
                        file.WriteLine(Parse_Tree[rank][i].dependency_position + "\t"
                            + Parse_Tree[rank][i].dependency_word + "#" + Parse_Tree[rank][i].dependency_POS + "\t\t" +
                            Parse_Tree[rank][i].gover_position);
                    }
                    file.WriteLine("\n");
                }


                Corret_Form cf = new Corret_Form();
                cf.Parse_Tree(rank, Parse_Tree);
                cf.Show();
                
            }

            else
            {
                MessageBox.Show("정답트리를 선택해 주세요.");
            }
            


        }





        //Rank 출력
        //Parse Tree 수 출력
        //Parsing Time 출력
        public void Rank_Write()
        {
            sw.Stop();
            for (int i = 0; i < Parse_Tree.Count; i++)
            {
                int rank_num = i + 1;
                string[] row1 = new string[] { "[Rank " + rank_num.ToString() + "]" };
                Rank_GridView.Rows.Add(row1);
            }
            double seconds = sw.Elapsed.TotalMilliseconds / 1000;
            Rank_Count.Text = "Parse Tree : " + Parse_Tree.Count.ToString() + "개";
            Parsing_Time.Text = "Pasing Time : " + seconds.ToString("F3") + " sec";            
        }


        private void Show_ParseTree(int _rank)
        {
            Rank_Number = _rank; //Rank 등수
            ParseTree_View.Nodes.Clear();//초기화
            POS_GridView.Rows.Clear();
            GOV_GridView.Rows.Clear();

            //Tree 이미지 추가 
            //ImageList imgList = new ImageList();
            // imgList.Images.Add(Bitmap.FromFile("..\\box.ico"));            
            //ParseTree_View.ImageList = imgList;

            if (Rank_Number > -1)
            {
                ParseTree_View.Nodes.Add(Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_position,
                    Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_word);




                //Tree 모양 출력          
                for (int i = Parse_Tree[Rank_Number].Count - 1; i >= 0; i--)//dependency loop           
                {
                    //Root-끝어절 연결
                    if (Parse_Tree[Rank_Number][i].gover_position.Equals(Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_position))
                    {
                        ParseTree_View.Nodes.Find(Parse_Tree[Rank_Number][Parse_Tree[Rank_Number].Count - 1].gover_position, true)[0].Nodes
                            .Add(Parse_Tree[Rank_Number][i].dependency_position,
                            Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ")");

                        continue;
                    }
                    ParseTree_View.Nodes.Find(Parse_Tree[Rank_Number][i].gover_position, true)[0].Nodes
                           .Add(Parse_Tree[Rank_Number][i].dependency_position,
                           Parse_Tree[Rank_Number][i].dependency_word + "(" + Parse_Tree[Rank_Number][i].dependency_POS + ")");

                }
                ParseTree_View.ExpandAll();
                Parsing_Weight.Text = "Rank Weight : " + Parse_Tree[_rank][0].total_weight;

                label_POSWeight.Text = "POS : " + Parse_Tree[_rank][0].POS_Weight;
                label_RelationWeight.Text = "Relation : " + Parse_Tree[_rank][0].rule_Weight;
                label_ParticleWeight.Text = "Particle : " + Parse_Tree[_rank][0].weight;
                label_lengthSum.Text = "Length : " + Parse_Tree[_rank][0].Relation_length;  // 2017.01.03. 류재민
            }


            // 2016.10.19. 비문복원, 에지연결오류 표시
            // 범위로 표현하지만, C++과 C#에서 Error code로 넣어야 할듯!
            if(Parse_Tree[Rank_Number][0].rule_Weight > 900 && Parse_Tree[Rank_Number][0].rule_Weight < 1100)
            {
                ParseTree_View.Nodes[0].Text = "ROOT : 비문 복원";
                ParseTree_View.Nodes[0].ForeColor = Color.White;
                ParseTree_View.Nodes[0].BackColor = Color.Crimson;
            }
            else if(Parse_Tree[Rank_Number][0].rule_Weight > 9900 && Parse_Tree[Rank_Number][0].rule_Weight < 10100)
            {
                ParseTree_View.Nodes[0].Text = "ROOT : 에지 연결 오류";
                ParseTree_View.Nodes[0].ForeColor = Color.White;
                ParseTree_View.Nodes[0].BackColor = Color.Indigo;
            }

        }



        //Rank Double 클릭시 이벤트
        private void Rank_DoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Parse_Tree == null)
                return;

            rank = e.RowIndex;
            //전역 변수
            Rank_DoubleClick_bool = true;

            Show_ParseTree(e.RowIndex);
        }


        //Rank 클릭시 이벤트
        private void Rank_Click(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (Parse_Tree == null)
                {
                    return;
                }

                rank = e.RowIndex;

                //전역 변수
                Rank_DoubleClick_bool = true;

                Show_ParseTree(e.RowIndex);
            }
            catch
            {
                MessageBox.Show("올바른 파스트리를 선택해 주세요.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }



        //Rank 방향키 이동 이벤트        
        private void Rank_GridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)38 || e.KeyValue == (char)40)
            {
                //전역 변수
                Rank_DoubleClick_bool = true;
                rank = this.Rank_GridView.Rows[this.Rank_GridView.CurrentCellAddress.Y].Cells[0].RowIndex;
                Show_ParseTree(this.Rank_GridView.Rows[this.Rank_GridView.CurrentCellAddress.Y].Cells[0].RowIndex);

            }

        }



        //ParseTree Node 클릭시 이벤트
        private void ParseTree_View_Click(object sender, TreeNodeMouseClickEventArgs e)
        {
            POS_GridView.Rows.Clear();
            GOV_GridView.Rows.Clear();

            String position = e.Node.Name;

            String word = "";
            String POS = "";
            int POS_NUM = 0;

            String gov_word = "";
            String gov_POS = "";
            int gov_POS_NUM = 0;

            for (int i = 0; i < Parse_Tree[Rank_Number].Count; i++)
            {
                if (Parse_Tree[Rank_Number][i].dependency_position.Equals(position))
                {
                    word = Parse_Tree[Rank_Number][i].dependency_word;
                    POS = Parse_Tree[Rank_Number][i].dependency_POS;
                    POS_NUM = Parse_Tree[Rank_Number][i].dependency_POS_num;

                    gov_word = Parse_Tree[Rank_Number][i].gover_word;
                    gov_POS = Parse_Tree[Rank_Number][i].gover_POS;
                    gov_POS_NUM = Parse_Tree[Rank_Number][i].gover_POS_num;
                    break;
                }
            }

            string[] row1 = new string[] { word, POS, POS_NUM.ToString() };
            string[] row2 = new string[] { gov_word, gov_POS, gov_POS_NUM.ToString() };


            POS_GridView.Rows.Add(row1);
            GOV_GridView.Rows.Add(row2);
        }








        //tab3  ----> Evaluation 루틴

        //corpus 생성 버튼
        private void button2_Click(object sender, EventArgs e)
        {
            /*return;
            String result_path = "C:\\KLParser\\";
            System.IO.StreamWriter write = new System.IO.StreamWriter("..\\Corpus\\정답문장_Corpus(2016.04.16).txt");


            //정답문장이 존재하는 문장만을 추출하기 위해 추가
            //파일 읽기 시작
            List<String> list = new List<string>();
            String line;
            System.IO.StreamReader fi = new System.IO.StreamReader("..\\Corpus\\정답문장(2016.04.16).txt", System.Text.Encoding.UTF8);
            while ((line = fi.ReadLine()) != null)
            {
                list.Add(line);
            }
            fi.Close();



            DirectoryInfo dir = new DirectoryInfo(result_path);
            System.IO.DirectoryInfo[] directory = dir.GetDirectories("*.*", SearchOption.AllDirectories);
            int id = 1;
            foreach (var direc in directory)
            {
                String path = "C:\\KLParser\\" + direc;
                DirectoryInfo d = new DirectoryInfo(path);
                System.IO.FileInfo[] files = d.GetFiles("*.*", SearchOption.AllDirectories);
                foreach (System.IO.FileInfo file in files)
                {
                    Sentence_Class sc = new Sentence_Class();
                    Parse_Tree = new List<List<Morpheme_Relation>>();

                    String file_path = path + "\\" + file;
                    //Tree 정보 저장
                    Parse_Tree = sc.corpus_input(direc.ToString(), file_path);

                    String on = Parse_Tree[0][Parse_Tree[0].Count - 1].dependency_POS;


                    int length = direc.ToString().Length - 1;
                    String end = direc.ToString().Substring(length);


                    String sentence_on = direc.ToString(); //문장 저장
                    if (on.Equals("온점"))
                    {
                        sentence_on += ".";
                    }
                    if (on.Equals("물음표"))
                    {
                        sentence_on += "?";
                    }

                    //추가 제약사항
                    if (sentence_on.Contains('\'') || sentence_on.Contains('"') || sentence_on.Contains('(') || sentence_on.Contains(')') || sentence_on.Contains('#')
                        || sentence_on.Contains('_') || Parse_Tree[0][0].dependency_POS.Equals("기타기호") || sentence_on.Contains('='))
                    {
                        continue;
                    }

                    //추가 제약사항
                    if (!end.Equals("다"))
                    {
                        continue;
                    }

                    //온점이 있는 문장만 저장
                    if (on.Equals("온점") || on.Equals("물음표"))
                    {


                        for (int x = 0; x < list.Count; x++)
                        {

                            if (sentence_on.Equals(list[x]))
                            {

                                //문장
                                write.WriteLine("<Sentence " + id.ToString() + ">" + sentence_on);
                                id++;

                                for (int i = 0; i < Parse_Tree.Count; i++)
                                {
                                    int count_id = 0;
                                    for (int j = 0; j < Parse_Tree[i].Count; j++)
                                    {
                                        write.WriteLine(Parse_Tree[i][j].dependency_position + "\t" + Parse_Tree[i][j].dependency_word + "#" + Parse_Tree[i][j].dependency_POS
                                            + "\t\t\t" + Parse_Tree[i][j].gover_position);
                                        count_id++;
                                    }//한 어절                        
                                }
                                write.WriteLine("\n");
                            }
                        }


                    }

                }//end file                
            }
            MessageBox.Show("완료");












            */
        }







        //Evaluation Gridview 초기화
        public void Evaluation_dataGridView()
        {
            Evaluation_Grid.ColumnCount = 3;
            Evaluation_Grid.Columns[0].Name = "문장";
            Evaluation_Grid.Columns[0].Width = 554;
            Evaluation_Grid.Columns[0].Frozen = true;
            Evaluation_Grid.ColumnHeadersDefaultCellStyle.Font = new Font("맑은고딕", 10);

            Evaluation_Grid.Columns[1].Name = "Tree 수";
            Evaluation_Grid.Columns[1].Width = 100;
            Evaluation_Grid.Columns[1].Frozen = true;


            Evaluation_Grid.Columns[2].Name = "정답 순위";
            Evaluation_Grid.Columns[2].Width = 100;
            Evaluation_Grid.Columns[2].Frozen = true;


            //cell 가운데 정렬
            //this.Evaluation_Grid.Columns[1].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            Evaluation_Grid.AutoGenerateColumns = true;
            Evaluation_Grid.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //this.Evaluation_Grid.Columns[2].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            Evaluation_Grid.AutoGenerateColumns = true;
            Evaluation_Grid.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //cell 가운데 정렬
            Evaluation_Grid.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Evaluation_Grid.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Evaluation_Grid.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;


            //Font 설정
            //Sentence_GridView.Columns[0].DefaultCellStyle.Font = new Font("맑은고딕", 11);

            //this.Evaluation_Grid.Columns[0].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //this.Evaluation_Grid.Columns[1].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //this.Evaluation_Grid.Columns[2].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // Evaluation_Grid.AutoGenerateColumns = true;





            //옵션
            Evaluation_Grid.AllowUserToAddRows = false;
            Evaluation_Grid.AllowUserToDeleteRows = false;
            Evaluation_Grid.ReadOnly = true;
            Evaluation_Grid.MultiSelect = false;
            Evaluation_Grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        }


        private void Load_Corpus_Click(object sender, EventArgs e)
        {
            OpenFileDialog OpenFileDialog = new OpenFileDialog();
            OpenFileDialog.Filter = "All files(*.*)|*.*";
            OpenFileDialog.FilterIndex = 1;
            OpenFileDialog.ShowDialog();

            if (OpenFileDialog.FileName.Length > 0)
            {
                this.Corpus_Path.Text = ""; //txtbox에 경로 초기화
                foreach (String filename in OpenFileDialog.FileNames)
                {
                    this.Corpus_Path.Text = filename;
                }
            }

        }
        delegate void CrossThreadSafetySetText(Control ctl, String text);


        private void CSafeSetText(Control ctl, String text)
        {

            /*
             * InvokeRequired 속성 (Control.InvokeRequired, MSDN)
             *   짧게 말해서, 이 컨트롤이 만들어진 스레드와 현재의 스레드가 달라서
             *   컨트롤에서 스레드를 만들어야 하는지를 나타내는 속성입니다.  
             * 
             * InvokeRequired 속성의 값이 참이면, 컨트롤에서 스레드를 만들어 텍스트를 변경하고,
             * 그렇지 않은 경우에는 그냥 변경해도 아무 오류가 없기 때문에 텍스트를 변경합니다.
             */
            if (ctl.InvokeRequired)
                ctl.Invoke(new CrossThreadSafetySetText(CSafeSetText), ctl, text);
            else
                ctl.Text = text;
        }
        
        private void Run_evaluation_Click(object sender, EventArgs e)
        {
            Evaluation_Grid.Rows.Clear();
            Result_Sentence = new Dictionary<string, int>();

            Result_Sentence.Clear();

            _ts = new ThreadStart(Run);
            _t = new Thread(_ts);
            _t.Start();
        }

        public void Run()
        {
            total_sentence = 0; //총 Pasing 문장
            answer_sentence = 0; //정답이 존재하는 문장 수
            no_answer_sentence = 0; //정답이 존재하지 않는 문장 수
            rank_one = 0; //Rank 1인 정답 문장 수
            total_parse_tree = 0;
            total_rank_one = 0;

            total_as_count = 0; //총 Attachment 
            correct_as_count = 0; //맞는 attachment 숫자

            String input_sentence = "";
            if (this.Corpus_Path.Text != "")
            {
                string contents = File.ReadAllText(Corpus_Path.Text);
                String[] senten = contents.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

                List<Morpheme_Relation> Relation = null;
                List<List<Morpheme_Relation>> Tree = null;
                Relation = new List<Morpheme_Relation>();
                Tree = new List<List<Morpheme_Relation>>();

                int error = 0;

                List<int> numOfTrees = null;
                numOfTrees = new List<int>();

                foreach (var txt in senten)
                {

                    if (txt.Contains("<Sentence"))
                    {
                        String[] str = txt.Split('>');
                        if (Tree != null && Relation != null)
                        {
                            //문장 저장
                            Tree.Add(Relation);
                            if(!(Tree.Count == 1 && Tree[0].Count == 0))
                                Compare_ParseTree(Tree, input_sentence);//Relation 모두 저장 후 Compare 함수 호출
                            // 트리 삭제

                        }

                        input_sentence = str[1];

                        //하나의 Sentence의 Parse Tree 생성
                        //error = cl.getParseTree(str[1], true);
                        // 2017.08.30. Speller On 으로 분석
                        error = cl.getParseTree(str[1], true, true);
                        if(error == 0)
                        {
                            int i = 0;
                        }
                        numOfTrees.Add(error);

                        //초기화
                        Relation.Clear();
                        Tree.Clear();
                        
                        //Relation = new List<Morpheme_Relation>();
                        //Tree = new List<List<Morpheme_Relation>>();
                    }

                    else if (txt.Contains("<END>"))
                    {
                        Tree.Add(Relation);
                        Compare_ParseTree(Tree, input_sentence);//Relation 모두 저장 후 Compare 함수 호출
                        //결과 값 출력
                        double t_p_t = total_parse_tree / total_sentence;
                        double t_r_on = total_rank_one / total_sentence;
                        double att_score = correct_as_count / total_as_count * 100;
                        CheckForIllegalCrossThreadCalls = false;
                        Total_RESULT_BOX.Text = "평균 Parse Tree 수 : " + t_p_t.ToString("F2") + "\n"
                                                + "평균 Rank 순위 : " + t_r_on.ToString("F2") + "\n"
                                                + "UAS : " + att_score.ToString("F2") + "%\n";
                        print_result();
                        print_resultWIthNumOfTrees(numOfTrees);
                        break;
                    }

                    else
                    {
                        if (error > 0)
                        {
                            //mor[0] = ID, mor[1] = 단어/품사, mor[4] = 지배소 ID
                            String[] mor = txt.Split(new char[] { '\t', '\t' });

                            // [1]단어 [2]품사
                            String[] depen = mor[1].Split('#');

                            String[] gover = mor[3].Split('#');

                            Morpheme_Relation mr = new Morpheme_Relation();
                            mr.dependency_position = mor[0];
                            mr.dependency_word = depen[0];
                            mr.dependency_POS = depen[1];
                            mr.dependency_POS_num = 0;

                            /////////////////////////////////
                            mr.gover_position = mor[3];//수정 3,4
                            mr.gover_POS_num = 0;
                            Relation.Add(mr);
                        }



                    }
                }//end read            
                
            }

            else
                MessageBox.Show("파일을 불러오세요.");


            _t.Abort();         //  쓰레드 종료

        }



        public void Compare_ParseTree(List<List<Morpheme_Relation>> Tree, String input_sentence)
        {
            List<List<Morpheme_Relation>> Parsing_Tree_List = new List<List<Morpheme_Relation>>();
            List<List<Morpheme_Relation>> Answer_Tree_List = Tree;

            //Sentence정보 전달
            Sentence_Class sc = new Sentence_Class();
            word_morpheme = new List<List<string>>();

            //Tree 정보 저장 (문장 전달)
            Parsing_Tree_List = sc.input(input_sentence);
            word_morpheme = sc.get_sentence_information();


            // 2017.08.30.
            // Create_ParseTree_function()과 동기화를 위해 for문 추가
            double value = 0;
            for (int kkk = 0; kkk < Parsing_Tree_List.Count(); kkk++)
            {
                value = Parsing_Tree_List[kkk][0].rule_Weight;
            }
            
            //option

            //Frame 정보 추가                        
            //Frame_information(ref Parsing_Tree_List, input_sentence);//Frame 정보 추가

            //Rule(ref Parsing_Tree_List);

            //Custom_Predicate_Rule(ref Parsing_Tree_List);

            // 거리가중치
            //Length_Sum(ref Parsing_Tree_List); //2018.10.09 김성태 주석처리

           // Custom_Predicate_Rule(ref Parsing_Tree_List);//규칙 추가
          //  Bojosa_Jijungsa(ref Parsing_Tree_List); // 2016.08.04. 추가
          //  Gwan_Near_Myung(ref Parsing_Tree_List); // 2016.07.22 추가
           // particle2(ref Parsing_Tree_List);

            //weight 값으로 Sorting
            Sorting(ref Parsing_Tree_List);
            Distance_Sorting(ref Parsing_Tree_List);    // 2017.01.04. 류재민


            //2016.05.04 추가
            /*
            for (int i = 0; i < Parsing_Tree_List.Count; i++)//전체 Parse Tree 수만큼 loop
            {
                for (int j = 0; j < Parsing_Tree_List[i].Count; j++)// 각 Rank의 어절 수만큼 loop
                {
                    if (j < Answer_Tree_List[0].Count)
                    {
                        if (Parsing_Tree_List[i][j].dependency_POS != Answer_Tree_List[0][j].dependency_POS)
                        {
                            //Parsing_Tree_List.Remove(Parsing_Tree_List[i]);
                            Parsing_Tree_List[i].Clear();
                            continue;
                        }
                    }
                }
                for (int j = 0; j < Parsing_Tree_List[i].Count; j++)// 각 Rank의 어절 수만큼 loop
                {
                    if (Parsing_Tree_List[i].Count() == 0)
                    {
                        Parsing_Tree_List.Remove(Parsing_Tree_List[i]);
                        --j;
                    }
                }
            }
                  

            */





            Rank = 0;
            int number = 0;
            int Rank1_UAS = 0;
            bool answer_check = false;
            //정답 Tree와 Pasing 된 Tree 비교
            for (int i = 0; i < Parsing_Tree_List.Count; i++)//전체 Parse Tree 수만큼 loop
            {
                number = 0;
                for (int j = 0; j < Parsing_Tree_List[i].Count; j++)// 각 Rank의 어절 수만큼 loop
                {
                    if (j < Answer_Tree_List[0].Count)
                    {
                        //Q1,Q2 명사일 경우 어디든 연결되어도 정답
                        if (Parsing_Tree_List[i][j].dependency_word.Contains("Q1"))
                            answer_check = true;

                        if (i == 0)//Rank 1일때 체크 Attachment score 체크
                        {
                            if (Parsing_Tree_List[i][j].dependency_word.Contains("Q1"))
                                correct_as_count++; //맞을 경우

                            if (Parsing_Tree_List[i][j].dependency_position == Answer_Tree_List[0][j].dependency_position &&
                             Parsing_Tree_List[i][j].dependency_word == Answer_Tree_List[0][j].dependency_word &&
                             Parsing_Tree_List[i][j].gover_position == Answer_Tree_List[0][j].gover_position)
                            {
                                correct_as_count++; //맞을 경우
                            }
                        }



                        if (Parsing_Tree_List[i][j].dependency_position == Answer_Tree_List[0][j].dependency_position &&
                            Parsing_Tree_List[i][j].dependency_word == Answer_Tree_List[0][j].dependency_word &&
                            Parsing_Tree_List[i][j].gover_position == Answer_Tree_List[0][j].gover_position)
                        {
                            number++;
                            //answer_check = true;
                        }

                        else
                        {
                            //answer_check = false;
                            //break;
                        }

                    }
                }//어절 수 만큼 Loop

                //if (answer_check)
                //Rank = i + 1;


                if (i == 0)//Rank 1일때 체크 total Attachment 체크
                {
                    total_as_count += Parsing_Tree_List[i].Count;
                    Rank1_UAS = number;
                }

                if (Answer_Tree_List[0].Count == number)
                {
                    Rank = i + 1;
                    break;
                }


            }//하나의 문장 끝


            //결과 값
            if (Rank > 0)
                answer_sentence++;
            if (Rank == 0)
                no_answer_sentence++;
            if (Rank == 1)
                rank_one++;

            //총 문장
            total_sentence++;

            if (Answer_Tree_List[0].Count != Parsing_Tree_List[0].Count)
            {
                FileStream fsError = new FileStream("형태소오류_정답.txt", FileMode.Append, FileAccess.Write);
                StreamWriter swError = new StreamWriter(fsError, System.Text.Encoding.Default);
                // 형태소 오류_정답
                swError.WriteLine("<Sentence >" + input_sentence);
                for (int i = 0; i < Answer_Tree_List[0].Count; i++)
                {
                    swError.WriteLine(Answer_Tree_List[0][i].dependency_position + "\t"
                        + Answer_Tree_List[0][i].dependency_word + "#" + Answer_Tree_List[0][i].dependency_POS + "\t\t" +
                        Answer_Tree_List[0][i].gover_position);
                }
                swError.WriteLine("\n");
                swError.Flush();
                swError.Close();
                fsError.Close();

                FileStream fsError2 = new FileStream("형태소오류_1등.txt", FileMode.Append, FileAccess.Write);
                StreamWriter swError2 = new StreamWriter(fsError2, System.Text.Encoding.Default);
                // 형태소 오류_1등
                swError2.WriteLine("<Sentence >" + input_sentence);
                for (int i = 0; i < Parsing_Tree_List[0].Count; i++)
                {
                    swError2.WriteLine(Parsing_Tree_List[0][i].dependency_position + "\t"
                        + Parsing_Tree_List[0][i].dependency_word + "#" + Parsing_Tree_List[0][i].dependency_POS + "\t\t" +
                        Parsing_Tree_List[0][i].gover_position);
                }
                swError2.WriteLine("\n");
                swError2.Flush();
                swError2.Close();
                fsError2.Close();
            }

            /* 1등 결과 */
            FileStream fsError3 = new FileStream("1등_결과.txt", FileMode.Append, FileAccess.Write);
            StreamWriter swError3 = new StreamWriter(fsError3, System.Text.Encoding.Default);
            swError3.WriteLine("<Sentence >" + input_sentence);
            for (int i = 0; i < Parsing_Tree_List[0].Count; i++)
            {
                swError3.WriteLine(Parsing_Tree_List[0][i].dependency_position + "\t"
                    + Parsing_Tree_List[0][i].dependency_word + "#" + Parsing_Tree_List[0][i].dependency_POS + "\t\t" +
                    Parsing_Tree_List[0][i].gover_position);
            }
            swError3.WriteLine("\n");
            swError3.Flush();
            swError3.Close();
            fsError3.Close();


            // 문장-답안에지수-정답에지수
            FileStream fs = new FileStream("_Result_Of_Evaluation.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);
            //sw.WriteLine(input_sentence + "\t" + Answer_Tree_List[0].Count + "\t" + Rank1_UAS);
            // 마지막 형태소는 항상 Root에 가니까 1 추가
            sw.WriteLine(input_sentence + "\t" + Answer_Tree_List[0].Count + "\t" + Rank1_UAS);
            sw.Flush();
            sw.Close();
            fs.Close();

            //  작업 쓰레드에서 안전한 방식으로 컨트롤을 호출하도록 해야함.
            GridUpdateDelegate td = new GridUpdateDelegate(Evaluation_Grid_Data);
            if (_t.IsAlive.Equals(true))
            {
                this.Invoke(td, new object[] { input_sentence, Parsing_Tree_List.Count.ToString(), Rank.ToString() });
                Thread.Sleep(100);
            }

            // 삭제
            Parsing_Tree_List.Clear();


        }



        //Evaluation Grid를 실시간 업데이트 한다.
        public void Evaluation_Grid_Data(String input_sentence, String Parsing_Tree_List, String rank)
        {
            total_parse_tree += Convert.ToDouble(Parsing_Tree_List); //parse tree 숫자 합
            total_rank_one += Convert.ToDouble(rank); //Rank 총 합


            string[] row1 = new string[] { input_sentence, Parsing_Tree_List, rank };

            Result_Sentence.Add(input_sentence, Convert.ToInt32(rank));

            Evaluation_Grid.Rows.Add(row1);
            log.Text = input_sentence;

            result_box.Text = "총 파싱 문장 : " + total_sentence + "\n" +
                          "정답이 존재하는 문장 수 : " + answer_sentence + "\n" +
                          "정답이 존재하지 않는 문장 수 : " + no_answer_sentence + "\n" +
                          "Rank 1이 정답인 문장 수 : " + rank_one + "\n";

        }



        //Thread Stop
        private void stop_Click(object sender, EventArgs e)
        {
            if (_t != null)
                _t.Abort();         //  쓰레드 종료

            //결과 값 출력
            double t_p_t = total_parse_tree / total_sentence;
            double t_r_on = total_rank_one / total_sentence;
            double att_score = correct_as_count / total_as_count * 100;
            Total_RESULT_BOX.Text = "평균 Parse Tree 수 : " + t_p_t.ToString("F2") + "\n"
                                    + "평균 Rank 순위 : " + t_r_on.ToString("F2") + "\n"
                                    + "UAS : " + att_score.ToString("F2") + "%\n";

        }



        private void Evaluation_Sentence_Parsing(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                String Cell_Sentence = Evaluation_Grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();

                this.tab.SelectedIndex = 0;
                Input_Sentence.Text = Cell_Sentence;
                this.Create_ParseTree.PerformClick();
                Show_ParseTree(0);
            }

        }







        /////////////////////////Option 정보 추가/////////////////////////
        

        //Rank Sorting
        public void Sorting(ref List<List<Morpheme_Relation>> Tree)
        {
            if (Tree.Count() == 1)
            {
                Tree[0][0].total_weight = Tree[0][0].POS_Weight + Tree[0][0].rule_Weight + Tree[0][0].weight;
            }

            List<Morpheme_Relation> p1, p2;
            List<Morpheme_Relation> tmp;

            // 2016.10.22. 류재민
            // Quick Sort → Boubble Sort : Because, Quick Sort is unstable.
            for (int i = 0; i < Tree.Count; i++)
            {
                for(int j = 0; j < Tree.Count; j++)
                {
                    p1 = Tree[i];
                    p2 = Tree[j];
                                        
                    // 형태소분석 가중치(Tagger [rw]), Argument Info 가중치, C#쪽 격조사구-동사 가중치
                    double p1_POS = p1[0].POS_Weight, p1_Relation = p1[0].rule_Weight, p1_W = p1[0].weight;
                    double p2_POS = p2[0].POS_Weight, p2_Relation = p2[0].rule_Weight, p2_W = p2[0].weight;

                    // 전체 가중치
                    double p1_total_weight = 0;
                    double p2_total_weight = 0;

                    // 전체 가중치 합 계산
                    p1_total_weight = p1_POS + p1_Relation + p1_W;
                    p2_total_weight = p2_POS + p2_Relation + p2_W;

                    p1[0].total_weight = p1_total_weight;   // 전체 가중치
                    p2[0].total_weight = p2_total_weight;   // 전체 가중치

                    if (p1[0].total_weight < p2[0].total_weight)
                    {
                        tmp = Tree[i];
                        Tree[i] = Tree[j];
                        Tree[j] = tmp;
                    }
                }
            }

            // Frame정보 + 격조사구 규칙
            //Tree.Sort(delegate(List<Morpheme_Relation> p1, List<Morpheme_Relation> p2)
            //{

            //    // 형태소분석 가중치(Tagger [rw]), Argument Info 가중치, C#쪽 격조사구-동사 가중치
            //    double p1_POS = p1[0].POS_Weight, p1_Relation = p1[0].rule_Weight, p1_W = p1[0].weight;
            //    double p2_POS = p2[0].POS_Weight, p2_Relation = p2[0].rule_Weight, p2_W = p2[0].weight;

            //    // 전체 가중치
            //    double p1_total_weight = 0;
            //    double p2_total_weight = 0;

            //    // p1 연산 루틴
            //    //for (int i = 0; i < p1.Count; i++)
            //    //{
            //    //    //p1_POS += p1[i].POS_Weight;         // 형태소 가중치
            //    //    p1_Relation += p1[i].rule_Weight;   // Subcat 가중치
            //    //    p1_W += p1[i].weight;               // 격조사구 가중치
            //    //}
            //    ////p1_Relation += p1[0].rule_Weight;
            //    ////p1_W += p1[0].weight;

            //    //// p2 연산 루틴
            //    //for (int i = 0; i < p2.Count; i++)
            //    //{
            //    //    //p2_POS += p2[i].POS_Weight;         // 형태소 가중치
            //    //    p2_Relation += p2[i].rule_Weight;   // Subcat 가중치
            //    //    p2_W += p2[i].weight;               // 격조사구 가중치
            //    //}
            //    ////p2_Relation += p2[0].rule_Weight;
            //    ////p2_W += p2[0].weight;


            //    // 전체 가중치 합 계산
            //    p1_total_weight = p1_POS + p1_Relation + p1_W;
            //    p2_total_weight = p2_POS + p2_Relation + p2_W;

            //    // 각 트리의 ROOT NODE에 Weight값 부여
            //    //p1[0].POS_Weight = p1_POS;              // 형태소 가중치
            //    //p1[0].rule_Weight = p1_Relation;        // Subcat 가중치
            //    //p1[0].weight = p1_W;                    // 격조사구 가중치
            //    p1[0].total_weight = p1_total_weight;   // 전체 가중치

            //    //p2[0].POS_Weight = p2_POS;              // 형태소 가중치
            //    //p2[0].rule_Weight = p2_Relation;        // Subcat 가중치
            //    //p2[0].weight = p2_W;                    // 격조사구 가중치
            //    p2[0].total_weight = p2_total_weight;   // 전체 가중치


            //    int result = 0;
            //    // 결과 확인용 value : result
            //    if (p1[0].total_weight == p2[0].total_weight)
            //    {
            //        result = -1;
            //    }
            //    else
            //    {
            //        result = (p1[0].total_weight).CompareTo(p2[0].total_weight);
                    
            //    }
            //    return result;
            //}
            //);
        }



        //거리 정보 추가
        //public void Length_Sum(ref List<List<Morpheme_Relation>> Tree)
        //{
        //    for (int i = 0; i < Tree.Count; i++)//Rank 하나
        //    {
        //        int sum = 0;
        //        for (int j = 0; j < Tree[i].Count; j++)//어절 하나
        //        {
        //            int depen = Convert.ToInt32(Tree[i][j].dependency_position);
        //            int gover = Convert.ToInt32(Tree[i][j].gover_position);

        //            Tree[i][j].Relation_length = depen - gover;
        //            sum += Tree[i][j].Relation_length;
        //        }
        //        Tree[i][0].Relation_length = sum;
        //    }
        //}

        //규칙 추가
        //public void Custom_Predicate_Rule(ref List<List<Morpheme_Relation>> Tree)
        //{
        //    for (int i = 0; i < Tree.Count; i++)
        //    {

        //        int last_verb_position = 0;
        //        int first_busa_position = 0;
        //        int section_link_position = 0;
        //        String post_position = "";
        //        for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해                
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사"))
        //            {
        //                last_verb_position = Convert.ToInt32(Tree[i][j].dependency_position);
        //                break;
        //            }
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해
        //        {
        //            if (Tree[i][j].gover_POS.Equals("보조사"))
        //            {
        //                post_position = Tree[i][j].gover_position.ToString();
        //                break;
        //            }
        //        }
        //        for (int j = 0; j <= Tree[i].Count - 1; j++)//Rank 하나에 대해                
        //            if (Tree[i][j].dependency_POS.Equals("그외부사"))
        //            {
        //                first_busa_position = Convert.ToInt32(Tree[i][j].dependency_position);
        //                break;
        //            }
        //        for (int j = 0; j <= Tree[i].Count - 1; j++)//Rank 하나에 대해                
        //            if (Tree[i][j].dependency_POS.Equals("절연결어미"))
        //            {
        //                section_link_position = Convert.ToInt32(Tree[i][j].dependency_position);
        //                break;
        //            }



        //        //규칙
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해
        //        {
        //            //1. 형용사 + 관형형일 경우
        //            if (Tree[i][j].gover_POS.Equals("관형형전성어미") && Tree[i][j].dependency_POS.Equals("형용사"))
        //            {
        //                String position = Tree[i][j].dependency_position;
        //                if (!Tree[i][j].dependency_word.Equals("있다") && !Tree[i][j].dependency_word.Equals("없다"))
        //                {
        //                    for (int x = 0; x < Tree[i].Count; x++)
        //                        if (Tree[i][j].dependency_position.Equals(Tree[i][x].gover_position))
        //                        {
        //                            //Tree[i][0].rule_Weight = 10;

        //                        }
        //                }
        //            }


        //            //2. 보조사 + 동사일 경우
        //            if ((Tree[i][j].gover_POS.Equals("동사") ||
        //                Tree[i][j].gover_POS.Equals("타동사") ||
        //                Tree[i][j].gover_POS.Equals("자동사") ||
        //                Tree[i][j].gover_POS.Equals("자타동사"))
        //                && Tree[i][j].dependency_POS.Equals("보조사") && (Tree[i][j].dependency_word.Equals("는") || Tree[i][j].dependency_word.Equals("도")))
        //            {
        //                if (Tree[i][j].gover_position.Equals(last_verb_position.ToString()) && Tree[i][j].dependency_position.Equals(post_position))
        //                {
        //                    Tree[i][0].rule_Weight += -2;

        //                }
        //                if (Tree[i][j].dependency_position.Equals(post_position) && !Tree[i][j].gover_position.Equals(last_verb_position.ToString()))
        //                    Tree[i][0].rule_Weight += 2;
        //            }


        //            //3. 접속부사 + 동사일 경우
        //            if ((Tree[i][j].gover_POS.Equals("동사") ||
        //                Tree[i][j].gover_POS.Equals("타동사") ||
        //                Tree[i][j].gover_POS.Equals("자동사") ||
        //                Tree[i][j].gover_POS.Equals("자타동사"))
        //                &&
        //                (Tree[i][j].dependency_POS.Equals("접속부사")))
        //            {

        //                if (Tree[i][j].gover_position.Equals(last_verb_position.ToString()) && Tree[i][j].dependency_position.Equals(Tree[i][j].dependency_position))
        //                {
        //                    Tree[i][0].rule_Weight += -1;

        //                }
        //                else
        //                {
        //                    Tree[i][0].rule_Weight += 1;
        //                }
        //            }

        //            //4. 문장 첫 부사는 끝 용언에 연결
        //            if (Tree[i][j].dependency_position.Equals(first_busa_position.ToString()))
        //            {
        //                if (!Tree[i][j].gover_position.Equals(last_verb_position.ToString())
        //                    && (Tree[i][j].gover_POS.Equals("동사") ||
        //                        Tree[i][j].gover_POS.Equals("타동사") ||
        //                        Tree[i][j].gover_POS.Equals("자동사") ||
        //                        Tree[i][j].gover_POS.Equals("형용사") ||
        //                        Tree[i][j].gover_POS.Equals("자타동사")))
        //                {
        //                    if ((Tree[i][Tree[i].Count - Convert.ToInt32(Tree[i][j].gover_position)].gover_position.Equals(section_link_position.ToString())))
        //                    {
        //                        Tree[i][0].rule_Weight += -1;
        //                    }

        //                }
        //                else if (Tree[i][j].gover_position.Equals(last_verb_position.ToString()))
        //                {
        //                    Tree[i][0].rule_Weight += -1;
        //                }
        //            }

        //            // 2017.06.27. Tree Remove로 인해 NullPointException 발생함!
        //            //// 규칙 주석 처리
        //            //if ((Tree[i][j].gover_word.Equals("이다") && Tree[i][j].dependency_word.Equals("것")) ||
        //            //    (Tree[i][j].gover_word.Equals("싶다") && Tree[i][j].dependency_word.Equals("고")))
        //            //{
        //            //    String position = Tree[i][j].gover_position;
        //            //    for (int x = 0; x < Tree[i].Count; x++)
        //            //        if (Tree[i][x].gover_position.Equals(position) && !Tree[i][x].dependency_position.Equals(Tree[i][j].dependency_position))
        //            //        {
        //            //            Tree.Remove(Tree[i]);
        //            //            break;
        //            //        }

        //            //}


        //        }

        //    }

        //}



        //격조사구 + 용언 정보 추가
        //public void particle(ref List<List<Morpheme_Relation>> Tree)
        //{
        //    for (int i = Tree.Count - 1; i >= 0; i--)
        //    {
        //        bool isRemove = false;

        //        int last_verb_position = 0; //마지막 동사의 위치
        //        int total_verb_nummber = 0; //문장의 총 동사 수
        //        int _number = 0;//문장의 총 조사 수
        //        int total_postposition_number = 0;//문장의 총 조사 수

        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사"))
        //                total_verb_nummber++;

        //            else if (Tree[i][j].dependency_POS.Equals("주격보격조사") ||
        //                Tree[i][j].dependency_POS.Equals("목적격조사") ||
        //                Tree[i][j].dependency_POS.Equals("관형격조사") ||
        //                Tree[i][j].dependency_POS.Equals("부사격조사") ||
        //                Tree[i][j].dependency_POS.Equals("인용격조사") ||
        //                 Tree[i][j].dependency_POS.Equals("보조사") ||
        //                Tree[i][j].dependency_POS.Equals("연결어미"))
        //                total_postposition_number++;
        //        }


        //        for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해                
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사"))
        //            {
        //                last_verb_position = Convert.ToInt32(Tree[i][j].dependency_position);
        //                break;
        //            }



        //        //1. 문장의 끝 동사가 아닌데 하나의 동사가 2개 이상의 격조사구를 지배할 경우
        //        //2. 동사가 2개 이상 조사가 1개 이상인데 아무것도 연결되지 않았을 경우 
        //        //3. 동사가 하나 조사가 1개 이상인데 아무것도 연결되지 않았을 경우



        //        //1. 하나의 동사가 2개 이상의 격조사구를 지배할 경우
        //        if (total_postposition_number >= 2)//동사가 2개 이상일 경우
        //        {

        //            for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해
        //            {
        //                if (Tree[i][j].gover_POS.Equals("동사") ||
        //                    Tree[i][j].gover_POS.Equals("자동사") ||
        //                    Tree[i][j].gover_POS.Equals("타동사") ||
        //                    Tree[i][j].gover_POS.Equals("자타동사"))
        //                {
        //                    int count_verb = 0;
        //                    int count_verb1 = 0;

        //                    if (!Tree[i][Tree[i].Count - Convert.ToInt32(Tree[i][j].gover_position)].gover_POS.Equals("종결어미"))
        //                    {
        //                        for (int x = 0; x < Tree[i].Count; x++)
        //                        {
        //                            if (Tree[i][j].gover_position == Tree[i][x].gover_position &&
        //                                Tree[i][x].dependency_POS.Equals("주격보격조사"))
        //                            {
        //                                count_verb++;
        //                                if (Tree[i][j].gover_word.Equals("되다"))
        //                                {
        //                                    count_verb--;
        //                                }
        //                            }
        //                            if (Tree[i][j].gover_position == Tree[i][x].gover_position &&
        //                                 Tree[i][x].dependency_POS.Equals("보조사"))
        //                            {
        //                                count_verb1++;
        //                                if (Tree[i][x].dependency_word.Equals("까지"))
        //                                {
        //                                    count_verb1--;
        //                                }
        //                                if (x + 1 < Tree[i].Count
        //                                    && Tree[i][x].dependency_word.Equals("만")
        //                                    && Tree[i][x + 1].dependency_word.Contains("하다"))
        //                                {
        //                                    count_verb1--;
        //                                }
        //                            }
        //                        }
        //                        if (count_verb1 >= 2)
        //                        {
        //                            Tree[i][0].weight += 8;
        //                        }
        //                        if (count_verb + count_verb1 >= 2
        //                            && count_verb > 1 && count_verb1 > 1)
        //                        {
        //                            Tree[i][0].weight += 8;
        //                        }
        //                    }


        //                }

        //            }

        //        }



        //        ////2. 동사가 2개 이상 조사가 1개 이상인데 아무것도 연결되지 않은 동사가 존재할 경우
        //        //if (total_verb_nummber >= 2 && total_postposition_number >= 1)//동사가 2개 이상일 경우
        //        //{

        //        //    for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해 Relation
        //        //    {
        //        //       bool is_verb = false;

        //        //        if (Tree[i][j].dependency_POS.Equals("동사") ||
        //        //            Tree[i][j].dependency_POS.Equals("자동사") ||
        //        //            Tree[i][j].dependency_POS.Equals("타동사") ||
        //        //            Tree[i][j].dependency_POS.Equals("자타동사"))
        //        //        {
        //        //            if (Convert.ToInt32(Tree[i][j].dependency_position) != last_verb_position) //문장의 끝 동사가 아닌 경우
        //        //            {
        //        //                //2018.08.17 김성태 수정 Tree.Conut[i] -> j
        //        //                for (int x = 0; x < Tree[i].Count - 1; x++)
        //        //                {
        //        //                    if (Tree[i][j].dependency_position == Tree[i][x].gover_position &&
        //        //                        (Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //        //                         Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //        //                         Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //        //                         Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //        //                         Tree[i][x].dependency_POS.Equals("인용격조사") ||
        //        //                         Tree[i][x].dependency_POS.Equals("보조사")||
        //        //                         Tree[i][x].dependency_word.Contains("를")))
        //        //                    {
        //        //                        is_verb = true;
        //        //                        break;
        //        //                    }
        //        //                }
        //        //                if (!is_verb)
        //        //                {
        //        //                    Tree[i][0].weight += 10;

        //        //                }
        //        //            }

        //        //        }
        //        //    }
        //        //}
        //        //2.1. 맨 마지막 동사이면서 앞에 인용형어미가 있을 경우 조사에 의존하지 않으면 삭제
        //        if (total_verb_nummber >= 2 && total_postposition_number >= 1)//동사가 2개 이상일 경우
        //        {
        //            isRemove = false;
        //            for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해 Relation
        //            {
        //                bool is_verb = false;
        //                if (Convert.ToInt32(Tree[i][j].dependency_position) == last_verb_position) //문장의 끝 동사
        //                {
        //                    if (j + 1 < Tree[i].Count
        //                        && !Tree[i][j + 1].dependency_POS.Equals("관형형전성어미")
        //                        && (!Tree[i][j].dependency_word.Equals("하다")
        //                            && !Tree[i][j].dependency_word.Equals("하다+었")))
        //                    {
        //                        if (j > 0 && Tree[i][j - 1].dependency_POS.Equals("인용형어미"))
        //                        {
        //                            for (int x = 0; x < Tree[i].Count - 1; x++)
        //                            {
        //                                if (Tree[i][j].dependency_position == Tree[i][x].gover_position)
        //                                {
        //                                    if (Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("인용격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("보조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("연결어미") ||
        //                                     Tree[i][x].dependency_POS.Equals("동사수식부사"))
        //                                    {
        //                                        is_verb = true;
        //                                        break;
        //                                    }
        //                                    else is_verb = false;
        //                                }
        //                            }
        //                        }
        //                        else if (j >= 0)
        //                        {
        //                            is_verb = true;
        //                        }

        //                        if (is_verb == false)
        //                        {
        //                            //isRemove = true;
        //                            // break;
        //                        }
        //                    }
        //                }
        //            }

        //            if (isRemove)
        //            {
        //                // Tree.RemoveAt(i);
        //                //continue;
        //            }
        //        }

        //        //2.2. 동사뒤에 관형형전성어미나 
        //        else if (total_verb_nummber >= 2 && total_postposition_number >= 1)//동사가 2개 이상일 경우
        //        {
        //            isRemove = false;
        //            for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해 Relation
        //            {
        //                bool is_verb = false;
        //                bool weigt_verb = false;
        //                if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                    Tree[i][j].dependency_POS.Equals("타동사") ||
        //                    Tree[i][j].dependency_POS.Equals("자타동사"))
        //                {
        //                    if (Convert.ToInt32(Tree[i][j].gover_position) != last_verb_position &&
        //                        Convert.ToInt32(Tree[i][j].dependency_position) != last_verb_position) //문장의 끝 동사가 아닌 경우
        //                    {
        //                        if (j == 0
        //                            ||
        //                            (Tree[i].Count - 2 >= j && Tree[i][j + 1].dependency_POS.Equals("관형형전성어미")
        //                            || Tree[i].Count - 2 >= j && Tree[i][j + 1].dependency_POS.Equals("명사형전성어미"))
        //                            ||
        //                            (Tree[i].Count - 4 >= j && Tree[i][j + 1].dependency_POS.Equals("연결어미")
        //                            && (Tree[i][j + 2].dependency_POS.Equals("보조용언") &&
        //                             Tree[i][j + 3].dependency_POS.Equals("관형형전성어미")))
        //                             ||
        //                            (j > 1 && Tree[i][j - 2].dependency_POS.Contains("따옴표"))
        //                             ||
        //                            (Tree[i].Count - 3 >= j && Tree[i][j + 1].dependency_POS.Equals("연결어미")
        //                            && (Tree[i][j + 2].dependency_POS.Equals("동사") ||
        //                             Tree[i][j + 2].dependency_POS.Equals("자동사") ||
        //                             Tree[i][j + 2].dependency_POS.Equals("타동사") ||
        //                             Tree[i][j + 2].dependency_POS.Equals("자타동사") ||
        //                             Tree[i][j + 2].dependency_POS.Equals("형용사")))
        //                             )
        //                        {
        //                            is_verb = true;
        //                            //2018.08.17 김성태 수정 Tree.Conut[i] -> j
        //                            if (Tree[i][j + 1].dependency_word.Contains("게"))
        //                            {
        //                                weigt_verb = true;
        //                            }
        //                            else if (j > 0 && Tree[i][j + 1].dependency_POS.Equals("관형형전성어미")
        //                                && Tree[i][j - 1].dependency_POS.Equals("연결어미"))
        //                            {
        //                                weigt_verb = true;
        //                            }
        //                            else if (Tree[i].Count - 3 > j
        //                                && Tree[i][j + 1].dependency_POS.Equals("연결어미")
        //                                && (Tree[i][j + 3].dependency_POS.Equals("연결어미")
        //                                    || Tree[i][j + 3].dependency_POS.Equals("종결어미")))
        //                            {
        //                                weigt_verb = true;
        //                            }
        //                            else
        //                            {
        //                                for (int x = 0; x < Tree[i].Count - 1; x++)
        //                                {
        //                                    if (Tree[i][j].dependency_position == Tree[i][x].gover_position &&
        //                                        (Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //                                         Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //                                         Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //                                         Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //                                         Tree[i][x].dependency_POS.Equals("인용격조사") ||
        //                                         Tree[i][x].dependency_POS.Equals("보조사") ||
        //                                         Tree[i][x].dependency_word.Contains("를")))
        //                                    {
        //                                        weigt_verb = true;
        //                                        break;
        //                                    }
        //                                }
        //                            }

        //                            if (!weigt_verb)
        //                            {
        //                                Tree[i][0].weight += 2;
        //                            }
        //                        }
        //                        else if (Tree[i].Count > j)
        //                        {
        //                            for (int x = 0; x < Tree[i].Count - 1; x++)
        //                            {
        //                                if (Tree[i][j].dependency_position == Tree[i][x].gover_position)
        //                                {
        //                                    if (Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("인용격조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("보조사") ||
        //                                     Tree[i][x].dependency_POS.Equals("연결어미") ||
        //                                     Tree[i][x].dependency_POS.Equals("동사수식부사") ||
        //                                     Tree[i][x].dependency_POS.Equals("문장수식부사") ||
        //                                     Tree[i][x].dependency_POS.Equals("명사형전성어미") ||
        //                                     Tree[i][x].dependency_POS.Equals("인용형어미"))
        //                                    {
        //                                        is_verb = true;
        //                                        break;
        //                                    }
        //                                    else is_verb = false;
        //                                }
        //                            }
        //                        }
        //                        if (!is_verb)
        //                        {
        //                            isRemove = true;
        //                            break;
        //                        }
        //                    }
        //                }
        //            }
        //            if (isRemove)
        //            {
        //                //Tree.RemoveAt(i);
        //                // continue;
        //            }
        //        }

        //        //3. 동사가 하나 조사가 1개 이상인데 아무것도 연결되지 않았을 경우
        //        if (total_verb_nummber == 1 && total_postposition_number >= 1)//동사가 1개, 격조사가 1이상일때 
        //        {

        //            for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해
        //            {
        //                if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                    Tree[i][j].dependency_POS.Equals("자동사") ||
        //                    Tree[i][j].dependency_POS.Equals("타동사") ||
        //                    Tree[i][j].dependency_POS.Equals("자타동사"))
        //                {
        //                    bool count_verb = false;
        //                    for (int x = 0; x < Tree[i].Count; x++)
        //                        if (Tree[i][j].dependency_position == Tree[i][x].gover_position &&
        //                            (Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("인용격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("보조사")))
        //                            count_verb = true;

        //                    if (!count_verb)
        //                        Tree[i][0].weight += 1;
        //                }
        //            }

        //        }




        //        //4. 동사 바로 앞 어절이 연결어미일 경우는 연결
        //        //
        //        //예) 
        //        for (int j = Tree[i].Count - 2; j >= 0; j--)//Rank 하나에 대해
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사"))
        //            {
        //                //for (int x = 0; x < Tree[i].Count; x++)
        //                //    if (Tree[i][j].gover_position == Tree[i][x].gover_position &&
        //                //        Tree[i][x].dependency_POS.Equals("연결어미") || Tree[i][x].dependency_POS.Equals("그외부사"))
        //                //    {
        //                //        if (Convert.ToInt32(Tree[i][x].dependency_position) - Convert.ToInt32(Tree[i][x].gover_position) == 1)
        //                //            Tree[i][0].weight += -10;
        //                //    }
        //                //2018.08.23 김성태 수정  gover_position -> dependency_POS
        //                for (int x = 0; x < Tree[i].Count; x++)
        //                    if (Tree[i][j].dependency_word == Tree[i][x].gover_word &&
        //                        (Tree[i][x].dependency_POS.Equals("연결어미") || Tree[i][x].dependency_POS.Equals("그외부사")))
        //                    {
        //                        if (j - 1 == x &&
        //                            (!Tree[i][j + 1].dependency_POS.Equals("관형형전성어미")
        //                            && !Tree[i][j + 1].dependency_POS.Equals("연결어미")))
        //                        {
        //                            Tree[i][0].weight += -5;
        //                        }
        //                    }



        //            }
        //        }

        //    }


        //}//end particle




        //격조사구 + 용언 정보 추가
        //public void particle2(ref List<List<Morpheme_Relation>> Tree)
        //{


        //    for (int i = 0; i < Tree.Count; i++)
        //    {
        //        String last_verb_position = "";
        //        String first_bojo = "";
        //        String first_verb_position = "";
        //        String first_busa_position = "";
        //        int total_verb_nummber = 0;

        //        for (int j = Tree[i].Count - 1; j >= 0; j--)//Rank 하나에 대해                
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사") ||
        //                Tree[i][j].dependency_POS.Equals("형용사"))
        //            {
        //                last_verb_position = Tree[i][j].dependency_position;
        //                break;
        //            }

        //        for (int j = 0; j < Tree[i].Count; j++)
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("보조사")
        //                || Tree[i][j].dependency_POS.Equals("주격보격조사"))
        //            {


        //                first_bojo = Tree[i][j].dependency_position;
        //                break;

        //            }
        //        }
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해                
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사"))
        //            {
        //                first_verb_position = Tree[i][j].dependency_position;
        //                break;
        //            }

        //        for (int j = 0; j <= Tree[i].Count - 1; j++)//Rank 하나에 대해                
        //            if (Tree[i][j].dependency_POS.Equals("그외부사"))
        //            {
        //                first_busa_position = Tree[i][j].dependency_position;
        //                break;
        //            }
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사"))
        //                total_verb_nummber++;
        //        }




        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("동사") ||
        //                Tree[i][j].dependency_POS.Equals("자동사") ||
        //                Tree[i][j].dependency_POS.Equals("타동사") ||
        //                Tree[i][j].dependency_POS.Equals("자타동사"))
        //            {
        //                if (total_verb_nummber >= 2)
        //                {
        //                    if (!Tree[i][j].dependency_position.Equals(last_verb_position))
        //                    {
        //                        for (int x = 0; x < j; x++)
        //                        {
        //                            if ((Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //                                Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //                                Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //                                Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //                                Tree[i][x].dependency_POS.Equals("인용격조사")) && Tree[i][x].gover_position.Equals(Tree[i][j].dependency_position))
        //                            {
        //                                //Tree[i][0].weight += -1;
        //                                break;
        //                            }//연결된게 있을 경우     

        //                        }
        //                    }
        //                }
        //                else if (total_verb_nummber == 1)
        //                {
        //                    for (int x = 0; x < j; x++)
        //                    {
        //                        if ((Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("인용격조사")) && Tree[i][x].gover_position.Equals(Tree[i][j].dependency_position))
        //                        {
        //                            //Tree[i][0].weight += -1;
        //                            break;
        //                        }//연결된게 있을 경우

        //                    }
        //                }
        //            }




        //            //부사격조사 + 지정사 연결의 경우 우선순위 낮춤
        //            if (Tree[i][j].gover_POS.Equals("지정사"))
        //            {

        //                if (Tree[i][j].dependency_POS.Equals("부사격조사"))
        //                {

        //                    Tree[i][0].weight += 10;
        //                }
        //            }
        //        }//end Rank







        //        //2016.06.01 추가


        //        //부사격조사,주격보격조사
        //        //그외부사, 형용사수식부사, 동사수식부사, 연결어미
        //        //가까운 용언에 연결된 구문분석 트리의 순위를 높임


        //        //부사격조사+ 동사 가까운 동사에 연결
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("부사격조사"))
        //            {
        //                // 2017.01.26. 류재민 추가
        //                // "에서+는"과 같은 부사격조사는 보조사적 성질을 가지므로
        //                // 가까운 용언에 붙는 가중치에서 예외처리
        //                if (Tree[i][j].dependency_word.Contains("는")
        //                    || Tree[i][j].dependency_word.Contains("도"))
        //                {
        //                    continue;
        //                }

        //                String verb_name = "";

        //                for (int x = 0; x < word_morpheme[i].Count(); x++)
        //                {
        //                    String[] str = word_morpheme[i][x].Split('#');

        //                    if (str[0].Equals(Tree[i][j].dependency_word) && str[1].Equals(Tree[i][j].dependency_POS))
        //                    {
        //                        for (int z = x + 1; z < word_morpheme[i].Count(); z++)
        //                        {
        //                            String[] verb = word_morpheme[i][z].Split('#');
        //                            if (verb[1].Equals("동사") ||
        //                                verb[1].Equals("자동사") ||
        //                                verb[1].Equals("타동사") ||
        //                                verb[1].Equals("자타동사") ||
        //                                verb[1].Equals("형용사")) // 2018.07.11 김성태 형용사 추가 문제될시 삭제요함.
        //                            {

        //                                verb_name = verb[0];
        //                                break;


        //                            }
        //                        }
        //                    }
        //                    if (!verb_name.Equals(""))
        //                        break;
        //                }
        //                if (verb_name.Equals(Tree[i][j].gover_word))
        //                {
        //                    Tree[i][0].weight += -1;
        //                }
        //            }
        //        }//end rank












        //        //주격보격조사 + 용언은 가까운 용언에 연결
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (!Tree[i][j].dependency_position.Equals(first_bojo) && Tree[i][j].dependency_POS.Equals("주격보격조사"))
        //            {
        //                String verb_name = "";


        //                for (int x = 0; x < word_morpheme[i].Count(); x++)
        //                {
        //                    String[] str = word_morpheme[i][x].Split('#');

        //                    if (str[0].Equals(Tree[i][j].dependency_word) && str[1].Equals(Tree[i][j].dependency_POS))
        //                    {
        //                        for (int z = x + 1; z < word_morpheme[i].Count(); z++)
        //                        {
        //                            String[] verb = word_morpheme[i][z].Split('#');
        //                            if (verb[1].Equals("동사") ||
        //                                verb[1].Equals("자동사") ||
        //                                verb[1].Equals("타동사") ||
        //                                verb[1].Equals("자타동사") ||
        //                                verb[1].Equals("형용사"))
        //                            {
        //                                verb_name = verb[0];
        //                                break;

        //                            }
        //                        }
        //                    }
        //                    if (!verb_name.Equals(""))
        //                        break;
        //                }
        //                if (verb_name.Equals(Tree[i][j].gover_word))
        //                    Tree[i][0].weight += -1;
        //            }
        //        }


        //        //부사는 가까운 용언에 연결
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (j == 0) continue;   // 문장 맨앞의 부사는 예외로 해본다. // 2016.07.23. 류재민 추가
        //            if (Tree[i][j].dependency_POS.Equals("그외부사") ||
        //                Tree[i][j].dependency_POS.Equals("형용사수식부사") ||
        //                Tree[i][j].dependency_POS.Equals("동사수식부사")) // 2018.08.30 김성태 추가
        //            {
        //                String verb_name = "";

        //                for (int x = 0; x < word_morpheme[i].Count(); x++)
        //                {
        //                    String[] str = word_morpheme[i][x].Split('#');

        //                    if (str[0].Equals(Tree[i][j].dependency_word) && str[1].Equals(Tree[i][j].dependency_POS))
        //                    {
        //                        for (int z = x + 1; z < word_morpheme[i].Count(); z++)
        //                        {
        //                            String[] verb = word_morpheme[i][z].Split('#');
        //                            if (verb[1].Equals("동사") ||
        //                                verb[1].Equals("자동사") ||
        //                                verb[1].Equals("타동사") ||
        //                                verb[1].Equals("자타동사") ||
        //                                verb[1].Equals("형용사"))
        //                            {
        //                                if (verb[0].Equals("이렇다")
        //                                    || verb[0].Equals("저렇다")
        //                                    || verb[0].Equals("그렇다"))
        //                                {
        //                                    continue;
        //                                }
        //                                else
        //                                {
        //                                    verb_name = verb[0];
        //                                    break;
        //                                }

        //                            }
        //                        }
        //                    }
        //                    if (!verb_name.Equals(""))
        //                        break;

        //                }
        //                if (verb_name.Equals(Tree[i][j].gover_word))
        //                {
        //                    Tree[i][0].weight += -2;
        //                }
        //            }
        //        }




        //        //연결어미 + 용언일 경우
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("연결어미"))
        //            {
        //                String verb_name = "";

        //                for (int x = 0; x < word_morpheme[i].Count(); x++)
        //                {
        //                    String[] str = word_morpheme[i][x].Split('#');

        //                    if (str[0].Equals(Tree[i][j].dependency_word) && str[1].Equals(Tree[i][j].dependency_POS))
        //                    {
        //                        for (int z = x + 1; z < word_morpheme[i].Count(); z++)
        //                        {
        //                            String[] verb = word_morpheme[i][z].Split('#');
        //                            if (verb[1].Equals("동사") ||
        //                                verb[1].Equals("자동사") ||
        //                                verb[1].Equals("타동사") ||
        //                                verb[1].Equals("자타동사") ||
        //                                verb[1].Equals("형용사"))
        //                            {
        //                                verb_name = verb[0];
        //                                break;
        //                            }
        //                        }
        //                    }
        //                    if (!verb_name.Equals(""))
        //                        break;
        //                }
        //                if (verb_name.Equals(Tree[i][j].gover_word)) ;
        //                //Tree[i][0].weight += -1;
        //            }
        //        }





        //        // 연결어미 + [동사 + 연결어미 + 동사]일 경우
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("연결어미"))
        //            {
        //                String verb_name = "";

        //                for (int x = 0; x < word_morpheme[i].Count(); x++)
        //                {
        //                    String[] str = word_morpheme[i][x].Split('#');

        //                    if (str[0].Equals(Tree[i][j].dependency_word) && str[1].Equals(Tree[i][j].dependency_POS))
        //                    {
        //                        for (int z = x + 1; z < word_morpheme[i].Count(); z++)
        //                        {
        //                            String[] verb = word_morpheme[i][z].Split('#');
        //                            if (verb[1].Equals("동사") ||
        //                                verb[1].Equals("자동사") ||
        //                                verb[1].Equals("타동사") ||
        //                                verb[1].Equals("자타동사"))
        //                            {
        //                                if (z + 2 < word_morpheme[i].Count())
        //                                {
        //                                    // 연결어미 + [동사 + 연결어미] + 동사일 경우                                         
        //                                    String[] end = word_morpheme[i][z + 1].Split('#');
        //                                    String[] verb2 = word_morpheme[i][z + 2].Split('#');
        //                                    if (end[1].Equals("연결어미") &&
        //                                        (verb2[1].Equals("동사") ||
        //                                        verb2[1].Equals("자동사") ||
        //                                        verb2[1].Equals("타동사") ||
        //                                        verb2[1].Equals("자타동사") &&
        //                                        !verb2[0].Equals("되다")
        //                                        //||verb2[1].Equals("보조용언")
        //                                        ))
        //                                    {
        //                                        if (z + 3 < word_morpheme[i].Count())
        //                                        {
        //                                            // 연결어미 + [동사 + 연결어미] + 동사일 경우                                         
        //                                            String[] ghan = word_morpheme[i][z + 3].Split('#');
        //                                            if (!ghan[1].Equals("관형형전성어미"))
        //                                            {
        //                                                verb_name = verb[0];
        //                                                break;
        //                                            }
        //                                        }
        //                                        else
        //                                        {
        //                                            verb_name = verb[0];
        //                                            break;
        //                                        }
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                    if (!verb_name.Equals(""))
        //                        break;
        //                }
        //                if (verb_name.Equals(Tree[i][j].gover_word))
        //                {
        //                    Tree[i][0].weight += 2;
        //                }


        //            }
        //        }






        //        // 연결어미,그외부사  + [형용사 + 관형형전성어미]일 경우
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("연결어미") || Tree[i][j].dependency_POS.Equals("그외부사"))
        //            {
        //                String verb_name = "";

        //                for (int x = 0; x < word_morpheme[i].Count(); x++)
        //                {
        //                    String[] str = word_morpheme[i][x].Split('#');

        //                    if (str[0].Equals(Tree[i][j].dependency_word) && str[1].Equals(Tree[i][j].dependency_POS))
        //                    {
        //                        for (int z = x + 1; z < word_morpheme[i].Count(); z++)
        //                        {
        //                            String[] verb = word_morpheme[i][z].Split('#');
        //                            if (verb[1].Equals("형용사")
        //                                && !verb[0].Equals("있다"))
        //                            {
        //                                if (z + 1 < word_morpheme[i].Count())
        //                                {
        //                                    // 연결어미 + [형용사 + 관형형전성어미]일 경우
        //                                    String[] end = word_morpheme[i][z + 1].Split('#');
        //                                    if (end[1].Equals("관형형전성어미"))
        //                                    {
        //                                        verb_name = verb[0];
        //                                        break;
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                    if (!verb_name.Equals(""))
        //                        break;
        //                }
        //                if (verb_name.Equals(Tree[i][j].gover_word))
        //                {
        //                    Tree[i][0].weight += 2;
        //                }


        //            }
        //        }









        //        //문장 마지막 동사에 주격이 연결된 경우 우선순위를 높임
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            //String verb_name = "";    // 할당되었으나 사용되지 않은 변수 : 주석처리 : 161016 류재민
        //            bool addWeight = false;
        //            if (Tree[i][j].gover_POS.Equals("동사") ||
        //            Tree[i][j].gover_POS.Equals("자동사") ||
        //            Tree[i][j].gover_POS.Equals("타동사") ||
        //            Tree[i][j].gover_POS.Equals("자타동사") ||
        //            Tree[i][j].gover_POS.Equals("형용사"))
        //            {
        //                if (Tree[i][j].gover_position.Equals(last_verb_position))
        //                {
        //                    if (!(Tree[i][Tree[i].Count - Convert.ToInt32(Tree[i][j].gover_position) - 1].dependency_POS.Equals("인용형어미")))
        //                    {
        //                        bool isOne = false;
        //                        if ((Tree[i][j].dependency_POS.Equals("주격보격조사")
        //                        || Tree[i][j].dependency_POS.Equals("보조사")
        //                        || Tree[i][j].dependency_POS.Equals("부사격조사")))
        //                        {
        //                            for (int k = 0; k < j; k++)
        //                            {
        //                                if ((Tree[i][k].dependency_word.Contains("는")
        //                                    || Tree[i][k].dependency_word.Contains("은")
        //                                    || Tree[i][k].dependency_word.Contains("도")
        //                                    || Tree[i][k].dependency_word.Contains("ㄴ")
        //                                    || Tree[i][k].dependency_word.Equals("대로라면")
        //                                    || Tree[i][k].dependency_word.Equals("이")
        //                                    || Tree[i][k].dependency_word.Equals("가")))
        //                                {
        //                                    isOne = true;
        //                                    break;
        //                                }
        //                            }
        //                            // 2017.01.30. 류재민 [부사격조사] 추가
        //                            // 2018.07.10 김성태 삭제 -> Tree[i][j].dependency_POS.Equals("부사격조사")&&
        //                            if (!isOne)
        //                            {
        //                                if ((Tree[i][j].dependency_word.Contains("는")
        //                                        || Tree[i][j].dependency_word.Contains("은")
        //                                        || Tree[i][j].dependency_word.Contains("도")
        //                                        || Tree[i][j].dependency_word.Contains("ㄴ")
        //                                        || Tree[i][j].dependency_word.Equals("대로라면")
        //                                        || Tree[i][j].dependency_word.Equals("이")
        //                                        || Tree[i][j].dependency_word.Equals("가")))
        //                                {
        //                                    Tree[i][0].weight += -3;
        //                                    break;
        //                                }
        //                                else
        //                                {
        //                                    if (Tree[i][j].dependency_POS.Equals("주격보격조사") || Tree[i][j].dependency_POS.Equals("부사격조사"))
        //                                    {

        //                                    }
        //                                    else
        //                                    {
        //                                        Tree[i][0].weight += -1;
        //                                    }
        //                                    break;
        //                                    //2018.07.10 김성태 둘다 -2??
        //                                    //Tree[i][0].weight += 2;
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }

        //        }//end rank




        //        /**
        //         * @date : 2017.02.10.
        //         * @author : 류재민
        //         * @brif : 문장수식부사가 맨 뒤 용언에 연결된 경우 우선순위 높임
        //         */
        //        for (int j = 0; j < Tree[i].Count; j++)//Rank 하나에 대해 Relation
        //        {
        //            if (Tree[i][j].gover_position.Equals(last_verb_position))
        //            {
        //                if (Tree[i][j].dependency_POS.Equals("문장수식부사"))
        //                {
        //                    Tree[i][0].weight += -2;
        //                    break;
        //                }
        //            }
        //        }
        //    }

        //}



        /**
         * @date : 2017.02.10.
         * @brif : 문장 맨 앞의 보조사가 본용언에 붙을 때 파스트리 순위 높임
         * @comment : 기존, 보조사-지정사 만 가중치 줬었음
         */
        //public void Bojosa_Jijungsa(ref List<List<Morpheme_Relation>> Tree)
        //{
        //    for (int i = 0; i < Tree.Count; i++)
        //    {
        //        for (int j = 0; j < Tree[i].Count; j++)
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("지정사"))
        //            {
        //                for (int x = 0; x < j; x++)
        //                {
        //                    if (Tree[i][x].dependency_POS.Equals("보조사")
        //                        && Tree[i][x].gover_position.Equals(Tree[i][j].dependency_position))
        //                    {
        //                        if (Tree[i][j].gover_POS.Equals("관형형전성어미"))
        //                        {
        //                            if (Tree[i].Count > j + 4
        //                                && Tree[i][j + 2].dependency_word.Equals("것")
        //                                && Tree[i][j + 3].dependency_POS.Equals("지정사")
        //                                && Tree[i][j + 4].dependency_POS.Equals("종결어미"))
        //                            {
        //                                Tree[i][0].weight -= 3;
        //                            }
        //                            else if (Tree[i][j].gover_word.Equals("다는"))
        //                            {
        //                                Tree[i][0].weight -= 3;
        //                            }
        //                            else
        //                            {
        //                                break;
        //                            }
        //                        }
        //                        else if (Tree[i][j].gover_POS.Equals("종결어미"))
        //                        {
        //                            // 2017.02.10. 아래에 보조사-본용언 규칙 추가
        //                            Tree[i][0].weight -= 3;
        //                            break;
        //                        }
        //                        else if (Tree[i][j].gover_POS.Equals("절연결어미"))
        //                        {
        //                            // 2016.11.18. 추가
        //                            // ex) [원작은] 남자주인공들 [위주지만] 영화에서는 여자배역의 역할을 좀 더 부각시키고 액션장면도 많이 넣어 재미를 보강할 계획이다.
        //                            Tree[i][0].weight -= 4;
        //                            break;
        //                        }

        //                    }
        //                }
        //            }
        //        }
        //    }


        //    for (int i = 0; i < Tree.Count; i++)
        //    {
        //        String last_verb_position = "";
        //        String first_bojo = "";
        //        String paragraph_ec = "";
        //        int divide = 0;

        //        for (int j = Tree[i].Count - 1; j >= 0; j--)
        //        {
        //            if (Tree[i][j].dependency_POS.Equals("동사")
        //                || Tree[i][j].dependency_POS.Equals("자동사")
        //                || Tree[i][j].dependency_POS.Equals("타동사")
        //                || Tree[i][j].dependency_POS.Equals("형용사")
        //                || Tree[i][j].dependency_POS.Equals("지정사")
        //                || Tree[i][j].dependency_POS.Equals("자타동사"))
        //            {
        //                last_verb_position = Tree[i][j].dependency_position;
        //                break;
        //            }
        //        }
        //        //for (int j = Tree[i].Count - 1; j >= 0; j--)
        //        //{
        //        //    if (Tree[i][j].dependency_POS.Equals("절연결어미")
        //        //        || Tree[i][j].dependency_POS.Equals("연결어미"))
        //        //    {
        //        //        divide = Tree[i][j].dependency_POS_num;
        //        //        break;
        //        //    }
        //        //}

        //        for (int j = 0; j < Tree[i].Count; j++)
        //        {
        //            bool isOne = false;
        //            if (Tree[i][j].gover_POS.Equals("보조사")
        //                || Tree[i][j].gover_POS.Equals("부사격조사"))
        //            {
        //                for (int k = 0; k < j; k++)
        //                {
        //                    if ((Tree[i][k].dependency_word.Contains("는")
        //                        || Tree[i][k].dependency_word.Contains("은")
        //                        || Tree[i][k].dependency_word.Contains("도")
        //                        || Tree[i][k].dependency_word.Contains("ㄴ")
        //                        || Tree[i][k].dependency_word.Equals("대로라면")
        //                        || Tree[i][k].dependency_word.Equals("이")
        //                        || Tree[i][k].dependency_word.Equals("가")))
        //                    {
        //                        isOne = true;
        //                        break;
        //                    }
        //                }
        //                if (!isOne)
        //                {
        //                    if (Tree[i][j].gover_word.Equals("은")
        //                        || Tree[i][j].gover_word.Equals("는")
        //                        || Tree[i][j].gover_word.Equals("도")
        //                        || Tree[i][j].gover_word.Equals("에서+ㄴ")
        //                        || Tree[i][j].gover_word.Equals("대로라면"))
        //                    {
        //                        first_bojo = Tree[i][j].gover_position;
        //                        break;
        //                    }
        //                }
        //            }
        //        }

        //        for (int j = 0; j < Tree[i].Count; j++)
        //        {
        //            if (Tree[i][j].gover_position.Equals(last_verb_position))
        //            {
        //                if (Tree[i][j].dependency_position.Equals(first_bojo))
        //                {
        //                    Tree[i][0].weight += -3;
        //                    break;
        //                }
        //            }
        //        }

        //        // 절연결어미 (2017.04.13.)
        //        for (int j = 0; j < Tree[i].Count; j++)
        //        {
        //            if (Tree[i][j].gover_POS.Equals("절연결어미"))
        //            {
        //                paragraph_ec = Tree[i][j].gover_position;
        //                break;
        //            }
        //        }
        //        for (int j = 0; j < Tree[i].Count; j++)
        //        {
        //            bool isUpWeight = false;
        //            if (Tree[i][j].gover_position.Equals(last_verb_position))
        //            {
        //                if (Tree[i][j].dependency_position.Equals(paragraph_ec))
        //                {
        //                    for (int x = 0; x < j; x++)
        //                    {
        //                        if ((Tree[i][x].dependency_POS.Equals("주격보격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("목적격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("관형격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("부사격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("인용격조사") ||
        //                            Tree[i][x].dependency_POS.Equals("보조사")))
        //                        {
        //                            isUpWeight = true;
        //                            break;
        //                        }
        //                    }
        //                    if (isUpWeight)
        //                    {
        //                        Tree[i][0].weight += -3;
        //                        break;
        //                    }
        //                }
        //            }
        //        }

        //    }

        //}




         //2016.07.22. 류재민 추가
        /* 관형형 + 가까운 명사 연결 우선*/
        //public void Gwan_Near_Myung(ref List<List<Morpheme_Relation>> Tree)
        //{
        //    for (int i = 0; i < Tree.Count; i++)
        //    {   // 각 트리 별 순환
        //        for (int j = 0; j < Tree[i].Count; j++)
        //        {   // 각 트리의 형태소 별 순환

        //            // 의존소가
        //            if (Tree[i][j].dependency_POS.Equals("관형형전성어미") ||      // 관형형전성어미 // 2018.08.14 김성태 주석처리 parsingElementList.cpp에 구현
        //                Tree[i][j].dependency_POS.Equals("관형사") ||              // 관형사
        //                Tree[i][j].dependency_POS.Equals("관형격조사") ||          // 관형격조사
        //                Tree[i][j].dependency_POS.Equals("지시관형사") ||
        //                Tree[i][j].dependency_POS.Equals("접속조사"))            // 지시관형사
        //            {

        //                if (j != Tree[i].Count - 1)  // j가 마지막 어절이 아니면서
        //                {
        //                    if (Tree[i][j].gover_POS.Equals("명사") ||
        //                        Tree[i][j].gover_POS.Equals("일반명사") ||
        //                        Tree[i][j].gover_POS.Equals("관형성명사") ||
        //                        Tree[i][j].gover_POS.Equals("고유명사") ||
        //                        Tree[i][j].gover_POS.Equals("사람이름") ||
        //                        Tree[i][j].gover_POS.Equals("술어명사") ||
        //                        Tree[i][j].gover_POS.Equals("동작성명사") ||
        //                        Tree[i][j].gover_POS.Equals("상태성명사") ||
        //                        Tree[i][j].gover_POS.Equals("부사성명사") ||
        //                        Tree[i][j].gover_POS.Equals("의존명사") ||
        //                        Tree[i][j].gover_POS.Equals("일반의존명사") ||
        //                        Tree[i][j].gover_POS.Equals("단위의존명사") ||
        //                        Tree[i][j].gover_POS.Equals("부사성의존명사") ||
        //                        Tree[i][j].gover_POS.Equals("대명사") ||
        //                        Tree[i][j].gover_POS.Equals("인칭대명사") ||
        //                        Tree[i][j].gover_POS.Equals("지시대명사") ||
        //                        Tree[i][j].gover_POS.Equals("의문대명사") ||
        //                         Tree[i][j].gover_POS.Equals("수관형사"))  // 명사 종류
        //                    {
        //                        bool contNoun = false;
        //                        bool leftToRight = false;
        //                        int pivot = Tree[i].Count - Convert.ToInt32(Tree[i][j].gover_position);

        //                        if (Convert.ToInt32(Tree[i][j].dependency_position) - Convert.ToInt32(Tree[i][j].gover_position) < 5)
        //                        {   // 명사 나열을 형태소 5이하로 제한 (~한 N1의 N2의 N3)정도 까지

        //                            // Check 1
        //                            for (int k = pivot + 1; k < Tree[i].Count; k++)
        //                            {   // 명사 나열인지 검사 (Left to Right)
        //                                if (Tree[i][k].dependency_POS.Contains("명사"))
        //                                {
        //                                    contNoun = true;
        //                                    leftToRight = true;
        //                                    break;
        //                                }
        //                                else
        //                                {
        //                                    break;
        //                                }
        //                            }

        //                            // Check 2
        //                            if (!contNoun && pivot > 0)
        //                            {
        //                                for (int rk = pivot - 1; rk >= 0; rk--)
        //                                {   // 명사 나열인지 검사 (Right to Left)
        //                                    if (Tree[i][rk].dependency_POS.Contains("명사"))
        //                                    {
        //                                        contNoun = true;
        //                                        leftToRight = false;
        //                                        break;
        //                                    }
        //                                    else
        //                                    {
        //                                        break;
        //                                    }
        //                                }
        //                            }
        //                            if (contNoun)
        //                            {   // 명사 나열형일 때 (뒤 우선)
        //                                if (leftToRight)
        //                                {
        //                                    Tree[i][0].rule_Weight = Tree[i][0].rule_Weight - (Convert.ToInt32(Tree[i][j].gover_position) - Convert.ToInt32(Tree[i][j].dependency_position));
        //                                }

        //                            }
        //                            else
        //                            {   // 명사 나열형이 아닐 때 (앞 우선)
        //                                if (j + 1 == pivot)
        //                                {
        //                                    Tree[i][0].rule_Weight = Tree[i][0].rule_Weight + (Convert.ToInt32(Tree[i][j].gover_position) - Convert.ToInt32(Tree[i][j].dependency_position));

        //                                }
        //                            }
        //                        }




        //                        /*
        //                        bool flag = true;
        //                        for (int k = j; k < Tree[i].Count; k++ )
        //                        {
        //                            // [관형형 N의] 패턴 시 가중치 X
        //                            if(Tree[i][j].gover_position == Tree[i][k].dependency_position)
        //                            {
        //                                if(Tree[i][k].gover_word.Equals("의"))
        //                                {
        //                                    flag = false;
        //                                }
        //                            }
        //                        }

        //                        if (flag)
        //                        {
        //                            // Tree[i][j].gover_position : 지배소 위치 (0에 가까울 수록 Root에 가까움)
        //                            // Tree[i][j].dependency_position : 의존소 위치 (큰 수 일 수록 문장 맨 앞에 가까움)
        //                            // gover_position - dependency_potition : 지배-의존 거리 : 클수록 Penalty 받는다.
        //                            Tree[i][0].rule_Weight = Tree[i][0].rule_Weight - (Convert.ToInt32(Tree[i][j].gover_position) - Convert.ToInt32(Tree[i][j].dependency_position));
        //                        }
        //                        */
        //                    }

        //                }
        //            }
        //        }// end for (j)
        //    }// end for (i)
        //}// end function

        //출력
        public void print_result()
        {
            System.IO.StreamWriter file = new System.IO.StreamWriter("../Result.txt", append: true);
            foreach (KeyValuePair<string, int> pair in Result_Sentence)
            {
                //Console.WriteLine("{0}, {1}", pair.Key, pair.Value);
                file.WriteLine(pair.Key + "\t" + pair.Value);
            }
            file.Close();
        }

        public void print_resultWIthNumOfTrees(List<int> _numOfTrees)
        {
            System.IO.StreamWriter file = new System.IO.StreamWriter("../Result(NumOfTrees).txt", append: true);
            foreach(int i in _numOfTrees)
            {
                file.WriteLine(i);
            }
            file.Close();
        }

















        /////////////////////////////////////////수정 금지//////////////////////////////////////////


        //tab2  ----> File Parsing 루틴


        //파일 불러 오기 
        private void Load_file(object sender, EventArgs e)
        {
            richTextBox.Text = "";
            OpenFileDialog OpenFileDialog = new OpenFileDialog();
            //OpenFileDialog.DefaultExt = "*.txt";
            OpenFileDialog.Filter = "All files(*.*)|*.*";
            OpenFileDialog.FilterIndex = 1;
            OpenFileDialog.ShowDialog();

            if (OpenFileDialog.FileName.Length > 0)
            {
                this.File_Path.Text = ""; //txtbox에 경로 초기화
                foreach (String filename in OpenFileDialog.FileNames)
                {
                    this.File_Path.Text = filename;
                }
            }
        }




        //File Parsing 시작
        private void Execute_Button_Click(object sender, EventArgs e)
        {
            if (this.File_Path.Text != "")
            {
                //RESULT내 txt 파일 모두 삭제
                String result_path = "..\\RESULT\\";
                DirectoryInfo dir = new DirectoryInfo(result_path);
                System.IO.FileInfo[] files = dir.GetFiles("*.*", SearchOption.AllDirectories);
                foreach (System.IO.FileInfo file in files)
                {
                    file.Attributes = FileAttributes.Normal;
                    file.Delete();
                }
                richTextBox.Text = "";



                //파일 읽기 시작
                String line;
                int count = 0;

                // File Output
                //System.IO.StreamWriter fout = new System.IO.StreamWriter("../FileParsingResult.txt", append:true);
                // File Input
                System.IO.StreamReader fi = new System.IO.StreamReader(this.File_Path.Text, System.Text.Encoding.Default);

                while ((line = fi.ReadLine()) != null)
                {
                    // File Output
                    System.IO.StreamWriter fout = new System.IO.StreamWriter("../FileParsingResult.txt", append:true);
                    //line = "나는 학교에 간다.";
                    //문장_result.txt 파일 생성
                    int numOfPT = cl.getParseTree(line, true, true);




                    Sentence_Class sc = new Sentence_Class();
                    Parse_Tree = new List<List<Morpheme_Relation>>();
                    word_morpheme = new List<List<string>>();

                    RegistryKey key = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\BCD_Parser");
                    String reg_Sentence = key.GetValue("Sentence").ToString();//문장

                    Parse_Tree = sc.input(reg_Sentence);
                    word_morpheme = sc.get_sentence_information();

                    double value = 0;
                    for (int kkk = 0; kkk < Parse_Tree.Count(); kkk++)
                    {
                        value = Parse_Tree[kkk][0].rule_Weight;
                    }

                    //Length_Sum(ref Parse_Tree);

                    //Custom_Predicate_Rule(ref Parse_Tree);//규칙 추가
                    //Bojosa_Jijungsa(ref Parse_Tree); // 2016.08.04. 추가  (Tree[i][0]만 사용)
                    //Gwan_Near_Myung(ref Parse_Tree);    // 2016.07.22. 추가   (Tree[i][0]만 사용)
                    //particle2(ref Parse_Tree);//격조사구 추가 (Tree[i][0]만 사용)

                    Sorting(ref Parse_Tree);    //weight 값으로 Sorting            
                    Distance_Sorting(ref Parse_Tree);   // 2017.01.03. 추가 (같은 weight에 대해 거리 짧은 순 정렬)




                    string[] row1 = new string[] { line, numOfPT.ToString() };
                    // 수정
                    fout.WriteLine("<Sentence>" + Input_Sentence.Text.ToString());
                    for(int i = 0; i < Parse_Tree[0].Count; i++)
                    {
                        fout.WriteLine(Parse_Tree[0][i].dependency_position + "\t"
                            + Parse_Tree[0][i].dependency_word + "#" + Parse_Tree[0][i].dependency_POS + "\t\t" +
                            Parse_Tree[0][i].gover_position);
                    }
                    fout.WriteLine("\n");
                    //fout.WriteLine(line, numOfPT.ToString());
                    Sentence_GridView.Rows.Add(row1);
                    count++;
                    fout.Close();
                }

                
                fi.Close();

                richTextBox.Text += "Parsing 완료\n";
                richTextBox.Text += "총 문장 수 : " + count.ToString() + "문장";
            }

            else
                MessageBox.Show("파일을 불러오세요.");
        }




        //Sentence Gridview 초기화
        public void Sentence_dataGridView()
        {
            Sentence_GridView.ColumnCount = 2;
            Sentence_GridView.Columns[0].Name = "문장";
            Sentence_GridView.Columns[0].Width = 1000;
            Sentence_GridView.Columns[0].Frozen = true;
            Sentence_GridView.ColumnHeadersDefaultCellStyle.Font = new Font("맑은고딕", 10);

            Sentence_GridView.Columns[1].Name = "Parse Tree 수";
            Sentence_GridView.Columns[1].Width = 175;
            Sentence_GridView.Columns[1].Frozen = true;


            //cell 가운데 정렬
            this.Sentence_GridView.Columns[1].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            Sentence_GridView.AutoGenerateColumns = true;
            Sentence_GridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Font 설정
            //Sentence_GridView.Columns[0].DefaultCellStyle.Font = new Font("맑은고딕", 11);



            this.Sentence_GridView.Columns[0].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Sentence_GridView.Columns[1].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            Sentence_GridView.AutoGenerateColumns = true;





            //옵션
            Sentence_GridView.AllowUserToAddRows = false;
            Sentence_GridView.AllowUserToDeleteRows = false;
            Sentence_GridView.ReadOnly = true;
            Sentence_GridView.MultiSelect = false;
            Sentence_GridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;



        }



        //행 번호 입력
        private void dataGridView_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.ColumnIndex < 0 && e.RowIndex >= 0)
            {
                e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
                Rectangle _rect = e.CellBounds;
                _rect.Inflate(-6, -6);
                e.CellStyle.Font = new Font("맑은고딕", 8);
                TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(), e.CellStyle.Font, _rect, e.CellStyle.ForeColor, TextFormatFlags.Right);
                e.Handled = true;
            }
        }


        /**
         * @date : 2016.12.02.
         * @author : 류재민
         * @brif : word_morpheme을 반환
         * @brif : Search_Form에서 이용하기 위함
         */
        public List<List<String>> getWordMorph()
        {
            return word_morpheme;
        }



        /**
         * @date : 2016.12.05.
         * @author : 류재민
         * @brif : Search_Form에 Parse_Tree를 넘겨준다.
         */
        public List<List<Morpheme_Relation>> getParse_Tree()
        {
            return Parse_Tree;
        }

        private void main_form_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Registry에 아무것도 없으면 지우기 실행 X
            RegistryKey closer = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\BCD_Parser", true);
            if(closer != null)
            {
                Registry.LocalMachine.DeleteSubKeyTree("Software\\Wow6432Node\\BCD_Parser");
            }

            // for test
            //if (DialogResult.Yes != MessageBox.Show("정말 종료하시겠습니까?", "프로그램 종료", MessageBoxButtons.YesNo))
            //{
            //    e.Cancel = true;
            //}
        }

        private void Distance_Sorting(ref List<List<Morpheme_Relation>> Tree)
        {
           // Length_Sum(ref Tree);

            List<Morpheme_Relation> p1, p2;
            List<Morpheme_Relation> tmp;

            for(int i = 0; i < Tree.Count; i++)
            {
                for (int j = 0; j < Tree.Count; j++)
                {
                    p1 = Tree[i];
                    p2 = Tree[j];

                    if (p1[0].total_weight == p2[0].total_weight)
                    {
                        double p1_distance = p1[0].Relation_length;
                        double p2_distance = p2[0].Relation_length;

                        if (p1_distance < p2_distance)
                        {
                            tmp = Tree[i];
                            Tree[i] = Tree[j];
                            Tree[j] = tmp;
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
            }
        }

        private void main_form_Load(object sender, EventArgs e)
        {

        }

        private void Rank_GridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void OpenFileDialog_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Input_Sentence_TextChanged(object sender, EventArgs e)
        {

        }
    }//end class
}
