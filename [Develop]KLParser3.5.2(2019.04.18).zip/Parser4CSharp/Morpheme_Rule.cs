﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parser4CSharp
{
    class Morpheme_Rule
    {
        //지배소 정보        
        public String gover_word = "";
        public String gover_POS = "";        

        //의존소 정보        
        public String dependency_word = "";
        public String dependency_POS = "";
        
    }
}
