﻿namespace Parser4CSharp
{
    partial class Corret_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Corret_ParseTree_View = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // Corret_ParseTree_View
            // 
            this.Corret_ParseTree_View.Cursor = System.Windows.Forms.Cursors.Default;
            this.Corret_ParseTree_View.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Corret_ParseTree_View.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.Corret_ParseTree_View.Indent = 30;
            this.Corret_ParseTree_View.ItemHeight = 30;
            this.Corret_ParseTree_View.Location = new System.Drawing.Point(12, 12);
            this.Corret_ParseTree_View.Name = "Corret_ParseTree_View";
            this.Corret_ParseTree_View.Size = new System.Drawing.Size(710, 538);
            this.Corret_ParseTree_View.TabIndex = 1;
            // 
            // Corret_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 562);
            this.Controls.Add(this.Corret_ParseTree_View);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Corret_Form";
            this.Padding = new System.Windows.Forms.Padding(12);
            this.Text = "정답 문장";
            this.ResumeLayout(false);

        }

        
        #endregion

        private System.Windows.Forms.TreeView Corret_ParseTree_View;
    }
}