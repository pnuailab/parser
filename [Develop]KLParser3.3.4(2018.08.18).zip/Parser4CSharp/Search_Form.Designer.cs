﻿namespace Parser4CSharp
{
    partial class Search_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.GovGruop = new System.Windows.Forms.GroupBox();
            this.GovInfo = new System.Windows.Forms.ComboBox();
            this.DepGroup = new System.Windows.Forms.GroupBox();
            this.DepInfo = new System.Windows.Forms.ComboBox();
            this.Search_SearchButton = new System.Windows.Forms.Button();
            this.SearchGridView = new System.Windows.Forms.DataGridView();
            this.Search_PT = new System.Windows.Forms.GroupBox();
            this.SearchPTView = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label_SearchResult = new System.Windows.Forms.Label();
            this.GovGruop.SuspendLayout();
            this.DepGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SearchGridView)).BeginInit();
            this.Search_PT.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GovGruop
            // 
            this.GovGruop.Controls.Add(this.GovInfo);
            this.GovGruop.Location = new System.Drawing.Point(511, 12);
            this.GovGruop.Name = "GovGruop";
            this.GovGruop.Size = new System.Drawing.Size(323, 59);
            this.GovGruop.TabIndex = 0;
            this.GovGruop.TabStop = false;
            this.GovGruop.Text = "지배소";
            // 
            // GovInfo
            // 
            this.GovInfo.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.GovInfo.FormattingEnabled = true;
            this.GovInfo.Location = new System.Drawing.Point(6, 20);
            this.GovInfo.Name = "GovInfo";
            this.GovInfo.Size = new System.Drawing.Size(311, 24);
            this.GovInfo.TabIndex = 2;
            this.GovInfo.Text = "지배소";
            // 
            // DepGroup
            // 
            this.DepGroup.Controls.Add(this.DepInfo);
            this.DepGroup.Location = new System.Drawing.Point(182, 12);
            this.DepGroup.Name = "DepGroup";
            this.DepGroup.Size = new System.Drawing.Size(323, 59);
            this.DepGroup.TabIndex = 1;
            this.DepGroup.TabStop = false;
            this.DepGroup.Text = "의존소";
            // 
            // DepInfo
            // 
            this.DepInfo.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.DepInfo.FormattingEnabled = true;
            this.DepInfo.ItemHeight = 16;
            this.DepInfo.Location = new System.Drawing.Point(6, 20);
            this.DepInfo.Name = "DepInfo";
            this.DepInfo.Size = new System.Drawing.Size(311, 24);
            this.DepInfo.TabIndex = 1;
            this.DepInfo.Text = "의존소";
            // 
            // Search_SearchButton
            // 
            this.Search_SearchButton.Location = new System.Drawing.Point(838, 12);
            this.Search_SearchButton.Name = "Search_SearchButton";
            this.Search_SearchButton.Size = new System.Drawing.Size(75, 60);
            this.Search_SearchButton.TabIndex = 3;
            this.Search_SearchButton.Text = "검색";
            this.Search_SearchButton.UseVisualStyleBackColor = true;
            this.Search_SearchButton.Click += new System.EventHandler(this.Search_SearchButton_Click);
            // 
            // SearchGridView
            // 
            this.SearchGridView.AllowUserToAddRows = false;
            this.SearchGridView.AllowUserToDeleteRows = false;
            this.SearchGridView.AllowUserToResizeColumns = false;
            this.SearchGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SearchGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.SearchGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SearchGridView.Location = new System.Drawing.Point(12, 77);
            this.SearchGridView.MultiSelect = false;
            this.SearchGridView.Name = "SearchGridView";
            this.SearchGridView.RowHeadersVisible = false;
            this.SearchGridView.RowTemplate.Height = 23;
            this.SearchGridView.Size = new System.Drawing.Size(164, 570);
            this.SearchGridView.TabIndex = 3;
            this.SearchGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SearchGridView_CellClick);
            this.SearchGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.SearchGridView_KeyUp);
            // 
            // Search_PT
            // 
            this.Search_PT.Controls.Add(this.SearchPTView);
            this.Search_PT.Location = new System.Drawing.Point(182, 77);
            this.Search_PT.Name = "Search_PT";
            this.Search_PT.Size = new System.Drawing.Size(946, 576);
            this.Search_PT.TabIndex = 4;
            this.Search_PT.TabStop = false;
            this.Search_PT.Text = "ParseTree";
            // 
            // SearchPTView
            // 
            this.SearchPTView.Location = new System.Drawing.Point(6, 20);
            this.SearchPTView.Name = "SearchPTView";
            this.SearchPTView.Size = new System.Drawing.Size(934, 550);
            this.SearchPTView.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label_SearchResult);
            this.groupBox1.Location = new System.Drawing.Point(182, 659);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(731, 51);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Result";
            // 
            // label_SearchResult
            // 
            this.label_SearchResult.AutoSize = true;
            this.label_SearchResult.Font = new System.Drawing.Font("돋움", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_SearchResult.Location = new System.Drawing.Point(6, 23);
            this.label_SearchResult.Name = "label_SearchResult";
            this.label_SearchResult.Size = new System.Drawing.Size(82, 15);
            this.label_SearchResult.TabIndex = 0;
            this.label_SearchResult.Text = "검색결과 : ";
            // 
            // Search_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1221, 733);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.GovGruop);
            this.Controls.Add(this.Search_PT);
            this.Controls.Add(this.SearchGridView);
            this.Controls.Add(this.Search_SearchButton);
            this.Controls.Add(this.DepGroup);
            this.Name = "Search_Form";
            this.Text = "검색";
            this.GovGruop.ResumeLayout(false);
            this.DepGroup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SearchGridView)).EndInit();
            this.Search_PT.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GovGruop;
        private System.Windows.Forms.GroupBox DepGroup;
        private System.Windows.Forms.Button Search_SearchButton;
        private System.Windows.Forms.DataGridView SearchGridView;
        private System.Windows.Forms.GroupBox Search_PT;
        private System.Windows.Forms.ComboBox DepInfo;
        private System.Windows.Forms.ComboBox GovInfo;
        private System.Windows.Forms.TreeView SearchPTView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label_SearchResult;
    }
}