﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parser4CSharp
{
    public class Morpheme_Relation
    {
        //지배소 정보
        public String gover_position ="";
        public String gover_word = "";
        public String gover_POS = "";
        public int gover_POS_num = 0;

        //의존소 정보
        public String dependency_position ="";
        public String dependency_word = "";
        public String dependency_POS= "";
        public int dependency_POS_num = 0;

        public double Frame_Check = 0; //Frame 값
        public int Relation_length = 0; //거리 정보
        public double weight = 0;   //격조사구 규칙 값
        public double POS_Weight = 0;  //태깅 우선순위 
        public double rule_Weight = 0; //규칙 사전 값

        public double total_weight = 0;//최종 Weight 값

        public void gover_set(String gover_position, String gover_word, String gover_POS, int gover_POS_num)
        {
            this.gover_position = gover_position;
            this.gover_word = gover_word;
            this.gover_POS = gover_POS;
            this.gover_POS_num = gover_POS_num;
        }

        public void depency_set(String dependency_position, String dependency_word, String dependency_POS, int dependency_POS_num)
        {
            this.dependency_position = dependency_position;
            this.dependency_word = dependency_word;
            this.dependency_POS = dependency_POS;
            this.dependency_POS_num = dependency_POS_num;

        }


        public void Corpus_gover_set(String gover_position, String gover_word, String gover_POS)
        {
            this.gover_position = gover_position;
            this.gover_word = gover_word;
            this.gover_POS = gover_POS;            
        }

        public void Corpus_depency_set(String dependency_position, String dependency_word, String dependency_POS)
        {
            this.dependency_position = dependency_position;
            this.dependency_word = dependency_word;
            this.dependency_POS = dependency_POS;
        }


    }
}
