#pragma once

#ifndef _PNUNLP_H_
#define _PNUNLP_H_
// ?�음 ifdef 블록?� DLL?�서 ?�보?�기?�는 ?�업???�게 ??주는 매크로�? 만드??
// ?��? 방식?�니?? ??DLL???�어 ?�는 ?�일?� 모두 명령줄에 ?�의??PNUNLP_EXPORTS 기호�?
// 컴파?�되�? ?�일??DLL???�용?�는 ?�른 ?�로?�트?�서????기호�??�의?????�습?�다.
// ?�렇�??�면 ?�스 ?�일?????�일???�어 ?�는 ?�른 모든 ?�로?�트?�서??
// PNUNLP_API ?�수�?DLL?�서 가?�오??것으�?보고,
// ??DLL?� ?�당 매크로로 ?�의??기호가 ?�보?��???것으�?봅니??

#ifdef INCLUDE_OS_RELATED_STDAFX_H
#	undef INCLUDE_OS_RELATED_STDAFX_H
#endif

#ifdef WINCE
#	ifndef INCLUDE_OS_RELATED_STDAFX_H
#		define INCLUDE_OS_RELATED_STDAFX_H
#	endif
#endif

#ifdef WIN32
#	ifndef INCLUDE_OS_RELATED_STDAFX_H
#		define INCLUDE_OS_RELATED_STDAFX_H
#		ifndef WIN_DESKTOP
#			define WIN_DESKTOP
#		endif
#	endif
#endif

// linux or mac
#ifndef INCLUDE_OS_RELATED_STDAFX_H
#	define INCLUDE_OS_RELATED_STDAFX_H
#	ifndef LINUX_PORTING
#		define LINUX_PORTING
#	endif
#endif

#ifdef WIN32
#	ifdef _WINDLL
#		ifdef PNUNLP_EXPORTS
#			define PNUNLP_API __declspec(dllexport)
#		else
#			define PNUNLP_API __declspec(dllimport)
#		endif
#	else
#		define PNUNLP_API	
#	endif
#else
#	define PNUNLP_API	
#endif


#ifndef NO_PACK
#	ifdef DEFAULT_PACK_SIZE
#		pragma pack(push, DEFAULT_PACK_SIZE)
#	else
#		pragma pack(push, 1)	// gcc?�선 DEFAULT_PACK_SIZE�?바로 �??�
#	endif
#endif


#ifndef NULL
#define NULL 0
#endif

#ifdef FOR_TAGGER
	#include <list>
#endif

//#ifdef LINUX_PORTING
// adding for linux porting solikang
#ifdef LINUX_PORTING
typedef unsigned int		DWORD;
#else
typedef unsigned long		DWORD;
#endif
typedef unsigned short		WORD;


#ifndef PNUDIC_LOADER_MAX_DICPATH
#define PNUDIC_LOADER_MAX_DICPATH		1000
#endif

#define PNU_SPELLER_MAX_CORRECTION		10
#define PNUNLP_MAX_WSTRING				28	// ?��?2004?�서 28?�까지 지??(2009.08.31 ?�명�??�시�?80?�로)
#ifdef LINUX_PORTING
	#define PNUNLP_MAX_STRING				56
#else
	#define PNUNLP_MAX_STRING				(PNUNLP_MAX_WSTRING<<1)
#endif

#define MAX_HELPMESSAGE			3000	// 2010.08.11 ?�재 ?�일 �??��?�?길이가 1953??
#define MAX_ERRORKINDMESSAGE	100

//////////////////////////////////////////////////////////////////////////

// TEXT_MANAGER_OPTION_*?� ?�일?�야 ??
#define PNU_SPELLER_OPTION_ALL					0xFFFFFFFF

#define PNU_SPELLER_OPTION_ERROR_CORRECTION		0x00000001
#define PNU_SPELLER_OPTION_COLLOCATION			0x00000002
#define PNU_SPELLER_OPTION_MULTIPLE				0x00000004
#define PNU_SPELLER_OPTION_MARK_CONTOROL		0x00000008
#define PNU_SPELLER_OPTION_SPECIAL_COMPNOUN		0x00000010
#define PNU_SPELLER_OPTION_ARRANGE_ERROR		0x00000020
#define PNU_SPELLER_OPTION_SCOURT_REMOVE		0x00000040		// 법원?�서 ?�류가 ?�닌�??�거
#define PNU_SPELLER_OPTION_END_OF_MARK_CONTOROL	0x00000080		// 문장 마�?막의 문장부???�류
#define	PNU_SPELLER_OPTION_MUTIPLE_LINE_CHECK	0x00000100		// 멀?�플 ?�류 �??�치어�??�인?�고 줄긋�?
#define PNU_SPELLER_OPTION_PERSON_LASTNAME_ADD	0x00000200		// 3글???�명???�올 ??LastName 추�? : ex) '?�길?? ?�력 ??'길동'???�람?�름?�로 분석
#define PNU_SPELLER_OPTION_IN_BRACE				0x00000400		// 괄호 ??분석????것인지
//#define PNU_SPELLER_OPT_ALLOW_NON_SPACING_ERR	0x00000400		// ?�어?�기 ?�의 ?�류 ?�용 : ???�션???�정?��? ?��? 경우, ?�른 ?�정 ?�션?�로 교정??결과?�서 ?�어?�기 부분만 ?�택?�여 ?�치어�??�성?�다.(?�명�?2009.07.31)
//#define PNU_SPELLER_OPTION_ONLY_SPACING			0xFFFFFBFF		// ?�어?�기 ?�류�?교정 (?�용 주의!!)(?�명�?2009.07.31)

//////////////////////////////////////////////////////////////////////////

#define CPnuSpellerResultType(__data__)	(*((CPnuSpellerResult*)&__data__))

class PnuSpellerResult	// ?��?(PnuNlpHnc)?�서 명시??링크�?????CPnuSpellerResult??멤버?�수�??�의?�야 ?�는 문제가 ?�어???�수?� ?�이?��? 분리??2011.11.11 ?�명�?
{
public:
	char m_ErrorWord[PNUNLP_MAX_STRING];
	char m_CandWordList[PNU_SPELLER_MAX_CORRECTION][PNUNLP_MAX_STRING];
	unsigned int m_nHelpnum;
	unsigned short m_nCandWordCount;
	unsigned short m_nCorrectMethod;// ?�류 ?�형(교정 방법)
	unsigned short m_nErrorType;	// ?�류??종류(0:철자?�류 1:?�어?�기 2:붙여?�기 3:?�어?�기+붙여?�기)	
	unsigned short m_nStart;	// 컬럼
	unsigned short m_nEnd;		// 길이
	unsigned short m_nCorrectInfo;
	unsigned short m_nLineColor;// 밑줄 ??
};

#ifdef PNUNLP_EXPORTS
class CPnuSpellerResult : public PnuSpellerResult
{
	// 멤버 ?�이??추�??�면 ????PnuSpellerResultType�??�기 ?�문)	2011.11.11 ?�명�?
public:
	CPnuSpellerResult();
	bool PushCandidate(const char* _szCand);		// ?��??�서 바로 ?�근?�는 �?막기(2009.09.08 ?�명�?	
	int GetCandidateCount() const;							// ?��??�서 바로 ?�근?�는 �?막기(2009.09.08 ?�명�?
	void ResetCandCount(int _nCnt=0);
	CPnuSpellerResult & operator=(const CPnuSpellerResult & _oth);
#ifdef LINUX_PORTING
	char* GetCandWord(int index);
#endif
};
#endif

#define CWString_PnuSpellerResultType(__data__)	(*((CPnuSpellerResult*)&__data__))

class WString_PnuSpellerResult	// ?��?(PnuNlpHnc)?�서 명시??링크�?????CPnuSpellerResult??멤버?�수�??�의?�야 ?�는 문제가 ?�어???�수?� ?�이?��? 분리??2011.11.11 ?�명�?
{
public:
	wchar_t m_wcsErrorWord[PNUNLP_MAX_WSTRING];
	wchar_t m_wcsCandWordList[PNU_SPELLER_MAX_CORRECTION][PNUNLP_MAX_WSTRING];
	unsigned short m_nCandWordCount;
	unsigned short m_nCorrectMethod;// ?�류 ?�형(교정 방법)
	unsigned short m_nErrorType;	// ?�류??종류(0:철자?�류 1:?�어?�기 2:붙여?�기 3:?�어?�기+붙여?�기)
	unsigned short m_nHelpnum;
	unsigned short m_nStart;	// 컬럼
	unsigned short m_nEnd;		// 길이
	unsigned short m_nCorrectInfo;
	unsigned short m_nLineColor;// 밑줄 ??
};

#ifdef PNUNLP_EXPORTS
class CWString_PnuSpellerResult : public WString_PnuSpellerResult
{
	// 멤버 ?�이??추�??�면 ????PnuSpellerResultType�??�기 ?�문)	2011.11.11 ?�명�?
public:
	CWString_PnuSpellerResult();
	bool PushCandidate(const wchar_t* _wszCand);	// ?��??�서 바로 ?�근?�는 �?막기(2009.09.08 ?�명�?	
	bool PushCandidate(const void* _hstrCand);		// HString ?�태??바로 ?�용?????�게.. 2010.03.17 ?�명�?
	int GetCandidateCount() const;					// ?��??�서 바로 ?�근?�는 �?막기(2009.09.08 ?�명�?
	void ResetCandCount(int _nCnt=0);
	CWString_PnuSpellerResult & operator=(const CWString_PnuSpellerResult & _oth);
#ifdef LINUX_PORTING
	wchar_t* GetCandWord(int index);
#endif
};
#endif

#ifdef FOR_TAGGER
#ifdef PNUNLP_EXPORTS
#ifdef _CONSOLE
#include "UserCmdDefs.h"
#else
#include "UserCmdDefs.h"
#endif
#else
#include "UserCmdDefs.h"
#endif
#endif

#ifdef LINUX_PORTING
// interface class
class PNUNLP_API PnuNlpInterface
{
private:
	int bOpenPnuNlp;
	//PnuNlpMorpResult m_PnuNlpMorpResult;
	//char* m_strMorpResult;
	wchar_t* m_wcsInputText;

	void* m_pObjDicLoader;
	void* m_pObjTextManager;		// ?�스??메니?� ( ?�태??분석???�는 �?)
	void* m_WString_ListErrorResult;

public:
	PnuNlpInterface();
	virtual ~PnuNlpInterface();
	virtual int OpenPnuNlp(const char* _szDicPath=NULL, unsigned int mode_pnudic_loader=0);

	virtual int ClosePnuNlp();
//	virtual int UserCmd(int _CmdCode, void* _pArg=NULL);
//	friend class UserCommand;

	virtual int PnuSpellCheck(const char* strText,unsigned long OPTION);
	virtual int PnuSpellCheckWithTokenCount(const char* strText,unsigned long OPTION,int& retTokenCount);
	virtual int GetErrorWord(PnuSpellerResult& SpellResult);
	virtual char* GetHelpMessage(int nHelpMsg, int& nHelpKind);
	virtual char* GetErrorKindMessage(int nHelpMsg);

	virtual int UserDicInsert(const char* strText, int nDicType );
	virtual int UserDicDelete(const char* strText );
	virtual int UserDicGetAllWordToFile(const char* strFile, int nDicType );
	virtual void UserDicUseDicType( int nDicType, int bUse );

	virtual void SpellEncodingString( const char* strInput, char* strOutput );
	virtual void SpellDecodingReplaceString( const char* strInput, const char* strReplace, char* strOutput );



	virtual int WString_PnuSpellCheck(const WORD* wcsText,unsigned long OPTION);
	virtual int WString_PnuSpellCheckWithTokenCount(const WORD* wcsText,unsigned long OPTION,int& retTokenCount);
	virtual int WString_GetErrorWord(WString_PnuSpellerResult& SpellResult);
	virtual WORD* WString_GetHelpMessage(int nHelpMsg, int& nHelpKind);
	virtual WORD* WString_GetErrorKindMessage(int nHelpMsg);

//	0: ?�용???�전 추�? ?�패
//	1: ?�용???�전 추�? ?�공
//  2: ?�용???�전???�는 ?�어
//  3: 공백?�나 문장부?��? ?�어?�는 ?�어
	virtual int WString_UserDicInsert(const WORD* wcsText, int nDicType );
//	0: ?�용???�전 ??�� ?�패
//	1: ?�용???�전 ??�� ?�공
//  2: ?�용???�전???�는 ?�어
	virtual int WString_UserDicDelete(const WORD* wcsText );
	virtual int WString_UserDicGetAllWordToFile(const char* strFile, int nDicType );
	virtual void WString_UserDicUseDicType( int nDicType, int bUse );

	virtual void WString_SpellEncodingString( const WORD* wcsInput, WORD* wcsOutput );
	virtual void WString_SpellDecodingReplaceString( const WORD* wcsInput, const WORD* wcsReplace, WORD* wcsOutput );

	virtual void GetVersionInfo(char* strVersion);



	virtual void ReplaceErrorWord(char* strText, const PnuSpellerResult& SpellResult);
	virtual void WString_ReplaceErrorWord(WORD* wcsText, const WString_PnuSpellerResult& SpellResult);
	virtual int ORDER_BY_USER_PnuSpellCheckWithTokenCount(const char* strText,unsigned long OPTION,int& retTokenCount);
};
#endif

#ifdef LINUX_PORTING
class PNUNLP_API PnuNlp : public PnuNlpInterface
#else 
class PNUNLP_API PnuNlp
#endif
{
private:
	int bOpenPnuNlp;
	char	m_szDicPath[PNUDIC_LOADER_MAX_DICPATH];
	//PnuNlpMorpResult m_PnuNlpMorpResult;
	//char* m_strMorpResult;
	wchar_t* m_wcsInputText;

	void* m_pObjDicLoader;
	void* m_pObjTextManager;		// ?�스??메니?� ( ?�태??분석???�는 �?)
#ifdef WIN_DESKTOP
	void* m_pObjStatSpacing;		// // 20080312 ?�거 solikang
#endif

	//void* m_ListErrorResult;		// INCUBE
	void* m_WString_ListErrorResult;
#ifdef PNUNLP_HNC
	//PnuSpellerResult m_SpellResult;
#endif
	// thread safe 처리 �?2009.11.20 ?�명�?멤버변?�로 ?�음
	//char*	 m_szHelpMessage;				// ?�적?�로 바꿈 2010.08.11 ?�명�?
	//wchar_t* m_wszHelpMessage;			// ?�적?�로 바꿈 2010.08.11 ?�명�?
	//char*	 m_szErrorKindMessage;			// ?�적?�로 바꿈 2010.08.11 ?�명�?
	//wchar_t* m_wszErrorKindMessage;		// ?�적?�로 바꿈 2010.08.11 ?�명�?
	char	m_szHelpMessage[MAX_HELPMESSAGE];
	wchar_t m_wszHelpMessage[MAX_HELPMESSAGE];
	char	m_szErrorKindMessage[MAX_ERRORKINDMESSAGE];
	wchar_t	m_wszErrorKindMessage[MAX_ERRORKINDMESSAGE];

public:
	PnuNlp();
	~PnuNlp();
	
//// Etri 기분?�기 Test /////////////////////////////////////////////////////////////
#ifdef ETRI_MA_TEST
	unsigned long m_nNumMR;
	unsigned long m_nNumNotMR;
#endif // ETRI_MA_TEST
/////////////////////////////////////////////////////////////////////////////////////

//// Etri ?�청 ?�스??///////////////////////////////////////////////////////////////
#ifdef ETRI_REQUEST
	bool bRedErrCorrect;
	bool bBeigeErrCorrect;
	bool bGreenErrCorrect;
	bool bBlueErrCorrect;

	char m_szExceptHelpNumList[1000];
#endif
/////////////////////////////////////////////////////////////////////////////////////


	int OpenPnuNlp(const char* _szDicPath=NULL, unsigned int mode_pnudic_loader=0);
	int ClosePnuNlp(bool _bUnloadSharedDic=false);

	int UserCmd(int _CmdCode, void* _pArg=NULL);
	friend class UserCommand;

	int PnuSpellCheck(const char* strText,unsigned long OPTION);
	int PnuSpellCheckWithTokenCount(const char* strText,unsigned long OPTION,int& retTokenCount);

 	int GetErrorWord(PnuSpellerResult& SpellResult);

	char* GetHelpMessage(int nHelpMsg, int& nHelpKind);
	char* GetErrorKindMessage(int nHelpMsg);

	int UserDicInsert(const char* strText, int nDicType );
	int UserDicDelete(const char* strText );
	int UserDicGetAllWordToFile(const char* strFile, int nDicType );
	void UserDicUseDicType( int nDicType, int bUse );

	void SpellEncodingString( const char* strInput, char* strOutput );
	void SpellDecodingReplaceString( const char* strInput, const char* strReplace, char* strOutput );

	int WString_PnuSpellCheck(const WORD* wcsText,unsigned long OPTION);
	int WString_PnuSpellCheckWithTokenCount(const WORD* wcsText,unsigned long OPTION,int& retTokenCount);
	//int WString_PnuSpellCheckWithTokenCountSub( const HString &_hstrText,unsigned long OPTION, int _CurMorpOption,int& retTokenCount, int _nBegPos, int &_nProcedLen);
	int WString_GetErrorWord(WString_PnuSpellerResult& SpellResult);
	WORD* WString_GetHelpMessage(int nHelpMsg, int& nHelpKind);
	WORD* WString_GetErrorKindMessage(int nHelpMsg);

//	0: ?�용???�전 추�? ?�패
//	1: ?�용???�전 추�? ?�공
//  2: ?�용???�전???�는 ?�어
//  3: 공백?�나 문장부?��? ?�어?�는 ?�어
	int WString_UserDicInsert(const WORD* wcsText, int nDicType );
//	0: ?�용???�전 ??�� ?�패
//	1: ?�용???�전 ??�� ?�공
//  2: ?�용???�전???�는 ?�어
	int WString_UserDicDelete(const WORD* wcsText );
	int WString_UserDicGetAllWordToFile(const char* strFile, int nDicType );
	void WString_UserDicUseDicType( int nDicType, int bUse );

	void WString_SpellEncodingString( const WORD* wcsInput, WORD* wcsOutput );
	void WString_SpellDecodingReplaceString( const WORD* wcsInput, const WORD* wcsReplace, WORD* wcsOutput );

	void GetVersionInfo(char* strVersion);

	void ReplaceErrorWord(char* strText, const PnuSpellerResult& SpellResult);
	void WString_ReplaceErrorWord(WORD* wcsText, const WString_PnuSpellerResult& SpellResult);
	int ORDER_BY_USER_PnuSpellCheckWithTokenCount(const char* strText,unsigned long OPTION,int& retTokenCount);
#ifdef FOR_TAGGER
	int GetAllPnuNlpMorpResult(list<PnuNlpMorpResult>* listMorpResult);
	int IsMultipleHead(const char* strText);
#endif
};

#ifdef LINUX_PORTING
// adding for linux porting solikang
// types of the class factories
typedef PnuNlp* create_t();
typedef void destroy_t(PnuNlp*);
#endif

#ifndef NO_PACK
#	pragma pack(pop)
#endif

#endif // _PNUNLP_H_