
#include "include/stdafx.h"

#ifdef PNUNLP_EXPORTS
#		include "PnuNlp.h"
#else
#		include "PnuNlp.h"
#endif


#include "UserCmdFuncs.h"
#include "UserCmdDefs.h"
#include <cassert>

#ifndef UAssert
#define UAssert(__x) assert(__x)
#endif

//#ifdef MA_EX_VER

const char* UCFGetDicPath(void *_pPnuNlp)
{
	UAssert(_pPnuNlp);
	const char* szDicPath;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetDicPath, &szDicPath);
	return szDicPath;
}


void UCFGetPnuNlpMorpResult(void *_pPnuNlp, const char* _szSource, void *_pPnuNlpMorpResult, unsigned short *_pPosViablePrefix)
{

	UAssert(_pPnuNlp);
	UAssert(_pPnuNlpMorpResult);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szSource;
	arg.pPointer1 = _pPnuNlpMorpResult;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetPnuNlpMorpResult, &arg);

	if(_pPosViablePrefix)	*_pPosViablePrefix = arg.nInt1;
}

//bool UCFOpenPnuNlp(void *_pPnuNlp, const char* _szDicPath, unsigned int _mode_pnudic_loader)
//{
//	UAssert(_pPnuNlp);
//
//	Arg_1Int1constSz arg;
//	arg.szText = _szDicPath;
//	arg.nInt1 = _mode_pnudic_loader;
//
//	return (((PnuNlp*)_pPnuNlp)->UserCmd(UCC_OpenPnuNlp, &arg)!=0);
//} 


void UCFGetMorpResult(void *_pPnuNlp, const char* _szSource, const void **ppMR)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szSource;
	arg.ppConstDoublePointer1 = ppMR;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetMorpResult, &arg);	
}

//void UCFMRBoundTest(void *_pPnuNlp, const char* _szSource)
//{
//	UAssert(_pPnuNlp);
//
//	Arg_1constSz arg;
//	arg.szText = _szSource;
//	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_MRBoundTest, &arg);
//}
//
//void UCFMakePreMADic(void *_pPnuNlp, const char* _szSource1, const char* _szSource2)
//{
//	UAssert(_pPnuNlp);
//
//	Arg_2constSz arg;
//	arg.szText1 = _szSource1;
//	arg.szText2 = _szSource2;
//
//	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_MakePreMADic, &arg);
//}

char* UCFGetMorpString(void *_pPnuNlp, const char* _szSource, char* _szResult, bool _bHideOverInfo, bool _bOnelinePrint, bool _bPrintExinfo, bool _bPrintOyong)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szSource;	
	arg.pPointer1 = _szResult;
	arg.nInt1 = (_bHideOverInfo?1:0);
	arg.nInt2 = (_bOnelinePrint?1:0);
	arg.nInt3 = (_bPrintExinfo?1:0);
	arg.nInt4 = (_bPrintOyong?1:0);
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetMorpString, &arg);
	return (char*)arg.pPointer1;
}


char* UCFGetDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szSource;	
	arg.pPointer1 = _szResult;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetDicInfo, &arg);
	return (char*)arg.pPointer1;
}

char* UCFGetSpecialDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szSource;	
	arg.pPointer1 = _szResult;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetSpecialDicInfo, &arg);
	return (char*)arg.pPointer1;
}


char* UCFGetJosaDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szSource;	
	arg.pPointer1 = _szResult;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetJosaDicInfo, &arg);
	return (char*)arg.pPointer1;
}

char* UCFGetEomiDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szSource;	
	arg.pPointer1 = _szResult;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetEomiDicInfo, &arg);
	return (char*)arg.pPointer1;
}

//// return const HCHAR*
//const void* UCFGetOyongStr(void *_pPnuNlp, unsigned long _posOyong)
//{
//	Arg_1uInt1p arg;
//	arg.uInt1 = _posOyong;
//	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetOyongStr, &arg);
//	return arg.p1;
//}

int UCFCheckPlaceInfo(void* _pPnuNlp, const char* _phszPlace1, int _nPlaceExinfo1, const char* _phszPlace2, int _nPlaceExinfo2)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _phszPlace1;
	arg.pConstPointer2 = _phszPlace2;
	arg.nInt1 = _nPlaceExinfo1;
	arg.nInt2 = _nPlaceExinfo2;
	return ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CheckPlaceInfo, &arg);
}

void UCFStatSpacingProc(void* _pPnuNlp, const char* _szText, char* _szResult, int _bViablePrefix, int _bMeanCheck)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szText;
	arg.pPointer1 = _szResult;
	arg.nInt1 = _bViablePrefix;
	arg.nInt2 = _bMeanCheck;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_StatSpacingProc, &arg);
}

void UCFBuildAllDic(void* _pPnuNlp, void* _hConsole, const char* _szSourceDir, const char* _szResultDir, unsigned long _nOPTION)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pPointer1 = _hConsole;
	arg.pConstPointer2 = _szSourceDir;
	arg.pConstPointer3 = _szResultDir;
	arg.nInt1 = _nOPTION;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_BuildAllDic, &arg);
}

void UCFBuildExUserDic(void* _pPnuNlp, void* _hConsole, const char* _szSourceFile, const char* _szResultDir)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg; 
	arg.pPointer1 = _hConsole;
	arg.pConstPointer2 = _szSourceFile;
	arg.pConstPointer3 = _szResultDir;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_BuildExUserDic, &arg);
}

//void UCFGetUnderlinedStr(void* _pPnuNlp, const char* _szOrgStr, char _szOutBuf[], int _nBufLen, const Arg_3Int* _pLineInfos, int _nNumOfInfo)
//{
//	UAssert(_pPnuNlp);
//
//	Arg_GeneralPurpos arg;
//	arg.pConstPointer1 = _szOrgStr;
//	arg.pPointer1 = _szOutBuf;
//	arg.nInt2 = _nBufLen;
//	arg.pPointer2 = (void*)_pLineInfos;
//	arg.nInt1 = _nNumOfInfo;	
//
//	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetUnderlinedStr, &arg);
//}
//
//void UCFGetUnderlinedStrW(void* _pPnuNlp, const wchar_t* _szOrgStr, wchar_t _szOutBuf[], int _nBufLen, const Arg_3Int* _pLineInfos, int _nNumOfInfo)
//{
//	UAssert(_pPnuNlp);
//
//	Arg_GeneralPurpos arg;
//	arg.pConstPointer1 = _szOrgStr;
//	arg.pPointer1 = _szOutBuf;
//	arg.nInt2 = _nBufLen;
//	arg.pPointer2 = (void*)_pLineInfos;
//	arg.nInt1 = _nNumOfInfo;	
//
//	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetUnderlinedStrW, &arg);
//}

int UCFCorrectionAll(void* _pPnuNlp, const char* _szOrgStr, int _nSpellingLevel, int _nBufSize, char _szOutBuf[], unsigned int _spellOpt, unsigned int _nLoopLimit)
{//printf("%s BUILD TIME:%s\n", __FILE__, __TIME__); 
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szOrgStr;
	arg.pPointer1 = _szOutBuf;
	arg.nInt3 = _nBufSize;
	arg.nInt1 = _nSpellingLevel;	
	arg.nInt2 = _spellOpt;
	arg.nInt4 = _nLoopLimit;

	return ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CorrectionAll, &arg);
}

int UCFCorrectionAll2(void* _pPnuNlp, const char* _szOrgStr, int _nSpellingLevel, int _nBufSize, char _szOutBuf[], char _szOutBuf1[], unsigned int _spellOpt, unsigned int _nLoopLimit)
{//printf("%s BUILD TIME:%s\n", __FILE__, __TIME__); 
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szOrgStr;
	arg.pPointer1 = _szOutBuf;
	arg.pPointer2 = _szOutBuf1;
	arg.nInt3 = _nBufSize;
	arg.nInt1 = _nSpellingLevel;	
	arg.nInt2 = _spellOpt;
	arg.nInt4 = _nLoopLimit;

	return ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CorrectionAll2, &arg);
}

int UCFCorrectionAllW(void* _pPnuNlp, const wchar_t* _szOrgStr, int _nSpellingLevel, int _nBufSize, wchar_t _szOutBuf[], unsigned int _spellOpt, unsigned int _nLoopLimit)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szOrgStr;
	arg.pPointer1 = _szOutBuf;
	arg.nInt3 = _nBufSize;
	arg.nInt1 = _nSpellingLevel;
	arg.nInt2 = _spellOpt;
	arg.nInt4 = _nLoopLimit;

	return ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CorrectionAllW, &arg);
}

// ���� ������ �ϳ��� ����
bool  UCFCombineDic(void* _pPnuNlp, const char* _szDicPath)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szDicPath;

	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CombineDic, &arg);
}

void UCFSetGlobalBitOpt(void* _pPnuNlp, unsigned int code, bool _bToActive)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.nInt1 = code;
	arg.nInt2 = (_bToActive==true?1:0);

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_SetGlobalBitOpt, &arg);
}

void UCFSpeedTest(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, const /*PrintCMBitset*/ void* _pPrintCorrectMethods, void* _pProgressData, bool _bForPrecisionCheck)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szInputFile;
	arg.pConstPointer2 = _pPrintCorrectMethods;
	arg.pPointer1 = _pProgressData;
	arg.nInt1 = _CurOption;
	arg.nInt2 = (_bForPrecisionCheck?1:0);

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_SpeedTest, &arg);
}

void UCFFileSpelling(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, const /*PrintCMBitset*/ void* _pPrintCorrectMethods, void* _pProgressData, bool _bForPrecisionCheck, bool _bExcelForm)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szInputFile;
	arg.pConstPointer2 = _pPrintCorrectMethods;
	arg.pPointer1 = _pProgressData;
	arg.nInt1 = _CurOption;
	arg.nInt2 = (_bForPrecisionCheck?1:0);
	arg.nInt3 = (_bExcelForm?1:0);

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CheckSpellFile, &arg);
}

void UCFTaggingCorrectMethodW(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, void* _pProgressData)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szInputFile;
	arg.pPointer1 = _pProgressData;
	arg.nInt1 = _CurOption;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_TaggingCorrectMethodW, &arg);
}

//void UCFWFileSpelling(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, const /*PrintCMBitset*/ void* _pPrintCorrectMethods, void* _pProgressData)
//{
//	UAssert(_pPnuNlp);
//
//	Arg_GeneralPurpos arg;
//	arg.pConstPointer1 = _szInputFile;
//	arg.pConstPointer2 = _pPrintCorrectMethods;
//	arg.pPointer1 = _pProgressData;
//	arg.nInt1 = _CurOption;
//
//	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_WCheckSpellFile, &arg);
//}


char* UCFUNICode2Wansung(void* _pPnuNlp, const wchar_t* _wszInput, char* _szResult)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _wszInput;
	arg.pPointer1 = _szResult;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_UNICODE2WANSUNG, &arg);
	return (char*)arg.pPointer1;
}

wchar_t* UCFWansung2UNICode(void* _pPnuNlp, const char* _szInput, wchar_t* _wszResult)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szInput;
	arg.pPointer1 = _wszResult;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_WANSUNG2UNICODE, &arg);
	return (wchar_t*)arg.pPointer1;
}

void UCFSetTimeLimit(void* _pPnuNlp, bool _bToActive, int _nMilliSeconds)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.nInt1 = (_bToActive?1:0);
	if(_bToActive)	arg.nInt2 = _nMilliSeconds;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_SetTimeLimit, &arg);
}
void UCFRestartTimeLimit(void* _pPnuNlp)
{
	UAssert(_pPnuNlp);

	//Arg_GeneralPurpos arg;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_RestartTimeCheck, NULL);
}

void UCFCorrectionAllFile(void* _pPnuNlp, const char* _szInputFile, int _nSpellingLevel, unsigned int _spellOpt, void* _pProgressData, bool _bPrintTime, unsigned int _nLoopLimit)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szInputFile;
	arg.pPointer1 = _pProgressData;
	arg.nInt1 = _nSpellingLevel;
	arg.nInt2 = _spellOpt;
	arg.nInt3 = _bPrintTime;
	arg.nInt4 = _nLoopLimit;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CorrectionAllFile, &arg);
}

//ETRI ��û ����
void UCFCorrectionAllFile2(void* _pPnuNlp, const char* _szInputFile, int _nSpellingLevel, unsigned int _spellOpt, void* _pProgressData, bool _bPrintTime, unsigned int _nLoopLimit)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szInputFile;
	arg.pPointer1 = _pProgressData;
	arg.nInt1 = _nSpellingLevel;
	arg.nInt2 = _spellOpt;
	arg.nInt3 = _bPrintTime;
	arg.nInt4 = _nLoopLimit;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_CorrectionAllFile2, &arg);
}

//bool UCFIsOccurException(void* _pPnuNlp)
//{
//	UAssert(_pPnuNlp);
//	return TRUE==((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsOccurException);
//}

void UCFUserDicClear(void* _pPnuNlp)
{
	UAssert(_pPnuNlp);
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_UserDicClear);	
}

void UCFGetSystemVer(void* _pPnuNlp, char _szOutBufDLLVer[], char _szOutBufDLLEditDay[], char _szOutBufRealBuildDay[], char _szOutBufDicEditDay[] )
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;	
	arg.pPointer1 = _szOutBufDLLVer;
	arg.pPointer2 = _szOutBufDLLEditDay;
	arg.pPointer3 = _szOutBufRealBuildDay;
	arg.pPointer4 = _szOutBufDicEditDay;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetSystemVer, &arg);
}

void UCFGetLog(void* _pPnuNlp, bool _bStartStop, char _szOutBuf[], int _nBufSize)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;	
	arg.nInt1 = (_bStartStop ? 1 : 0);
	arg.nInt2 = _nBufSize;
	arg.pPointer1 = _szOutBuf;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_GetLog, &arg);
}

// _szOutputPath==NULL�̸� ��Ʈ�е�� ������
void UCFShowUsedCompNounDic(void* _pPnuNlp, const char* _szOutputPath, bool _bShowWithNotePad)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;	
	arg.pConstPointer1 = _szOutputPath;
	arg.nInt1 = _bShowWithNotePad ? 1 : 0;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_ShowUsedCompNounDic, &arg);
}


void UCFAllowContinueSpace(void* _pPnuNlp, int _nMaxAllowContinueSpace)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;	
	arg.nInt1 = _nMaxAllowContinueSpace;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_AllowContinueSpace, &arg);
}

void UCFSetUserDicDir(void* _pPnuNlp, const char* _szUserDicDir)
{
	UAssert(_pPnuNlp);
	UAssert(_szUserDicDir);
	Arg_GeneralPurpos arg;	
	arg.pConstPointer1 = _szUserDicDir;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_SetUserDicDir, &arg);
}

void UCFUserDicToFile(void* _pPnuNlp, const char* _szPath, int _nDicType, bool _bAppend)
{
	UAssert(_pPnuNlp);
	UAssert(_szPath);
	Arg_GeneralPurpos arg;	
	arg.pConstPointer1 = _szPath;
	arg.nInt1 = _nDicType;
	arg.nInt2 = _bAppend ? 1 : 0;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_UserDicToFile, &arg);
}

void UCFUsedCompNounDicToFile(void* _pPnuNlp, const char* _szPath, bool _bAppend)
{
	UAssert(_pPnuNlp);
	UAssert(_szPath);
	Arg_GeneralPurpos arg;	
	arg.pConstPointer1 = _szPath;
	arg.nInt1 = _bAppend ? 1 : 0;
	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_UsedCompNounDicToFile, &arg);
}

bool UCFIsWordHCHAR(void* _pPnuNlp, wchar_t _w, bool _bWithBlank)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	arg.nInt2 = _bWithBlank ? 1 : 0;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsWordHCHAR, &arg);
}

bool UCFIsNormalWord(void* _pPnuNlp, wchar_t _w, bool _bWithBlank, bool _bWithBrace)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	arg.nInt2 = _bWithBlank ? 1 : 0;
	arg.nInt3 = _bWithBrace ? 1 : 0;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsWordHCHAR, &arg);
}

bool UCFIsJohabHanja(void* _pPnuNlp, wchar_t _w)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsJohabHanja, &arg);
}

bool UCFIsJohabHangul(void* _pPnuNlp, wchar_t _w)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsJohabHangul, &arg);
}

bool UCFIsAlpha(void* _pPnuNlp, wchar_t _w)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsAlpha, &arg);
}

bool UCFIsDigit(void* _pPnuNlp, wchar_t _w)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsDigit, &arg);
}

bool UCFIsAlnum(void* _pPnuNlp, wchar_t _w)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsAlnum, &arg);
}

bool UCFIsBlank(void* _pPnuNlp, wchar_t _w, bool _bIncludeTab)
{
	UAssert(_pPnuNlp);
	Arg_GeneralPurpos arg;
	arg.nInt1 = (int)_w;
	arg.nInt2 = _bIncludeTab ? 1 : 0;
	return 0 != ((PnuNlp*)_pPnuNlp)->UserCmd(UCC_IsBlank, &arg);
}

void UCFTBTCorrectionW(void* _pPnuNlp, const wchar_t* _szOrgStr, int _nSpellingLevel, int _nBufSize, wchar_t _szOutBuf[], unsigned int _spellOpt, unsigned int _nLoopLimit)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szOrgStr;
	arg.pPointer1 = _szOutBuf;
	arg.nInt3 = _nBufSize;
	arg.nInt1 = _nSpellingLevel;
	arg.nInt2 = _spellOpt;
	arg.nInt4 = _nLoopLimit;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_TBTCorrectionFile, &arg);
}
void UCFTBTCorrectionFile(void* _pPnuNlp, const char* _szInputFile, int _nSpellingLevel, unsigned int _spellOpt, void* _pProgressData, bool _bPrintTime, unsigned int _nLoopLimit)
{
	UAssert(_pPnuNlp);

	Arg_GeneralPurpos arg;
	arg.pConstPointer1 = _szInputFile;
	arg.pPointer1 = _pProgressData;
	arg.nInt1 = _nSpellingLevel;
	arg.nInt2 = _spellOpt;
	arg.nInt3 = _bPrintTime;
	arg.nInt4 = _nLoopLimit;

	((PnuNlp*)_pPnuNlp)->UserCmd(UCC_TBTCorrectionFile, &arg);
}

//#endif

