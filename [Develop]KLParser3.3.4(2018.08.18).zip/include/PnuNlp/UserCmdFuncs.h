#pragma once

#include "UserCmdDefs.h"
//#ifdef PNUNLP_EXPORTS
//#	include "../api/PnuNlp.h"
//#else
//#	include "PnuNlp.h"
//#endif

//#ifdef MA_EX_VER

#ifndef NULL
#define NULL 0
#endif

const char* UCFGetDicPath(void *_pPnuNlp);
void UCFGetPnuNlpMorpResult(void *_pPnuNlp, const char* _szSource, void *_pPnuNlpMorpResult, unsigned short *_pPosViablePrefix=NULL);
//bool UCFOpenPnuNlp(void *_pPnuNlp, const char* _szDicPath, unsigned int _mode_pnudic_loader=0);
void UCFGetMorpResult(void *_pPnuNlp, const char* _szSource, const void **ppMR);
//void UCFMRBoundTest(void *_pPnuNlp, const char* _szSource);
//void UCFMakePreMADic(void *_pPnuNlp, const char* _szSource1=NULL, const char* _szSource2=NULL);
char* UCFGetMorpString(void *_pPnuNlp, const char* _szSource, char* _szResult, bool _bHideOverInfo=false, bool _bOnelinePrint=false, bool _bPrintExinfo=true, bool _bPrintOyong=true);
char* UCFGetDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult);
char* UCFGetSpecialDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult);
char* UCFGetJosaDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult);
char* UCFGetEomiDicInfo(void *_pPnuNlp, const char* _szSource, char* _szResult);
//const void* UCFGetOyongStr(void *_pPnuNlp, unsigned long _posOfOyong);
int UCFCheckPlaceInfo(void* _pPnuNlp, const char* _phszPlace1, int _nPlaceExinfo1, const char* _phzPlace2, int _nPlaceExinfo2);	// _phszPlace1 -> �����δ� HCHAR* type��
void UCFStatSpacingProc(void* _pPnuNlp, const char* _szText, char* _szResult, int _bViablePrefix, int _bMeanCheck);
void UCFBuildAllDic(void* _pPnuNlp, void* _hConsole, const char* _szSourceDir, const char* _szResultDir, unsigned long _nOPTION);
void UCFBuildExUserDic(void* _pPnuNlp, void* _hConsole, const char* _szSourceFile, const char* _szResultDir);
//void UCFGetUnderlinedStr(void* _pPnuNlp, const char* _szOrgStr, char _szOutBuf[], int _nBufLen, const Arg_3Int* _pLineInfos, int _nNumOfInfo);
//void UCFGetUnderlinedStrW(void* _pPnuNlp, const wchar_t* _szOrgStr, wchar_t _szOutBuf[], int _nBufLen, const Arg_3Int* _pLineInfos, int _nNumOfInfo);
int UCFCorrectionAll(void* _pPnuNlp, const char* _szOrgStr, int _nSpellingLevel, int _nBufSize, char _szOutBuf[], unsigned int _spellOpt=PNU_SPELLER_OPTION_ALL, unsigned int _nLoopLimit=10);
int UCFCorrectionAll2(void* _pPnuNlp, const char* _szOrgStr, int _nSpellingLevel, int _nBufSize, char _szOutBuf[], char _szOutBuf1[], unsigned int _spellOpt=PNU_SPELLER_OPTION_ALL, unsigned int _nLoopLimit=10);
int UCFCorrectionAllW(void* _pPnuNlp, const wchar_t* _szOrgStr, int _nSpellingLevel, int _nBufSize, wchar_t _szOutBuf[], unsigned int _spellOpt=PNU_SPELLER_OPTION_ALL, unsigned int _nLoopLimit=10);
bool UCFCombineDic(void* _pPnuNlp, const char* _szDicPath);
void UCFSetGlobalBitOpt(void* _pPnuNlp, unsigned int code, bool _bToActive);
void UCFSpeedTest(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, const /*PrintCMBitset*/ void* _pPrintCorrectMethods, void* _pProgressData=NULL, bool _bForPrecisionCheck=false);
void UCFFileSpelling(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, const /*PrintCMBitset*/ void* _pPrintCorrectMethods, void* _pProgressData=NULL, bool _bForPrecisionCheck=false, bool _bExcelForm=false);
//void UCFWFileSpelling(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, const /*PrintCMBitset*/ void* _pPrintCorrectMethods, void* _pProgressData=NULL);
void UCFTaggingCorrectMethodW(void* _pPnuNlp, const char* _szInputFile, DWORD _CurOption, void* _pProgressData=NULL);
char* UCFUNICode2Wansung(void* _pPnuNlp, const wchar_t* _wszInput, char* _szResult);
wchar_t* UCFWansung2UNICode(void* _pPnuNlp, const char* _szInput, wchar_t* _wszResult);
void UCFSetTimeLimit(void* _pPnuNlp, bool _bToActive, int _nMilliSeconds);
void UCFRestartTimeLimit(void* _pPnuNlp);
void UCFCorrectionAllFile(void* _pPnuNlp, const char* _szInputFile, int _nSpellingLevel, unsigned int _spellOpt, void* _pProgressData, bool _bPrintTime, unsigned int _nLoopLimit=10);
void UCFCorrectionAllFile2(void* _pPnuNlp, const char* _szInputFile, int _nSpellingLevel, unsigned int _spellOpt, void* _pProgressData, bool _bPrintTime, unsigned int _nLoopLimit=10);
//bool UCFIsOccurException(void* _pPnuNlp);
void UCFUserDicClear(void* _pPnuNlp);
void UCFGetSystemVer(void* _pPnuNlp, char _szOutBufDLLVer[], char _szOutBufDLLEditDay[], char _szOutBufRealBuildDay[], char _szOutBufDicEditDay[] );
void UCFGetLog(void* _pPnuNlp, bool _bStartStop, char _szOutBuf[], int _nBufSize);
void UCFShowUsedCompNounDic(void* _pPnuNlp, const char* _szOutputPath=NULL, bool _bShowWithNotePad=true);
void UCFAllowContinueSpace(void* _pPnuNlp, int _nMaxAllowContinueSpace);
void UCFSetUserDicDir(void* _pPnuNlp, const char* _szUserDicDir);
void UCFUserDicToFile(void* _pPnuNlp, const char* _szPath, int _nDicType, bool _bAppend);
void UCFUsedCompNounDicToFile(void* _pPnuNlp, const char* _szPath, bool _bAppend);

bool UCFIsWordHCHAR(void* _pPnuNlp, wchar_t _w, bool _bWithBlank);
bool UCFIsNormalWord(void* _pPnuNlp, wchar_t _w, bool _bWithBlank, bool _bWithBrace);
bool UCFIsJohabHanja(void* _pPnuNlp, wchar_t _w);
bool UCFIsJohabHangul(void* _pPnuNlp, wchar_t _w);
bool UCFIsAlpha(void* _pPnuNlp, wchar_t _w);
bool UCFIsDigit(void* _pPnuNlp, wchar_t _w);
bool UCFIsAlnum(void* _pPnuNlp, wchar_t _w);
bool UCFIsBlank(void* _pPnuNlp, wchar_t _w, bool _bIncludeTab);
void UCFTBTCorrectionW(void* _pPnuNlp, const wchar_t* _szOrgStr, int _nSpellingLevel, int _nBufSize, wchar_t _szOutBuf[], unsigned int _spellOpt=PNU_SPELLER_OPTION_ALL, unsigned int _nLoopLimit=10);
void UCFTBTCorrectionFile(void* _pPnuNlp, const char* _szInputFile, int _nSpellingLevel, unsigned int _spellOpt, void* _pProgressData, bool _bPrintTime, unsigned int _nLoopLimit=10);



//#endif
