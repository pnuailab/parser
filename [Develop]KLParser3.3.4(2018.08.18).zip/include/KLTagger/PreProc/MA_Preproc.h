enum PRE_TOKEN_TYPE {P_NORMAL, P_REMOVEBRACE};

void MA_PreProc(const char* in, char* out,PRE_TOKEN_TYPE opt);
void MA_PreProc(char* str, PRE_TOKEN_TYPE opt);
//void Replace_HangulToHanja(char* str);
//unsigned hanja_conv(char hbyte,char lbyte);
//int hanja_bsearch(unsigned item);
void Remove_Brace_Content(char* in,char open_brace,char close_brace);

void Convert2ByteTo1Byte(char* str);
void Convert1ByteTo2Byte(char* str);
