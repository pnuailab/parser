//////////////////////////////////////////////////////////////////////////////////////////
//
//  �����̸� : KLTagger.h
//  ��  �� : �±��� �����ϴ� Ŭ������ ������. 
//  �� �� �� : �� �� ��
//  ��  ¥ : 2004-11-26
//														
//////////////////////////////////////////////////////////////////////////////////////////
#ifndef __KLTAGGER_H__
#define __KLTAGGER_H__
#pragma once

#ifndef KLTAGGERLIB_API 
#ifdef KLTLIB_EXPORTS
#		define KLTAGGERLIB_API __declspec(dllexport)
#else
#		define KLTAGGERLIB_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	KLTAGGERLIB_API
#		define	KLTAGGERLIB_API
#endif

#include "include/KLTTypeMng/TagTypeDefs.h"
#include "include/KLTTypeMng/TagString.h"
#include "include/Tools/tools.h"
#include "include/PnuNlp/PnuNlpAddon.h"
#include "include/PnuNlp/PnuNlpAddon.h"//"
#include <fstream>

#ifdef USE_PROBABILITY
#	include "include/ProbabilityMng/ProbabilityMng.h"
#endif

using namespace std;


#define PNUDIC_LOADER_LOAD_BASIC			0x00000001

//////////////////////////////////////////////////////////////////////////
//	CountInTagging
//////////////////////////////////////////////////////////////////////////
class CountInTagging
{
public:
	int iCountOfLastTagging;	// �Ʒ� ���� iCountOfLastTagging�� ����ϱ� ���ؼ��� �� �Լ� DoTagging�� ȣ���ϱ� �� �ʱ�ȭ�ؾ��Ѵ�.
	int iCountOfAmbiguity[MAX_MORP];		// ���Ǽ� ī��Ʈ. ù �±� ���� �ʱ�ȭ�ؾ���
	int iCountOfGuessingAmbiguity[MAX_MORP];		// �̵�Ͼ� ������ �� �� ���Ǽ� ī��Ʈ. ù �±� ���� �ʱ�ȭ�ؾ���

	CountInTagging** m_ppEmptyPointForUsingThis;

public:
	CountInTagging();
	CountInTagging(CountInTagging** _ppEmptyPointForUsingThis);	// m_pCount ����. �Լ� ���� �� �ڵ� NULL ����
	~CountInTagging();
	void Clear();
};

//////////////////////////////////////////////////////////////////////////
//	KLTagger
//////////////////////////////////////////////////////////////////////////

class KLTAGGERLIB_API KLTagger
{
private:
	bool			m_bClone;
	CountInTagging* m_pCount;
	BufferMng		m_bufferMng;
public:
	void* m_pTagger;			// Tagging Ŭ����
	PnuNlp* m_pPnuNlp;			// PnuNlp Ŭ����
	void* m_pKMA;
	void* m_pKMAPostProc;
	void* m_pEngSpeller;
public:
	//////////////////////////////////////////////////////////////////////////
	//KLTagger();
	KLTagger(const char* DicPath = NULL, int nTokenRingSize = -1, unsigned int mode_pnudic_loader = PNUDIC_LOADER_LOAD_BASIC, unsigned short *pStdTagPOSMergingTable = NULL, unsigned short *pStdTagPOSLevelingTable = NULL);
	KLTagger(KLTagger &_other);
	~KLTagger();

	bool LoadEnv(const char* DicPath, int nTokenRingSize = -1, unsigned int mode_pnudic_loader = PNUDIC_LOADER_LOAD_BASIC, unsigned short *pStdTagPOSMergingTable = NULL, unsigned short *pStdTagPOSLevelingTable = NULL);
	void UnLoadEnv();

	//////////////////////////////////////////////////////////////////////////////////
	// �±� ���� ���� �Լ�			
	char*	DoTagging(const char* const_strInput, TaggingOption printformat, TagString* pDestTS = NULL);
	int DoTaggingFromKeyIn(char* _strSen, TaggingOption& _opt, bool _bSaveAnalysis = false, bool _bProbCalLog = false, bool _bPrintToConsole = false);
	void  DoTaggingFromFile(const char* filename, TaggingOption& opt, const char* outfile = NULL, ProgressData * pProgressData = NULL, bool _bProgressPrintToConsole = false);//, bool *pbStop=NULL, __int64 *pCurPOS=NULL, int *pNumOfTaggedToken=NULL, int *pNumOfTaggedSentence=NULL);

																																						  //strList*	DoTaggingForEvalModel(char* strSen, TaggingOption opt);
	void DoTaggingForEvalModel(const char* inputFile, const char* outputFile, ProgressData* pProgressData, TaggingOption opt, int ver);
	TagString*	DoTaggingExp(char* strSen, TaggingOption& opt, char* pRemainStr = NULL, bool IsApplyRule = true);
	int BuildTeggedCorpus1(char* inputFile, bool bApplyProbability, bool bApplyRule, ProgressData* pProgressData);
	void EvaluateMain(const char* inputFileName, const char* outDir, bool bEvalWithOldCorpus, ProgressData* pProgressData, TaggingOption opt, int ver);
	double DetailEvaluate(const char* answerFile, const char* testFile, const char* reportFile, const char* performanceFile, ProgressData* pProgressData, int ver);

	//////////////////////////////////////////////////////////////////////////////////
	// ��ƿ��Ƽ
	//const char* HCHARP_To_CharP(const HCHAR hsWord[], int posStart, int start_only_jongsung, int nLength, int end_remove_jongsung);
	//void HCHARP_To_CharP(char* result, const HCHAR hsWord[]);
	//static void ConvertJohapToWansung(HCHAR* source,char* result);
	//const char* GetTagEngName(Morpheme& morp , unsigned short* level);
	TagPOSMng* GetTagPOSMngPtr();
	//TagPOSMng* GetTagPOSMng();
	TagPOSMergingMng* GetTagPOSMergingMngPtr();

	int Spelling(char* str, int _nSpellingLevel, bool _bMakeSpellingLog, list<PnuNlpMorpResult>* listMorpResult);

#ifdef USE_PROBABILITY
	bool LoadProbabilityDic();
	bool LoadProbabilityDic(const SimpleProbabilityOpt &simpleProbabilityOpt, int type = 0);
	double GetEojeolProbability(MAList &malist);
	string GetStrDicInfo(bool bSimple = false);
#endif	 

	int GetMorpResult(Token &token, char* str = NULL);
	const char* GetDicPath() const;
	bool IsDicOpen();
};

#endif//__KLTAGGER_H__

















