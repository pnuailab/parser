// KLTMA.h : KLTMA DLL�� �⺻ ��� �����Դϴ�.
//

#pragma once

#ifndef KLTAGGERMA_API
#ifdef KLTMA_EXPORTS
#		define KLTAGGERMA_API __declspec(dllexport)
#else
#		define KLTAGGERMA_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	KLTAGGERMA_API
#		define	KLTAGGERMA_API
#endif
//
//#ifdef	LINUX_PORTING
//#	include "../stdafx.h"
//#	include "../MacOSIncludes/mac_inc.h"
//#else
//#	include <Windows.h>
//#endif

#include "include/PnuNlp/PnuNlpAddon.h"//"
#include "include/KLTTypeMng/TagString.h"


class KLTAGGERMA_API KLTMA
{
	void* m_pTokenizer;
	void* m_pPnuNlp;
public:
	string m_strExceptionMsg;
public:
	KLTMA(void *_pPnuNlp, TaggingOption *_pTaggingOption=NULL);
	KLTMA(const char *_szDicPath, TaggingOption *_pTaggingOption=NULL, unsigned int _mode_pnudic_loader=0);
	~KLTMA();

	void SetTaggingOption(TaggingOption *_pTaggingOption);

	char* KLT_MA(list<PnuNlpMorpResult>* listMorpResult, char* _szSource, TagString &_TS, bool _PreDefinedTokenAnalysis(char* in, int len, int &i, void* pPreToken, void* pToken, void *tokenizer), bool _bProcBrace = false);
	
	// [2008.07.30] ��ȣ ���� ����
	//const char* GetFirstBrace();
	//int GetSizeOfMarkStack();
	int GetProcessedTokenCount();
	void ResetProcessedTokenCount();
	int GetMorpResult(Token &token, char* str=NULL);
	void* GetPnuNlp(){return m_pPnuNlp;}
};
