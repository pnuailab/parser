
#pragma once

#ifndef KLTAGGERMA_API
#ifdef KLTMA_EXPORTS
#		define KLTAGGERMA_API __declspec(dllexport)
#else
#		define KLTAGGERMA_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	KLTAGGERMA_API
#		define	KLTAGGERMA_API
#endif

#include "include/KLTTypeMng/TagTypeDefs.h"
#include "include/KLTTypeMng/TagString.h"
#include <vector>

using namespace std;
class Token;


class TokenHistoryMng
{
	vector<Token*> m_TokenVec;
	int m_nGuessLen;
public:	
	TagString* m_pPrevTS;
	const char* m_szNextSen;
public:
	~TokenHistoryMng();
	Token* push_back();	// ������ ���� �ѱ��ʿ����� ��
	void pop_back();
	void pop_front();
	Token* operator[](int idx);    
	Token* front();
	Token* back();
	size_t size();
	void swap(int idx1, int idx2);
	void clear(){m_TokenVec.clear();m_nGuessLen=0;}
	int GetGuessLen(){return m_nGuessLen;}
	void SetGuessLen(int _len){m_nGuessLen=_len;}
};

