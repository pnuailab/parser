
#pragma once

#ifndef KLTAGGERMA_API
#ifdef KLTMA_EXPORTS
#		define KLTAGGERMA_API __declspec(dllexport)
#else
#		define KLTAGGERMA_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	KLTAGGERMA_API
#		define	KLTAGGERMA_API
#endif

#include "include/KLTTypeMng/TagTypeDefs.h"
#include "include/KLTTypeMng/TagString.h"
#include "TokenHistoryMng.h"

using namespace std;
class Token;
class Tokenizer;
class HCHAR;




class KLTAGGERMA_API VPBasedGuessing
{
	TokenHistoryMng m_tokens;
	TagString *m_pTS;

	void *m_pTokenizer;

public:
	VPBasedGuessing(void *_pTokenizer);	
    //const Token* GetToken(int _idx);
	size_t Size(){return m_tokens.size();}
	TokenHistoryMng& GetTokenHistory(){return m_tokens;}

	int DoGuessing(const char* _szSource, int _numOfBytes=-1, TagString *_pTS=NULL, bool _bTryGuessing=true, bool _bDontTrySpacingGuessing=false);
	
protected:
	int ConcatableWithPrevToken(Token* _pPrevToken, const char* _szSource, int _numOfBytes);
	const char* AnlalysisByVP(const char* _szSource, int _numOfBytes=-1);
	bool AvalibleVP(int _posViablePrefix, const char* _pEnd, const char* _szCantAnalised, const char** _pszCurrSource, int &_numOfCurrBytes);
	void ProcPostMAFail(const char* _szCantAnalised, const char* _szCurrSource);
	bool ReadyNewProc(Token** _ppToken, const char* _szSource, const char* _pEnd, const char** _pszCantAnalised, const char** _pszCurrSource, int &_numOfCurrBytes, bool _bBegWithWhiteSpace);
	bool ResetBoundary(Token *_pToken, const char* _szCurrSource, int &_numOfCurrBytes);	
	const char*  AnlalysisByNoneVP(const char* _szNextSource, bool _bDontTrySpacingGuessing);	// �м� ������ ��ū�� AnlalysisByNoneVP()�� �м��غ���
	void AnlalysisByNoneVP(Token &_currToken, const char* _szSource, int _numOfBytes=-1, Token *_pPrevToken=NULL, const Token *_pNextToken=NULL, bool bMaximumSimple=true);
	//void NounGuessingByContext(Token &_currToken, const char* _szSource, int _numOfBytes=-1, Token *_pPrevToken=NULL, const Token *_pNextToken=NULL);
	void BackwardGuessing(Token &_currToken, const char* _szSource, int _numOfBytes=-1, Token *_pPrevToken=NULL, const Token *_pNextToken=NULL, bool *_pbOutDefiniteNounAnalized=NULL);

	const char* Recomp(const char* _szSource, int &_numOfBytes);

	Token* Get40GussingResult(const char* _szGuessText, int numOfBytesOfSource);	// 46 + something���� �Խ��ϴ� �Լ�.	2016.05.21 ����ȣ.
	Token* Get106GussingResult(const char* _szGuessText, int numOfBytesOfSource);	// 106 + something���� �Խ��ϴ� �Լ�.	2016.05.21 ����ȣ.

private:
	const Token* GetNextTokenByEarlyAnalysis(const char** _ppszNextSource);	// ���� ������ �̸� �м��ؼ�, �Խ̿� ���(������ �ʿ��� ��쵵 �����Ƿ� �м��� �� �� ��� �̸� �м��ؼ� �����)
	Token* GetToken(int _idx);

	//bool GuessPersonName(Token &_currToken, const char* _szSource, int _numOfBytes=-1, Token *_pPrevToken=NULL, const Token *_pNextToken=NULL);
	//bool GuessPlaceName(Token &_currToken, const char* _szSource, int _numOfBytes=-1, Token *_pPrevToken=NULL, const Token *_pNextToken=NULL);
	//bool GuessPlaceNameByPlaceName(Token &_currToken, const char* _szSource, int _numOfBytes=-1, const Token *_pPrevToken=NULL, const Token *_pNextToken=NULL);
	//bool GuessPlaceNameByBackNoun(Token &_currToken, const char* _szSource, int _numOfBytes=-1, const Token *_pNextToken=NULL);
	//bool GuessPlaceNameByFrontNoun(Token &_currToken, const char* _szSource, int _numOfBytes=-1, Token *_pPrevToken=NULL);
	//bool GuessPlaceNameByPostfix(Token &_currToken, const char* _szSource, int _numOfBytes=-1);
	//bool GuessPlaceNameByPrefix(Token &_currToken, const char* _szSource, int _numOfBytes=-1);
	//bool GuessMechineName(Token &_currToken, const char* _szSource, int _numOfBytes=-1);

	//int DoAnlalysisByVP(Token &_token, const char* _szSource, WORD _initViablePrefix);
    
};

bool DoVPBasedGuessing(void *_pTokenizer, Token &_currToken, const char* _szSource, int _numOfBytes=-1, bool _bTryGuessing=true, bool _bDontTrySpacingGuessing=false);