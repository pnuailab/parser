#pragma once

#include "stdafx.h"
#include "stdafx.win_ce.h"
#include <time.h>


long clock_mobile()
{
	return GetTickCount() * (CLOCKS_PER_SEC/1000);
	
}


//long clock_mobile()
//{
//	static bool bFirstCall = true;
//	static __time64_t startTime;
//
//	SYSTEMTIME tmpSysTime;
//	GetSystemTime(&tmpSysTime);
//
//	if(bFirstCall)
//	{
//		startTime = _mktime64(&GetCurrentTM_Mobile(tmpSysTime));
//		bFirstCall = false;
//		return 1;
//	}
//	else
//	{
//		__time64_t currTime = _mktime64(&GetCurrentTM_Mobile(tmpSysTime));
//		return long( (__int64(currTime)-(__int64)(startTime)) + tmpSysTime.wMilliseconds ) * CLOCKS_PER_SEC;
//	}
//
//
//	//HANDLE currentThread = GetCurrentThread();
//
//	//FILETIME creationTime, exitTime, kernalTime, userTime;
//
//	//GetThreadTimes( currentThread, &creationTime, &exitTime, &kernalTime, &userTime );
//
//
//
//	//ULARGE_INTEGER uli;
//
//	//uli.LowPart = userTime.dwLowDateTime; 
//
//	//uli.HighPart = userTime.dwHighDateTime;
//
//	//ULONGLONG systemTimeInMS = uli.QuadPart/10000;
//
//	//return (long)systemTimeInMS;
//}


//struct tm {
//	int tm_sec;     /* seconds after the minute - [0,59] */
//	int tm_min;     /* minutes after the hour - [0,59] */
//	int tm_hour;    /* hours since midnight - [0,23] */
//	int tm_mday;    /* day of the month - [1,31] */
//	int tm_mon;     /* months since January - [0,11] */
//	int tm_year;    /* years since 1900 */
//	int tm_wday;    /* days since Sunday - [0,6] */
//	int tm_yday;    /* days since January 1 - [0,365] */
//	int tm_isdst;   /* daylight savings time flag */
//};

//typedef struct _SYSTEMTIME {
//	WORD wYear;					// The current year. 
//	WORD wMonth;				// The current month; January is 1. 
//	WORD wDayOfWeek;			// The current day of the week; Sunday is 0, Monday is 1, and so on. 
//	WORD wDay;					// The current day of the month. 
//	WORD wHour;					// The current hour. 
//	WORD wMinute;				// The current minute. 
//	WORD wSecond;				// The current second. 
//	WORD wMilliseconds;			// The current millisecond. 
//} SYSTEMTIME;



struct tm GetCurrentTM_Mobile()
{
	SYSTEMTIME curTime;
	GetSystemTime(&curTime);
	return GetCurrentTM_Mobile(curTime);
}

struct tm GetCurrentTM_Mobile(SYSTEMTIME &_curTime)
{
	struct tm t;
	t.tm_year	= _curTime.wYear-1900;
	t.tm_mon	= _curTime.wMonth-1;
	//t.tm_yday   = _curTime.
	t.tm_mday	= _curTime.wDay;
	t.tm_wday	= _curTime.wDayOfWeek;
	t.tm_hour	= _curTime.wHour;
	t.tm_min	= _curTime.wMinute;
	t.tm_sec	= _curTime.wSecond;

	return t;	
}

