#include "../stdafx.h"
#include "mac_conv.cxx"
//#include <iconv.h>


/****************************************************************************
*****************************************************************************
*****************************************************************************
				<<< Win32 Function Emulation for MacSOX>>>

		MultiByteToWideChar
		WideCharToMultiByte
		GetProcessHeap
		HeapAlloc
		HeapReAlloc

*****************************************************************************
*****************************************************************************
****************************************************************************/



/****************************************************************************
*****************************************************************************

            GNU LIBICONV - character set conversion library

This library provides an iconv() implementation, for use on systems which
don't have one, or whose implementation cannot convert from/to Unicode.

It provides support for the encodings:

    European languages
        ASCII, ISO-8859-{1,2,3,4,5,7,9,10,13,14,15,16},
        KOI8-R, KOI8-U, KOI8-RU,
        CP{1250,1251,1252,1253,1254,1257}, CP{850,866},
        Mac{Roman,CentralEurope,Iceland,Croatian,Romania},
        Mac{Cyrillic,Ukraine,Greek,Turkish},
        Macintosh
    Semitic languages
        ISO-8859-{6,8}, CP{1255,1256}, CP862, Mac{Hebrew,Arabic}
    Japanese
        EUC-JP, SHIFT_JIS, CP932, ISO-2022-JP, ISO-2022-JP-2, ISO-2022-JP-1
    Chinese
        EUC-CN, HZ, GBK, CP936, GB18030, EUC-TW, BIG5, CP950, BIG5-HKSCS,
        BIG5-HKSCS:2001, BIG5-HKSCS:1999, ISO-2022-CN, ISO-2022-CN-EXT
    Korean
        EUC-KR, CP949, ISO-2022-KR, JOHAB
    Armenian
        ARMSCII-8
    Georgian
        Georgian-Academy, Georgian-PS
    Tajik
        KOI8-T
    Kazakh
        PT154, RK1048
    Thai
        ISO-8859-11, TIS-620, CP874, MacThai
    Laotian
        MuleLao-1, CP1133
    Vietnamese
        VISCII, TCVN, CP1258
    Platform specifics
        HP-ROMAN8, NEXTSTEP
    Full Unicode
        UTF-8
        UCS-2, UCS-2BE, UCS-2LE
        UCS-4, UCS-4BE, UCS-4LE
        UTF-16, UTF-16BE, UTF-16LE
        UTF-32, UTF-32BE, UTF-32LE
        UTF-7
        C99, JAVA
    Full Unicode, in terms of `uint16_t' or `uint32_t'
        (with machine dependent endianness and alignment)
        UCS-2-INTERNAL, UCS-4-INTERNAL
    Locale dependent, in terms of `char' or `wchar_t'
        (with machine dependent endianness and alignment, and with OS and
        locale dependent semantics)
        char, wchar_t
        The empty encoding name "" is equivalent to "char": it denotes the
        locale dependent character encoding.

When configured with the option --enable-extra-encodings, it also provides
support for a few extra encodings:

    European languages
        CP{437,737,775,852,853,855,857,858,860,861,863,865,869,1125}
    Semitic languages
        CP864
    Japanese
        EUC-JISX0213, Shift_JISX0213, ISO-2022-JP-3
    Chinese
        BIG5-2003 (experimental)
    Turkmen
        TDS565
    Platform specifics
        ATARIST, RISCOS-LATIN1

It can convert from any of these encodings to any other, through Unicode
conversion.

*****************************************************************************
****************************************************************************/
// return number wide char + null
int MultiByteToWideChar(UINT codepage, DWORD, const char* inStr, int inLen, wchar_t* outUnicode, int maxLen)
{
#if 1
	return gcMB2WC(	codepage,						// code page
					inStr,							// string to map
					inLen,							// number of bytes in string
					(unsigned short*)outUnicode,	// wide-character buffer
					maxLen);						// size of buffer
#else
	iconv_t		cd;
	int			wcLen = 0;

	if(codepage == CP_Hanguel_Wansung){
		cd = iconv_open("UCS-2-INTERNAL", "CP949");
	}else if(codepage == CP_Hanguel_Johab){
		if((unsigned char)inStr[0] == 0x84 && (unsigned char)inStr[1] == 0x49){
			cd = (iconv_t)-1;
		}
		cd = iconv_open("UCS-2-INTERNAL", "JOHAB");
	}else{
		cd = (iconv_t)(-1);
		DebugStr("\p Unexpected CodePage");
	}

	if(cd != (iconv_t)(-1)){
		// set-up clone in-put buffer for iconv in-put(non const *)
		char*	pInPtr = NULL;
		char*	pInBuf = NULL;

		if(inLen < 0){
			inLen = strlen(inStr);
		}

		pInBuf = pInPtr = NewPtrClear((inLen * 2) + 2);
		memcpy(pInBuf, inStr, inLen);

		// set-up out-put buffer
		char*	pOutPtr = NULL;
		char*	pOutBuf = NULL;
		if(outUnicode == NULL || maxLen <= 0){
			maxLen = (sizeof(wchar_t) * inLen + 2);
			pOutBuf = pOutPtr = NewPtrClear(maxLen);
			outUnicode = (wchar_t*)pOutBuf;
		}else{
			maxLen *= 2;
			pOutBuf = (char*)outUnicode;
		}

		size_t	inbytes = inLen;
		size_t	outbytes = maxLen;
		if(iconv(cd, &pInBuf, &inbytes, &pOutBuf, &outbytes) == 0){
			wcLen = (maxLen - outbytes) / 2;
			outUnicode[wcLen++] = 0;	// number of bytes + null
		}else{
			int	eee = errno;
			if(eee != 0){
				eee = 0;
			}
//			assert(false);
		}
		iconv_close(cd);

		if(pInPtr != NULL){		DisposePtr(pInPtr);		}
		if(pOutPtr != NULL){	DisposePtr(pOutPtr);	}
	}
	
	return wcLen;
#endif	
}

// return number of bytes + null
int WideCharToMultiByte(UINT codepage, DWORD, const wchar_t* inUnicode, int inLen, char* outStr, int maxLen, int unused0, int unused1)
{
#if 1
	return gcWC2MB(	codepage,							// code page
					(const unsigned short*)inUnicode,	// wide-character string
					inLen,								// number of chars in string.
					outStr,								// buffer for new string
					maxLen);							// size of buffer
#else
	iconv_t		cd;
	int			mblen = 0;

	if(codepage == CP_Hanguel_Wansung){
		cd = iconv_open("CP949", "UCS-2-INTERNAL");
	}else if(codepage == CP_Hanguel_Johab){
		cd = iconv_open("JOHAB", "UCS-2-INTERNAL");
	}else{
		cd = (iconv_t)(-1);
		DebugStr("\p Unexpected CodePage");
	}

	if(cd != (iconv_t)(-1)){
		// set-up clone in-put buffer for iconv in-put(non const *)
		char*	pInPtr = NULL;
		char*	pInBuf = NULL;
		if(inLen < 0){
			inLen = MacWcslen(inUnicode);
		}

		pInBuf = pInPtr = NewPtrClear((inLen * 2) + 2);
		memcpy(pInBuf, inUnicode, inLen * 2);

		// set-up out-put buffer
		char*	pOutPtr = NULL;
		char*	pOutBuf = NULL;
		if(outStr == NULL || maxLen <= 0){
			maxLen = (inLen * 4);
			pOutBuf = pOutPtr = NewPtrClear(maxLen);
			outStr = pOutBuf;
		}else{
			pOutBuf = outStr;
		}

		size_t	inbytes = inLen * 2;
		size_t	outbytes = maxLen;
		if(iconv(cd, &pInBuf, &inbytes, &pOutBuf, &outbytes) == 0){
			mblen = (maxLen - outbytes);
			outStr[mblen++] = 0;	// number of bytes + null
			if((unsigned char)outStr[0] == 0x84 && (unsigned char)outStr[1] == 0x49){
				int fff = errno;
				if(fff == 0){
					fff = -1;
				}
			}
		}else{
//			assert(false);
			int	eee = errno;
			if(eee != 0){
				eee = 0;
			}
		}
		iconv_close(cd);

		if(pInPtr != NULL){		DisposePtr(pInPtr);		}
		if(pOutPtr != NULL){	DisposePtr(pOutPtr);	}
	}

	return mblen;
#endif
}

HANDLE GetProcessHeap()
{
	return 0;
}
LPVOID HeapAlloc(HANDLE heap, DWORD dwFlags, SIZE_T dwBytes)
{
#pragma unused (heap)
	return (LPVOID)NewPtrClear(dwBytes);
}
LPVOID HeapReAlloc(HANDLE heap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes)
{
#pragma unused (heap)
	Ptr	pNewMem;
	if((pNewMem = NewPtrClear(dwBytes)) != NULL){
		if(lpMem != NULL){
			memcpy(pNewMem, lpMem, dwBytes);
		}
		DisposePtr((Ptr)lpMem);
	}
	return pNewMem;
}
BOOL HeapFree(HANDLE heap, DWORD dwFlags, LPVOID lpMem)
{
	if(lpMem != NULL){
		DisposePtr((Ptr)lpMem);
		return TRUE;
	}
	return FALSE;
}


size_t MacWcslen(const wchar_t* ustr)
{
	size_t	len = 0;
	if(ustr != NULL){
		while(ustr[len] != 0){
			len++;
		}
	}
	return len;
}
wchar_t	*MacWcscpy(wchar_t* dst, const wchar_t* src)
{
	wchar_t*	ucp = dst;
	while((*ucp++ = *src++));
	return dst;
}


const char* MacPosixPath(const char* cszPathName)
{
	int				length;
	static UInt8	strPosixPath[2048];
	const char*		cszPosixPath = NULL;

	OSStatus		err;
	CFURLRef		appUrl;
	CFBundleRef		appBundle;
	FSRef			appFileFSRef;
	const char*		cszFileName;
	Boolean			bok = FALSE;

	if(cszPathName == NULL || strlen(cszPathName) == 0){
		return "";
	}else{
		if((cszFileName = strrchr(cszPathName, '/')) != NULL){
			cszFileName -= 1;
		}else if((cszFileName = strrchr(cszPathName, '\\')) != NULL){
			cszFileName -= 1;
		}else{
			cszFileName = cszPathName;
		}
	}

	appBundle = CFBundleGetMainBundle();
	appUrl = CFBundleCopyBundleURL(appBundle);
	bok = CFURLGetFSRef(appUrl, &appFileFSRef);
	CFRelease(appUrl);

	if(bok)
	{
		FSRef	appDirFSRef;
		if((err = FSGetCatalogInfo(&appFileFSRef, kFSCatInfoNone, NULL, NULL, NULL, &appDirFSRef)) == noErr)
		{
			FSRef			dicDirFRef;
			CFStringRef		dicDirName;
			CFIndex			nameLength;
			UniChar			dicNameChars[255];

			dicDirName = CFStringCreateWithCString(kCFAllocatorDefault, MAC_DICTIONARY_DIR_NAME, kCFStringEncodingMacKorean);
			nameLength = CFStringGetLength(dicDirName);
			CFStringGetCharacters(dicDirName, CFRangeMake(0, nameLength), &dicNameChars[0]);
			CFRelease(dicDirName);
			if((err = FSMakeFSRefUnicode(&appDirFSRef, nameLength, dicNameChars, CFStringGetSystemEncoding(), &dicDirFRef)) == noErr)
			{
				FSRef			dicFileFRef;
				CFStringRef		dicFileName;

				dicFileName = CFStringCreateWithCString(kCFAllocatorDefault, cszFileName, kCFStringEncodingMacKorean);
				nameLength = CFStringGetLength(dicFileName);
				CFStringGetCharacters(dicFileName, CFRangeMake(0, nameLength), &dicNameChars[0]);
				CFRelease(dicFileName);

				if((err = FSMakeFSRefUnicode(&dicDirFRef, nameLength, dicNameChars, CFStringGetSystemEncoding(), &dicFileFRef)) == noErr){
					FSCatalogInfo	catInfo;
					if((err = FSGetCatalogInfo(&dicFileFRef, kFSCatInfoGettableInfo, &catInfo, NULL, NULL, NULL)) == noErr)
					{
						err = FSRefMakePath(&dicFileFRef, strPosixPath, 2048);
						if(err == noErr){
							cszPosixPath = (const char*)strPosixPath;
#if 0	// for Debugging
							HFILE	hFile;
							if((hFile = open(cszPosixPath, O_RDONLY)) != HFILE_ERROR){
								close(hFile);
							}else{
								DebugStr("\pFile Open Failure!!");
							}
#endif
						}
					}
				}
			}
		}
	}

	return cszPosixPath;
}


