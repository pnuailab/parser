#ifndef __INCUBE_TECHNOLOGIES_MAC_INCLUDE__H__
#define __INCUBE_TECHNOLOGIES_MAC_INCLUDE__H__

#define _BACKWARD_BACKWARD_WARNING_H	0

#include <malloc.h>
#include <time.h>
#include <string.h>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
//#include <cstring>
#include <cctype>
#include <cwchar>
#include <fstream>
#include <iostream>
#include <bitset>
#include <list>
#include <ostream>
#include <stack>
#include <strstream>
#include <string>
#include <unistd.h>

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define EXTENSION_64BIT
#define	APIENTRY
#define	WINAPI
#define	_cdecl



#define INCUBE_PACK
#pragma GCC system_header
#undef _GLIBCXX_DEBUG

using namespace std;
//using namespace _GLIBCXX_STD;

#ifdef __cplusplus
extern "C" {
#endif

#define DEFAULT_PACK_SIZE 1

#ifndef TRUE
#define TRUE 1
#define FALSE 0
//#	define BOOL bool
//#	define Boolean bool
#endif
#define NULL 0

typedef bool				Boolean;
//typedef long unsigned int		size_t;
typedef long long			__int64;

typedef	void*				HANDLE;
typedef	void*				LPVOID;
typedef unsigned long long	DWORD64;
typedef unsigned int		DWORD;
typedef unsigned short		WORD;
typedef unsigned char		BYTE;
typedef int					BOOL;
typedef unsigned int		UINT;
typedef unsigned short		UINT16;
typedef unsigned int		UINT32;
typedef unsigned long		SIZE_T;

typedef int					HWND;

typedef unsigned long ULONG_PTR, *PULONG_PTR;

typedef ULONG_PTR DWORD_PTR, *PDWORD_PTR;

//#define wchar_t WORD

#define MAX_PATH          260

#define HIBYTE(w)	((BYTE)((WORD)(w) & 0xff))
#define LOBYTE(w)	((BYTE)((WORD)(w) >> 8))

#define LOWORD(l)           ((WORD)(((DWORD_PTR)(l)) & 0xffff))
#define HIWORD(l)           ((WORD)((((DWORD_PTR)(l)) >> 16) & 0xffff))

#define DLL_PROCESS_ATTACH	1
#define DLL_THREAD_ATTACH	2
#define DLL_THREAD_DETACH	3
#define DLL_PROCESS_DETACH	0

//
//  MBCS and Unicode Translation Flags.
//
#define MB_PRECOMPOSED            0x00000001  // use precomposed chars
#define MB_COMPOSITE              0x00000002  // use composite chars
#define MB_USEGLYPHCHARS          0x00000004  // use glyph chars, not ctrl chars
#define MB_ERR_INVALID_CHARS      0x00000008  // error for invalid chars

//
//  Code Page Default Values.
//
#define CP_ACP                    0           // default to ANSI code page
#define CP_OEMCP                  1           // default to OEM  code page
#define CP_MACCP                  2           // default to MAC  code page
#define CP_THREAD_ACP             3           // current thread's ANSI code page
#define CP_SYMBOL                 42          // SYMBOL translations
#define CP_UTF7                   65000       // UTF-7 translation
#define CP_UTF8                   65001       // UTF-8 translation

#ifdef MAC_PORTING
#	define CP_Hanguel_Wansung	1000
#	define CP_Hanguel_Johab		2000
#endif

// low-level file handling interfaces
#define	_O_RDONLY	O_RDONLY	/* 0x0000	open for reading only */
#define	_O_WRONLY	O_WRONLY	/* 0x0001	open for writing only */
#define _O_RDWR		O_RDWR		/* 0x0002	open for reading and writing */
#define	_O_APPEND	O_APPEND	/* 0x0008	set append mode */
#define	_O_BINARY	0			/* Posix support binary mode only for open function */

#define	_O_CREAT	O_CREAT
#define	_S_IREAD	S_IREAD
#define	_S_IWRITE	S_IWRITE

#define HFILE		int
#define HFILE_ERROR ((HFILE)-1)

#define	_stat		stat
#define	_open		open
#define	_fstat		fstat
#define	_read		read
#define	_write		write
#define	_close		close

// wide string functions
#define wcslen		MacWcslen
#define wcscpy		MacWcscpy
#define _itoa		itoa
#define __time64_t	time_t
#define _time64		time
#define _mktime64	mktime
#define _localtime64	localtime

#define CRITICAL_SECTION		pthread_mutex_t
//#define EnterCS(__cs)	printf("%s:%s()::%d: EnterCS:%s\n", __FILE__, __FUNCTION__, __LINE__, #__cs);pthread_mutex_lock ((pthread_mutex_t*)__cs)
//#define LeaveCS(__cs)	printf("%s:%s()::%d: LeaveCS:%s\n", __FILE__, __FUNCTION__, __LINE__, #__cs);pthread_mutex_unlock((pthread_mutex_t*)__cs)
#define EnterCS(__cs)	pthread_mutex_lock ((pthread_mutex_t*)__cs)
#define LeaveCS(__cs)	pthread_mutex_unlock((pthread_mutex_t*)__cs)




// <<< Win32 Function Emulation for MacSOX>>>
int MultiByteToWideChar(UINT, DWORD, const char*, int, wchar_t*, int);
int WideCharToMultiByte(UINT, DWORD, const wchar_t*, int, char*, int, int unused0, int unused1);
HANDLE GetProcessHeap();
LPVOID HeapAlloc(HANDLE heap, DWORD dwFlags, SIZE_T dwBytes);
LPVOID HeapReAlloc(HANDLE heap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes);
BOOL HeapFree(HANDLE heap, DWORD dwFlags, LPVOID lpMem);
char* itoa( int value, char* result, int base ) ;
wchar_t *_itow(int _i, wchar_t *_wsz, int base);
int _wtoi(const wchar_t *_wsz);
int _wtol(const wchar_t *_wsz);

void qsort__twin(void *base, size_t num, size_t width, int ( *comp)(const void *, const void *) );
#define qsort qsort__twin	// ���� ����: �� ���� ���� ���� ���� �� �������� ms �� qsort ����� �ٸ�.

void CopyFile(const char* _szSrc, const char* _szDest, bool b);

// ���������� �Ʒ� �� �Լ��� ���� �ʰ� wcslen() ���� ���� ������ ����
size_t MacWcslen(const wchar_t *);
wchar_t	*MacWcscpy(wchar_t *, const wchar_t *);

#define Sleep(uSeconds)		usleep(uSeconds)
#define stricmp(a, b)		strcasecmp((a), (b))
#define strnicmp(a, b, c)	strncasecmp((a), (b), (c))

#define wcsicmp(a, b)		wcscasecmp((a), (b))
#define wcsnicmp(a, b, c)	wcsncasecmp((a), (b), (c))



//#define MessageBox(a,b,c,d)	printf("[%s][%s]\n", b, c)
int MessageBox(int _a, const char* _b, const char* _c, int _d);
int MessageBoxW(int _a, const wchar_t* _b, const wchar_t* _c, int _d);
#define IDYES 1
#define MB_OK 1
#define MB_YESNO 1
#define DeleteFile(a) remove(a)



#ifdef UAssert
#undef UAssert
#endif

#ifdef _DEBUG
#define UAssert(__x)	assert(__x)
#else
#define UAssert(__x)	assert(true)
#endif

//////////////////////////////////////////////////////////////////////////
// <<< MacSOX Functions >>>
#ifdef MAC_PORTING
const char* MacPosixPath(const char* strFileName);


// <<< Directory Name for Mac NLP Dictionary >>>
#define MAC_DICTIONARY_DIR_NAME		((const char*)"NLPDictionary")



// <<< endian utilities for MacSOX >>>
#ifdef __LITTLE_ENDIAN__ 
#	define ENDIAN_ITOS(s)		(s)
#	define ENDIAN_ITOL(l)		(l)
#	define ENDIAN_ITOLL(ll)		(ll)
#else
typedef unsigned short		U16N;
typedef unsigned long		U32N;
typedef unsigned long long	U64N;
#	define ENDIAN_ITOS(s)		(((((U16N)(s))<<8)&0xff00)|((((U16N)(s))>>8)&0x00ff))
#	define ENDIAN_ITOL(l)		(((((U32N)(l))<<24)&0xff000000)|((((U32N)(l))<<8)&0x00ff0000)|((((U32N)(l))>>8)&0x0000ff00)|((((U32N)(l))>>24)&0x000000ff))
#	define ENDIAN_ITOLL(ll)		(((((U64N)(ll))<<56)&0xff00000000000000)|((((U64N)(ll))<<40)&0x00ff000000000000)|((((U64N)(ll))<<24)&0x0000ff0000000000)|((((U64N)(ll))<<8)&0x000000ff00000000)|((((U64N)(ll))>>8)&0x00000000ff000000)|((((U64N)(ll))>>24)&0x0000000000ff0000)|((((U64N)(ll))>>40)&0x000000000000ff00)|((((U64N)(ll))>>56)&0x00000000000000ff))
#endif

#define MAC_PATH(path)	MacPosixPath(path)



//////////////////////////////////////////////////////////////////////////
#else // MAC_PORTING

#define MAC_PATH(path)	(path)

#endif // MAC_PORTING else
//////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
}
#endif

#endif
