
#pragma once

#ifndef PROBABILITYMNG_API 
#ifdef PROBMNG_EXPORTS
#		define PROBABILITYMNG_API __declspec(dllexport)
#else
#		define PROBABILITYMNG_API __declspec(dllimport)
//#		define PROBABILITYMNG_EXPIMP_TEMPLATE extern
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	PROBABILITYMNG_API
#		define	PROBABILITYMNG_API
#endif

#include "include/KLTTypeMng/TagString.h"
#include "ProbabilityDef.h"
#include "ProbabilityOpt.h"
#include "ProbabilityDicMng.h"



class PROBABILITYMNG_API ProbabilityMng
{
public:
	ProbabilityMng(const char* dicPath, TagPOSMng *pTagPOSMng=NULL);

	// Ȯ�� ��� ��� ��å ����
	static int		GetProbabilityPolicy(const char* dicPath, SimpleProbabilityOpt *pSimpleProbabilityOpt);
	static int		GetProbabilityPolicy2(const char* dicPath, SimpleProbabilityOpt *pSimpleProbabilityOpt);

    // ��� ���� �ҷ�����
	inline bool isLoadedProbabilityDic();
	bool isLoadedEojeolProbabilityDic();
	bool isLoadedTransitionProbabilityDic();
	bool LoadProbabilityDic();
	bool LoadProbabilityDic(const SimpleProbabilityOpt &simpleProbabilityOpt);

	// ����Ȯ�� ����Ȯ�� ���
	double GetEojeolProbability(const MAList &malist);
	double GetTransitionProbability(const MAList &malist1, const MAList &malist2, bool bExistAlonMorp);

	void SetWriteCalLogFlag(bool bForTransition, bool bWrite);


	ProbabilityOpt		m_probabilityOpt;
	ProbabilityDicMng	*m_pEojeolProbabilityDicMng;
	ProbabilityDicMng	*m_pTransitionProbabilityDicMng;


	TagPOSMng*			m_pTagPOSMng;
	char				m_dicPath[1000];
};