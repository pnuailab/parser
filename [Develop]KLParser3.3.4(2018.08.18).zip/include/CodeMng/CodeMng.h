// CodeMng.h : CodeMng DLL�� �⺻ ��� �����Դϴ�.
//

#pragma once



//#ifndef __AFXWIN_H__
//	#error include 'stdafx.h' before including this file for PCH
//#endif
//
//#include "resource.h"		// �� ��ȣ�Դϴ�.


// CodeMng
// �� Ŭ������ ������ ������ CodeMng.cpp�� �����Ͻʽÿ�.
//

#ifndef CODEMNG_LIB_API
#ifdef	CODEMNG_LIB_EXPORTS
#		define	CODEMNG_LIB_API __declspec(dllexport)
#else
#		define CODEMNG_LIB_API __declspec(dllimport)
#endif
#endif

#ifdef	LINUX_PORTING
#		undef	CODEMNG_LIB_API
#		define	CODEMNG_LIB_API
#endif

#include	"CodeDefs.h"


class CODEMNG_LIB_API CodeMng
{
public:

	//CodeConvWin.h
	static wchar_t* _toUnicode(const char* s, int codepage=1/*CP_OEMCP*/);
	static char* _toMBCS(const wchar_t* ws, int codepage=1/*CP_OEMCP*/);

	static void _WansungToJohab(const char* in,char** out);
	static void _JohabToWansung(const char* in,char** out);
	static void _AsciiToUTF8(const char* in,char** out);
	static void _UTF8ToAscii(const char* in,char** out);

	static void _WansungToJohab(char* in);
	static void _JohabToWansung(char* in);
	static void _AsciiToUTF8(char* in);
	static void _UTF8ToAscii(char* in);


	//CodeDesc.h
	static int _codeAnalyzeWansung(const char *code);
	static int _getPunctuationIDWansung(const char *code);
	static int _NumOfBytesOfCodeWansung(const char *code, int _wantCode);

	
	//CodeFormat.h
	static void _FilteringStr(unsigned char tmp_buf[], char buf[]);
	static void _Hex2Johap(char Hex[],unsigned char Dec[]);
	static void _Hex2Wan(unsigned char hex[],unsigned char wan[]);
	static void _Oct2Wan(unsigned char oct[],unsigned char wan[]);
	static void _Wan2Oct(unsigned char wan[],unsigned char oct[]);
	static void _Wan2Hex(unsigned char wan[],unsigned char hex[]);
	static void _Oct2Johap(unsigned char oct[],unsigned char Dec[]);
	static void _Ten2Hex(int num,unsigned char H_buf[]);
	static char _conv_char(int n);


	//CodeUtils.h
	static bool _IsJohabHangul(char h, char l);
	static bool _IsJohabHangul(const HangulChar &johab);
	static bool _IsWansungHangul(char h, char l);
	static int _NumOfBytesOfJohabHangul(const char *szSource);
	static int _NumOfBytesOfWansungHangul(const char *szSource);

	static void _JongsungToChosung(HangulChar &johab);
	static void _ChosungToJongsung(HangulChar &johab);

	static void _JongsungToChosung(unsigned char *johab);
	static void _ChosungToJongsung(unsigned char *johab);

	static const char* _GetAsciiNum_Wansung(char *wansung);
	static const char* _GetAsciiNum_Wansung(char h, char l);

	//CodeConversion.h
	static int _ConversionString(BYTE stringbuffer[], int sourcehangultype, int targethangultype);


	//CodeConvHanja2.h
	static void _HanjaToHangulString(char* str);
	static unsigned _HanjaToHangul(char hbyte,char lbyte);
	static int _Hanja_bsearch(unsigned item);

};
