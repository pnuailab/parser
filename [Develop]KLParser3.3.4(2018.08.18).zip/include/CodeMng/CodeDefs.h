#pragma once



#define KMNS_HANGUL_WANSUNG	//MS Ȯ�� �ϼ��� �ڵ带 �� ��
//#define KMNS_HANGUL_JOHAB //������ �ڵ带 �� ��

enum CODE_DESCRIPTION
{
	CD_Unknown		= 0x0000,
	CD_Character	= 0x0001,
	CD_Numeric		= 0x0002,
	CD_WhiteSpace	= 0x0004,

	CD_NewLine		= 0x0008,

	CD_NewLine2		= 0x000D,	//�� �󿡼��� ����

	CD_CarrageRet	= 0x0010,
	CD_Period		= 0x0020,
	CD_Comma		= 0x0040,
	CD_Quotation	= 0x0080,
	CD_Parenthesis	= 0x0100,
	CD_Open			= 0x0200,
	CD_Close		= 0x0400,
	CD_Single		= 0x0800,
	CD_Double		= 0x1000,
	CD_Capital		= 0x2000,
	CD_Special		= 0x4000,
	CD_Delimeter	= 0x8000,	//word
	CD_Terminator	= 0x10000,	//sentence

	CD_HangulLetter	= 0x20000,
	CD_RomanNum		= 0x40000,
	CD_Greek		= 0x80000,
	CD_BoxDrawing	= 0x100000,
	CD_Unit			= 0x200000,
	CD_Latin		= 0x400000,
	CD_Japanese		= 0x800000,
	CD_Cyrillic		= 0x1000000,
	CD_Chinese		= 0x2000000,
	CD_Hangul		= 0x4000000,

	CD_Wide			= 0x80000000
};

//getPuncID()
enum PUNCTUATION_ID
{
	PID_WhiteSpace	= 1,	//0x0001, lsb == 1, if(x & PID_WhiteSpace)... 
	PID_Quatation	= 2,	//0x0002,
	PID_Parenthesis	= 4,	//0x0004,
	//= 0x0008,

	//combined with PID_WhiteSpace
	PID_Tab			= 17,	//0x0011,
	PID_LF			= 33,	//0x0021,
	PID_CR			= 65,	//0x0041,
	PID_SP			= 129,	//0x0081,

	//combined with PID_Quatation
	PID_QtDouble	= 258,	//0x0102,
	PID_QtSingle	= 514,	//0x0202,

	//combined with PID_Quatation or PID_Parenthesis
	PID_Open		= 1024,	//0x0400,
	PID_Close		= 2048,	//0x0800,

	//used independantly
	PID_Exclamation	= 4096,	//0x00001000,	//'!'
	PID_Comma		= 8192,	//0x00002000,	//','
	PID_Hyphen		= 16384,	//0x00004000,	//'-'
	PID_Period		= 32768,	//0x00008000,	//'.'
	PID_Solidus		= 65536,	//0x00010000,	//'/'
	PID_Colon		= 131072,	//0x00020000,	//':'
	PID_Semicolon	= 262144,	//0x00040000,	//';'
	PID_Question	= 524288,	//0x00080000,	//'?'
	PID_Tilde		= 1048576,	//0x00100000,	//'~'

	PID_Number		= 2097152,	//0x00200000,	//'#'
	PID_Dollar		= 4194304,	//0x00400000,	//'$'
	PID_Percent		= 8388608,	//0x00800000,	//'%'
	PID_Ampersand	= 16777216,	//0x01000000,	//'&'
	PID_Equal		= 33554432,	//0x02000000,	//'='
	PID_At			= 67108864,	//0x04000000,	//'@'
	PID_RvSolidus	= 134217728,	//0x08000000,	//'\' reverse solidus
	PID_LowLine		= 268435456,	//0x10000000,	//'_'
	PID_Unit		= 0x20000000,	//0xA0000000,	//(2byte) ��, ��, ��, ��, ��...	// 2009.05.26: �� 0xA0000000��? 0x20000000�� �� �������� �ʳ�?(������)

	//others that don't belong to any flag
	PID_ETC			= 0x40000000,	//0x40000000,

	//combined with 2byte characters, msb = 1
	PID_Wide		= 0x80000000	//0x80000000
};



// �ڵ� ������(for windows)
#ifndef CP_Hanguel_Wansung		// �ٸ� OS(mac)���� ȣȯ�� ����
#	define CP_Hanguel_Wansung	949
#endif
#ifndef CP_Hanguel_Johab
#	define CP_Hanguel_Johab		1361
#endif

typedef unsigned short WORD;
typedef unsigned char BYTE;
//typedef unsigned wchar_t;

class HangulChar
{
public:
	union{
		WORD data;
		struct {
			WORD end	: 5;		//����
			WORD mid	: 5;		//�߼�
			WORD sts	: 5;		//�ʼ�
			WORD fill	: 1;		//fill code (�̰��� 1�̸� �ѱ��̴�)
		}g;
		struct {
			BYTE rear;	 // �ι�° ����Ʈ
			BYTE front;	 // ù��° ����Ʈ
		}c;
	};

	// ���� ���� ����
	char* set(char* hangul)
	{
		if( hangul[0] & 0x80 )
		{
			c.front = hangul[0];
			c.rear = hangul[1];			
			return hangul+2;
		}
		else
		{
			c.front = 0;
			c.rear = hangul[0];
			return hangul+1;
		}
	}
};

#define SPACECHAR(c) ( (c == ' ') || (c == '\t') || (c == '\n') || (c == 13) )
#define HANJA(h,l) (((h > (char)0xc9) && (h < (char)0xfe)) && ((l > (char)0xa0) && (l < (char)0xff))) // �ϼ���
#define ASCII(c) ((c & 0x80) ? 0 : 1)
#define FIGURE(c) (c >= '0' && c <= '9')
#define ALPHABET(c) ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))