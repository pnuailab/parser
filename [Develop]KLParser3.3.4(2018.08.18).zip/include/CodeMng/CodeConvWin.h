#pragma once


#include "CodeDefs.h"

class CodeConvWin
{
public:
	static int Code_Convert(const char* str, wchar_t* w_str, int len, int codepage);
	static int Code_Convert(const wchar_t* w_str, char* str, int len, int codepage);
	static int Code_Convert_Len(const char* str, int codepage);
	static int Code_Convert_Len(const wchar_t* w_str, int codepage);

	static wchar_t* toUnicode(const char* s, int codepage=1/*CP_OEMCP*/);
	static char* toMBCS(const wchar_t* ws, int codepage=1/*CP_OEMCP*/);


	static void WansungToJohab(const char* in,char** out);
	static void JohabToWansung(const char* in,char** out);
	static void AsciiToUTF8(const char* in,char** out);
	static void UTF8ToAscii(const char* in,char** out);

	static void WansungToJohab(char* in);
	static void JohabToWansung(char* in);
	static void AsciiToUTF8(char* in);
	static void UTF8ToAscii(char* in);
};

