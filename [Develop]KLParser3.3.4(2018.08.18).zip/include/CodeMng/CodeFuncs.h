#pragma once

#include "CodeDefs.h"


class CodeFuncs
{

public:
	static bool isJohabHangul(unsigned char h, unsigned char l);
	static bool isJohabHangul(const HangulChar &johab);
	static bool isWansungHangul(unsigned char h, unsigned char l);

	static void JongsungToChosung(HangulChar &johab);
	static void ChosungToJongsung(HangulChar &johab);

    static void JongsungToChosung(unsigned char *johab);
	static void ChosungToJongsung(unsigned char *johab);

	static const char* GetAsciiNum_Wansung(char *wansung);
	static const char* GetAsciiNum_Wansung(unsigned char h, unsigned char l);

	static int codeAnalyzeWansung(const char *code);
	static int getPunctuationIDWansung(const char *code);
	static int codeAnalyzeJohab(const char *code);
	static int getPunctuationIDJohab(const char *code);
};
