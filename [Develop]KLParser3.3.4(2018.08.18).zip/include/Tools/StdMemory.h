// GlobalMemory.h: interface for the GlobalMemory class.
//
//////////////////////////////////////////////////////////////////////

#pragma once





class StdMemory  
{
	long	m_nAllocSize;
public:
	void*	m_pMemory;
	long	m_nDataSize;	

public:
	StdMemory();
	~StdMemory();
	void*	LoadFromFile(const char* strFileName_);
	//int		LoadFromMemory(void* hSource_);
	int		CopyToFile(const char* strFileName_);
	//int		CopyToMemory(void* hDestine_);
	int		FreeAll();
	bool	IsLoaded(){return m_nDataSize!=0;}
	int		Size(){return m_nDataSize;}
};

