#pragma once
#ifndef _BINARY_TREE_
#define _BINARY_TREE_

#include <functional>

#ifndef NULL
#	define NULL	0
#endif // !NULL


// �׽�Ʈ ���� �ҽ�
template <class Key, class Comp = std::less<Key> > 
class BinaryTreeNode
{
public:	
	Key m_data;
	Comp m_comp;

	BinaryTreeNode *m_pParentNode;
	BinaryTreeNode *m_pLesserNode;
	BinaryTreeNode *m_pGreaterNode;

public:
	BinaryTreeNode(Key &_data, BinaryTreeNode *m_pParentNode=NULL, BinaryTreeNode *_pLesserNode=NULL, BinaryTreeNode *_pGreaterNode=NULL)
	{
		m_data = _data;
		m_pLesserNode = _pLesserNode;
		m_pGreaterNode = _pGreaterNode;
	}
	~BinaryTreeNode()
	{
		if(m_pLesserNode!=NULL)		delete m_pLesserNode;
		if(m_pGreaterNode!=NULL)	delete m_pGreaterNode;
	}
};

template <class Key, class Comp = std::less<Key> >
class BinaryTree
{
	BinaryTreeNode<Key, Comp>* m_pRoot;
public:
	BinaryTree()
	{
		m_pRoot = NULL;
	}
	~BinaryTree()
	{
		if(m_pRoot!=NULL)	delete m_pRoot;
	}

	void Insert(const Key &_key)
	{
		if(m_pRoot==NULL)
			m_pRoot = new BinaryTreeNode(_key);
		else
			Insert(*m_pRoot, _key)
	}

	void Insert(BinaryTreeNode &_parentNode, const Key &_key)
	{
		BinaryTreeNode** pTargetNode;

		if(m_comp(_parentNode.m_data, _key))	// <
			*pTargetNode = m_pGreaterNode;
		else
			*pTargetNode = m_pLesserNode;

		if(*pTargetNode==NULL)
		{
			*pTargetNode = new BinaryTreeNode(_key, &_parentNode);
		}
		else
		{
			(*pTargetNode)->AttachNode(*this, _key);
		}
	}

	BinaryTreeNode* Find(const Key &_data)
	{
		return Find(*m_pRoot, _data)
	}
	BinaryTreeNode* Find(BinaryTreeNode &_parentNode, const Key &_data)
	{
		BinaryTreeNode** pTargetNode;

		if(m_comp(_parentNode.m_data, *_data))	// <
			*pTargetNode = m_pGreaterNode;
		else if(m_comp(*_data, _parentNode.m_data))
			*pTargetNode = m_pLesserNode;
		else
			return this;	// ũ���� ������ ������ ���� ��

		if((*pTargetNode)==NULL) return NULL;

		return (*pTargetNode)->Find(*this, _data);		
	}

	BinaryTreeNode* MinNode()
	{
		MinNode(*m_pRoot);
	}

	BinaryTreeNode* MinNode(BinaryTreeNode &pNode)
	{
		if(pNode==NULL) return NULL;
		if(pNode->m_pLesserNode !=NULL) return MinNode(*pNode->m_pLesserNode);
		return pNode;
	}

	BinaryTreeNode* MaxNode()
	{
		MaxNode(*m_pRoot);
	}

	BinaryTreeNode* MaxNode(BinaryTreeNode &pNode)
	{
		if(pNode==NULL) return NULL;
		if(pNode->m_pGreaterNode !=NULL) return MaxNode(*pNode->m_pGreaterNode);
		return pNode;
	}


	void Erase(const Key &_key)
	{
		BinaryTreeNode* pTargetNode = Find(_key);

		if(pTargetNode==NULL) return;

		BinaryTreeNode* pParentNode = pTargetNode->m_pParentNode;

		// ������ �ڽ��� ������
		BinaryTreeNode* pNewMidNode = MinNode(*pTargetNode->m_pGreaterNode);
		if(pNewMidNode!=NULL)	
		{
			pTargetNode->m_data = pNewMidNode->m_data;
			pParentNode->m_pLesserNode = pNewMidNode->m_pGreaterNode;	// pNewMidNode�� ������ ��尡 ���� �� ����.
			pNewMidNode->m_pGreaterNode = NULL;
			delete pNewMidNode;
			return;
		}

		// ���� �ڽ��� ������
		pNewMidNode = MaxNode(*pTargetNode->m_pLesserNode);
		if(pNewMidNode!=NULL)	
		{
			pTargetNode->m_data = pNewMidNode->m_data;
			pParentNode->m_pGreaterNode = pNewMidNode->m_pLesserNode;	// pNewMidNode�� ������ ��尡 ���� �� ����.
			pNewMidNode->m_pLesserNode = NULL;
			delete pNewMidNode;
			return;
		}

		// �ڽ��� �� �� ������
		{
			if(pParentNode->m_pLesserNode == pTargetNode)	pParentNode->m_pLesserNode = NULL;
			else if(pParentNode->m_pGreaterNode == pTargetNode)	m_pGreaterNode->m_pGreaterNode = NULL;

			delete pTargetNode;
		}
	}
};

#endif 