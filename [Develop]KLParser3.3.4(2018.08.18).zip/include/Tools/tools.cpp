

#if _MSC_VER >= 1000
#pragma warning(disable : 4103)  //  ���� ����� �����ϱ� ���� #pragma pack�� ����߽��ϴ�.
#pragma warning(disable : 4996) // _CRT_SECURE_NO_WARNINGS ����
#endif


//#include "stdafx.h"


#ifdef LINUX_PORTING
#		include "include/stdafx.h"
#		include "include/OSIncludes/mac_inc.h"
#		include <unistd.h>
#else
#		include <direct.h>
#		include <io.h>
//#		include <windows.h>
//#		include <afxwin.h>
//#		include <winuser.h>
#endif

#include "tools.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#		include <stdarg.h>

//#include "../Tagger/TagTypeDefs.h"

//#include "../HString/HCharUtil.h"
//class HString;
//class HCHAR;

#include <string>
#include <vector>

//#ifdef	INCUBE_REMARK
//#include <algorithm>
//#endif	//INCUBE_REMARK

#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <assert.h>

#include <time.h>
#include <iostream>
#include <fstream>
//#include <assert.h>


#ifndef C_DIR_DELIMIT
#ifdef	LINUX_PORTING
#		define	C_DIR_DELIMIT	'/'
#		define	STR_DIR_DELIMIT	"/"
#		define	STR_UPPER_DIR_DELIMIT	"../"
#		define	STR_CURRENT_DIR_DELIMIT	"./"
#else
#		define	C_DIR_DELIMIT	'\\'
#		define	STR_DIR_DELIMIT	"\\"
#		define	STR_UPPER_DIR_DELIMIT	"..\\"
#		define	STR_CURRENT_DIR_DELIMIT	".\\"
#endif
#endif


#pragma comment(lib, "user32.lib")



//using namespace std;




int IsWhiteSpace(const char* _szSource)
{
	const unsigned char* szSource = (const unsigned char*)_szSource;

	if (szSource == NULL) return 0;

	if (*szSource == ' ')		return 1;
	if (*szSource == '\r')	return 1;
	if (*szSource == '\n')	return 1;
	if (*szSource == '\t')	return 1;
	if (szSource[0] == 0x00A1 && szSource[1] == 0x00A1)	return 2;
	return false;
}

int SkipWhiteSpace(const char* _szSource)
{
	int nSpaceLen = IsWhiteSpace(_szSource);
	int nTotalLen = 0;
	for (; nSpaceLen>0; )
	{
		nTotalLen += nSpaceLen;
		nSpaceLen = IsWhiteSpace(_szSource + nTotalLen);
	}
	return nTotalLen;
}


std::string StringTrimLeft(std::string &str)
{
	int idx = (int)str.find_first_not_of(" \n\r\t");

	if (idx == std::string::npos) return "";

	return str.substr(idx, str.length() - idx);
}

std::string StringTrimRight(std::string & str)
{
	int idx = (int)str.find_last_not_of(" \n\r\t");

	if (idx == std::string::npos) return "";

	return str.substr(0, idx + 1);
}


std::string &operator<<(std::string& str, double n)
{
	static char buf[30];
	sprintf(buf, "%e", n);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, float n)
{
	static char buf[30];
	sprintf(buf, "%f", n);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, long n)
{
	static char buf[30];
	sprintf(buf, "%d", n);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, int n)
{
	static char buf[30];
	sprintf(buf, "%d", n);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, char c)
{
	static char buf[30];
	sprintf(buf, "%c", c);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, unsigned long n)
{
	static char buf[30];
	sprintf(buf, "%d", n);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, unsigned int n)
{
	static char buf[30];
	sprintf(buf, "%d", n);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, unsigned char c)
{
	static char buf[30];
	sprintf(buf, "%c", c);
	str += buf;
	return str;
}
std::string &operator<<(std::string& str, const char* pStr)
{
	str += pStr;
	return str;
}
std::string &operator<<(std::string& str, const std::string &oth)
{
	str += oth;
	return str;
}

void tolower(char* _szSource)
{
	int len = (int)strlen(_szSource);

	int i;
	for (i = 0; i<len; i++)
	{
		if (_szSource[i] & 0x80)
		{
			i++;
			continue;
		}

		_szSource[i] = tolower(_szSource[i]);
	}
}

void toupper(char* _szSource, bool _bFirst)
{
	int len = (int)strlen(_szSource);

	int i;
	for (i = 0; i<len; i++)
	{
		if (_szSource[i] & 0x80)
		{
			i++;
			continue;
		}

		if (!_bFirst
			|| i == 0
			|| !is_alnum_char(_szSource[i - 1]) && _szSource[i - 1] != '\''
			|| i>1 && _szSource[i - 2] == 0xA1 && _szSource[i - 1] == 0xAF		// 2byte apostrophe
			)
		{
			_szSource[i] = toupper(_szSource[i]);
		}
	}
}


void GenNewPath(const char* orgFileName, char* outNewDirName, char* outNewDirAndFileName, const char* strDirNamePreFix, const char* strFileNamePostFix, bool bUseLastFolder)
{
	RAssert(orgFileName != NULL);
	RAssert(outNewDirAndFileName != NULL);

	char strNewDirName[2000];
	strcpy(strNewDirName, orgFileName);

	const char* pOnlyFilename = NULL;

	char* pCR = strrchr(strNewDirName, C_DIR_DELIMIT);
	if (pCR)
	{
		pCR[1] = 0;	//strOutPath
		pCR++;
		pOnlyFilename = orgFileName + (pCR - strNewDirName);
	}

	std::string strNewDir;
	if (strDirNamePreFix)	strNewDir = strDirNamePreFix;
	strNewDir += pOnlyFilename;

	strcpy(strNewDirName, MakeResultOutputDir(strNewDirName, strNewDir, bUseLastFolder).c_str());	// ? null�� ����?

	sprintf(outNewDirAndFileName, "%s%s", strNewDirName, pOnlyFilename);
	if (strFileNamePostFix)	strcat(outNewDirAndFileName, strFileNamePostFix);

	if (outNewDirName)	strcpy(outNewDirName, strNewDirName);
}


const std::string& MakeResultOutputDir(const std::string &_sFromPath, const std::string &sDirName, bool bUseLastFolder, bool bGenerateNewFolderName)
{
#ifndef LINUX_PORTING

	std::string sFromPath = removeUpperDir(_sFromPath.c_str());
	char oldpath[2000];
	static std::string strNULL = "";

	//	GetCurrentDirectory(2000,oldpath);
	getcwd(oldpath, 2000);

	if (_chdir(sFromPath.c_str()) != 0)	return strNULL;


	int c = -1;
	char tmpBuf[500];

	if (!bUseLastFolder && !bGenerateNewFolderName)
	{
		sprintf(tmpBuf, "%s", sDirName.c_str());
		c = _mkdir(tmpBuf);
	}

	else
	{
		int i;
		for (i = 999; i >= -1; i--)
		{
			sprintf(tmpBuf, "%s.%03d", sDirName.c_str(), i);

			_finddata_t fd;

			if (0 <= i)
			{

				long handle;
				int result = 1;

				handle = (long)_findfirst("*.*", &fd);
				if (handle == -1) break;

				bool bExist = false;
				while (result != -1)
				{
					if (!strnicmp(tmpBuf, fd.name, strlen(tmpBuf)))
					{
						bExist = true;
						break;
					}

					result = _findnext(handle, &fd);
				}

				_findclose(handle);

				if (!bExist)	continue;
			}


			if (i >= 0 && bUseLastFolder)
			{
				//sprintf(tmpBuf, "%s.%03d", sDirName.c_str(), i);
				strcpy(tmpBuf, fd.name);
				c = 0;
				break;
			}
			else
			{
				sprintf(tmpBuf, "%s.%03d", sDirName.c_str(), i + 1);
				c = _mkdir(tmpBuf);
				if (c != EEXIST) break;
			}
		}
	}

	static std::string sResultPath;
	sResultPath = "";
	if (c == 0 || !bGenerateNewFolderName)
	{
		sResultPath = sFromPath + tmpBuf;
		sResultPath += STR_DIR_DELIMIT;
	}

	_chdir(oldpath);

	return sResultPath;

#else //LINUX_PORTING
	static std::string strCurrendDir = STR_CURRENT_DIR_DELIMIT;
	return strCurrendDir;
#endif //LINUX_PORTING
}



std::string MakeDir(const char *szPath, bool bNumbering)
{
#ifdef INCUBE_REMARK

	if (strlen(szPath) == 0)	return "";

	std::vector<std::string> tokenVector = strtokToVector(szPath, STR_DIR_DELIMIT);
	std::string strPath, strResultPath;
	char* szOldPath = new char[MAX_FILE_NAME_LENGTH];
	_getdcwd(_getdrive(), szOldPath, MAX_FILE_NAME_LENGTH);


	// szPath�� �������� \\�� �ƴϸ� ������ ��ū�� ���ϸ����� ����
	if (szPath[strlen(szPath) - 1] != C_DIR_DELIMIT)	tokenVector.pop_back();

	int i;
	for (i = 0; i<(int)tokenVector.size(); i++)
	{
		strPath = tokenVector[i];
		strPath += STR_DIR_DELIMIT;

		if (0 > _chdir(strPath.c_str()))	// ������
		{
			std::string strNewPath = MakeResultOutputDir(STR_CURRENT_DIR_DELIMIT, tokenVector[i], false, bNumbering);
			DAssert(strNewPath.length()>0);
			_chdir(strNewPath.c_str());
			strResultPath += (strchr(strNewPath.c_str(), C_DIR_DELIMIT) + 1);
		}
		else
		{
			strResultPath += strPath;
		}
	}

	_chdir(szOldPath);
	delete[] szOldPath;

	return strResultPath;

#else	//INCUBE_REMARK
	static std::string strCurrendDir = STR_CURRENT_DIR_DELIMIT;
	return strCurrendDir;
#endif	//INCUBE_REMARK
}

std::string GetOnlyDir(const char* _szSourcePath)
{
	char szResultDir[MAX_FILE_NAME_LENGTH];
	GetOnlyDir(szResultDir, _szSourcePath);
	return szResultDir;
}

void GetOnlyDir(char* _szResultDir, const char* _szSourcePath)
{
	if (strchr(_szSourcePath, C_DIR_DELIMIT))
	{
		strcpy(_szResultDir, _szSourcePath);

		// ���� �̸� �κ� ����. ���丮���� �����
		hstrrtok(_szResultDir, STR_DIR_DELIMIT);
		strcat(_szResultDir, STR_DIR_DELIMIT);
	}
	else
	{
		strcpy(_szResultDir, STR_CURRENT_DIR_DELIMIT);
	}
}


void GetOnlyFileName(char* _szResultFileName, const char* _szSourcePath)
{
	const char* szFileName = strrchr(_szSourcePath, C_DIR_DELIMIT);

	if (szFileName == NULL)
	{
		strcpy(_szResultFileName, _szSourcePath);
		return;
	}

	szFileName++;
	strcpy(_szResultFileName, szFileName);
}


std::string GetOnlyFileName(const char* _szSourcePath)
{

	const char* szFileName = strrchr(_szSourcePath, C_DIR_DELIMIT);

	if (szFileName == NULL)
	{
		return _szSourcePath;
	}

	szFileName++;
	return szFileName;
}


//void  InsertStrTokensToSet(set<HString> &s, char* wordTable)
//{
////	AfxMessageBox("set");
//	char* token = strtok(wordTable, " ");
//	while(token)
//	{
//		//TRACE(token); TRACE("\n");
//		s.insert(HString(token, true));
//		token = strtok(NULL, " ");
//	}
//}


// memmove()�� �̹� �⺻������ ����
////source�� �տ� �ְ� dest�� �ڿ� ������ �־ ���Ľ����� ���� �����ϱ� ����
////���� ������ ���� ����
//void* M emShift(void* source, unsigned int size, int iShiftOffset)
//{
//	if(iShiftOffset==0)
//	{
//		return source;
//	}else if(0<iShiftOffset){
//		char* cpDestPos = (char*)source + iShiftOffset + size -1;
//		char* cpSourcePos = (char*)source + size -1;
//
//		for(int i=0; (unsigned)i<size; i++)
//			*(cpDestPos--) = *(cpSourcePos--);
//	}else{
//		memcpy((char*)source-iShiftOffset, source, size);
//	}
//
//	return((char*)source+iShiftOffset); 
//}



// _cElementSet�� ��Ұ� _szSource���� ��Ÿ���� �������� ����
// �Է� ������ 2����Ʈ ���� ����
// hstrcspn("abcdef", "fde") == 3
size_t hstrcspn(const char* _szSource, const char* _cElementSet, int _lenOfSource)
{
	DAssert(_szSource != NULL);

	const char* pElement;
	const char* pCurPos = _szSource;
	const char* pEndPos = _szSource + ((_lenOfSource >= 0) ? _lenOfSource : strlen(_szSource));

	while (pCurPos<pEndPos)
	{
		if (*pCurPos & 0x80)
		{
			pCurPos += 2;
			continue;
		}
		else
		{
			for (pElement = _cElementSet; *pElement; pElement++)
			{
				if (*pElement == *pCurPos)	return pCurPos - _szSource;
			}
			pCurPos++;
		}
	}

	if (pCurPos>pEndPos)	pCurPos = pEndPos;

	return pCurPos - _szSource;
}

// _cElementSet�� ��Ұ� _szSource���� �����ؼ� ��Ÿ�� ����
// �Է� ������ 2����Ʈ ���� ����
// hstrspn("abcdef", "bca") == 3
size_t hstrspn(const char* _szSource, const char* _cElementSet, int _lenOfSource)
{
	DAssert(_szSource);

	const char* pElement;
	const char* pCurPos = _szSource;
	const char* pEndPos = _szSource + ((_lenOfSource >= 0) ? _lenOfSource : strlen(_szSource));

	while (pCurPos<pEndPos)
	{
		if (*pCurPos & 0x80)
		{
			return pCurPos - _szSource;
		}
		else
		{
			for (pElement = _cElementSet; true; pElement++)
			{
				if (*pElement == *pCurPos)	break;
				if (*pElement == '\0')			return pCurPos - _szSource;
			}
			pCurPos++;
		}
	}

	if (pCurPos>pEndPos)	pCurPos = pEndPos;

	return pCurPos - _szSource;
}


// _cElementSet�� ��Ÿ���� �������� ���ڿ��� ����� �� �� ���
// _cElementSet�� ó�� ��Ÿ���� ���̳� ���ڿ� ���� ����
char* hstrpbrk(char* _szSource, const char* _cElementSet, int _lenOfSource)
{
	return _szSource + hstrcspn(_szSource, _cElementSet, _lenOfSource);
}

const char* hstrpbrk(const char* _szSource, const char* _cElementSet, int _lenOfSource)
{
	return _szSource + hstrcspn(_szSource, _cElementSet, _lenOfSource);
}




//strspn()�� ����
// str���� delimit���� ó������ ��Ÿ���� ���� �κ� ����
char* hstrskip(char* str, const char* delimits, int _lenOfSource)
{
	return str + hstrspn(str, delimits, _lenOfSource);
	//int i;
	//int delimitLen = (int)strlen(delimits);
	//char* p = str;

	//while(p)
	//{
	//	for(i=0; i<delimitLen; i++)
	//	{
	//		if(*p==delimits[i]) break;
	//	}
	//	if(i==delimitLen) return p;
	//	p++;
	//}

	//return NULL;
}

const char* hstrskip(const char* str, const char* delimits, int _lenOfSource)
{
	return str + hstrspn(str, delimits, _lenOfSource);
}

//void hstrskip(const char* str, const char* delimits, const char** szOutResult)
//{
//	*szOutResult = str+hstrspn(str, delimits);
//}


// ���� str="abcde", delimits="cba" ���, ���=d�� �ּ�
// ã�� ����� '\0'�� ������ str���� delimit�� �ش��ϴ� ���ڰ� ���ڿ� �������� �ǰ� �ϴ� �κ� ã��
char* hstrrpbrk(char* _szSource, const char* delimits, int _lenOfSource)
{
	DAssert(_szSource);

	char* pResult = _szSource;
	char* pCurPos = _szSource;
	char* pEndPos = _szSource + ((_lenOfSource >= 0) ? _lenOfSource : strlen(_szSource));

	while (true)
	{
		pCurPos = hstrskip(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pEndPos;
		pResult = pCurPos;
		pCurPos = hstrpbrk(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pResult;
	}

	//char *pEnd = str + strlen(str);

	//if(delimits==NULL) return pEnd;

	//for(; str<pEnd; pEnd--)
	//{
	//	if(strchr(delimits, *(pEnd-1)) == NULL) break;
	//}

	//return pEnd;
}

const char* hstrrpbrk(const char* _szSource, const char* delimits, int _lenOfSource)
{
	DAssert(_szSource);

	const char* pResult = _szSource;
	const char* pCurPos = _szSource;
	const char* pEndPos = _szSource + ((_lenOfSource >= 0) ? _lenOfSource : strlen(_szSource));

	while (true)
	{
		pCurPos = hstrskip(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pEndPos;
		pResult = pCurPos;
		pCurPos = hstrpbrk(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pResult;
	}
}


// ���ʿ��� ã�ƿ� ��� �ѱ۰� ���� ���ڿ����� ������ ���� �� ����
//char* hstrrpbrk(const char* str, const char* delimits)
//{
//	int len = strlen(str);
//	while(len--)
//	{
//		char* pd = strchr(delimits, str[len]);
//		if(pd) return pd;
//	}
//
//	return NULL;
//}




// str�� �ڿ�������, delimit���� ó�� ��Ÿ�� �κ��� ���� ���� �ּ� ����
// ���� str="abcde", delimits="ced" ���, ���=c�� �ּ�
// str�� ���� delimits���� ���� �� ���
char* hstrrskip(char* _szSource, const char* delimits, int _lenOfSource) {
	DAssert(_szSource);

	char* pResult = _szSource;
	char* pCurPos = _szSource;
	char* pEndPos = _szSource + ((_lenOfSource >= 0) ? _lenOfSource : strlen(_szSource));

	while (true)
	{
		pCurPos = hstrskip(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pResult;
		pCurPos = hstrpbrk(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pEndPos;
		pResult = pCurPos;
	}
}

const char* hstrrskip(const char* _szSource, const char* delimits, int _lenOfSource)
{
	DAssert(_szSource);

	const char* pResult = _szSource;
	const char* pCurPos = _szSource;
	const char* pEndPos = _szSource + ((_lenOfSource >= 0) ? _lenOfSource : strlen(_szSource));

	while (true)
	{
		pCurPos = hstrskip(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pResult;
		pCurPos = hstrpbrk(pCurPos, delimits);
		if (pCurPos >= pEndPos)	return pEndPos;
		pResult = pCurPos;
	}
}


// �ڿ������� ��ũ����¡
// �ѱ۰��� 2����Ʈ ���� ����. ��, delimits�� �ѱ��� ���� ó�� ����
char* hstrrtok(char* _str, const char* delimits)
{
	static char* str = NULL;
	if (_str)	str = _str;
	if (str == NULL) return NULL;

	char* endOfStr = str + strlen(str);
	char* p = str;
	char* lastP = p;

	while (*p && p<endOfStr)
	{
		// skip delimits
		for (; strchr(delimits, *p); p++);

		lastP = p;	// delimit ���� ù ����

					// skip nondelimits
		for (; !strchr(delimits, *p) && p<endOfStr; p++)
		{
			if (*p & 0x80) p++;
		}
	}

	if (endOfStr<lastP)	// �������Ͱ� �������� ���� ��
	{
		lastP = endOfStr;
	}

	// ��ū �տ��� �ڸ���(������ ��ũ����¡�� ����)
	if (lastP>str)
		lastP[-1] = 0;

	// ���ڿ� ó���̸� ��ũ����¡�� ���� ��(�ڿ������� �ϹǷ�)
	// ���� ��ũ����¡ �� NULL�����ϵ���
	else
		str = NULL;

	return lastP;

	//static char* str=NULL;
	//if(_str)	str=_str;
	//if(str==NULL) return NULL;

	//char* p = str+strlen(str);

	//// skip delimits
	//while(p-- && strchr(delimits, *p));
	//p[1] = 0;

	//// skip nondelimits
	//while(p-- && !strchr(delimits, *p));
	//p[0]=0;

	//return p+1;
}


std::vector<std::string> strtokToVector(const char* _szSource, const char* _szDelimit, bool _bDoNotDropDelimit)
{
	std::vector<std::string> tokenVector;
	strtokToVector(_szSource, _szDelimit, tokenVector, _bDoNotDropDelimit);
	return tokenVector;
}

void strtokToVector(const char* _szSource, const char* _szDelimit, std::vector<std::string> &_tokenVector, bool _bDoNotDropDelimit)
{
	_tokenVector.clear();	// 2010.01.12 Ȳ����

	if (_szSource == NULL) return;

	const char* endOfStr = _szSource + strlen(_szSource);
	const char* p = _szSource;
	const char* oldP = p;
	//char* pBuf=NULL;
	//int nSizeOfBuf=0;


	while (*p)
	{
		oldP = p;	// delimit ���� ù ����		

					// skip delimits
		p = strskip(p, _szDelimit);
		//for(; strchr(_szDelimit, *p) && p<endOfStr; p++ );		

		if (p != _szSource)
		{
			if (oldP == p)	break;
			if (_bDoNotDropDelimit)	_tokenVector.push_back(std::string(oldP, p - oldP));
		}

		oldP = p;

		// skip nondelimits
		p = hstrpbrk(p, _szDelimit);
		//for(; !strchr(_szDelimit, *p) && p<endOfStr; p++)
		//{
		//	if(*p&0x80) p++;
		//}

		if (oldP == p)	break;

		// ���� ũ�� Ȯ��
		//if(nSizeOfBuf < p-oldP)
		//{
		//	nSizeOfBuf = int(p-oldP)*2;
		//	if(pBuf)	delete [] pBuf;
		//	pBuf = new char[nSizeOfBuf+1];
		//}

		//strncpy(pBuf, oldP, p-oldP);
		//pBuf[p-oldP] = 0;
		//_tokenVector.push_back(std::string(oldP, p-oldP));      
		_tokenVector.push_back(std::string(oldP, p - oldP));
	}

	//if(pBuf)	delete [] pBuf;
	return;
}

std::set<std::string> strtokToSet(const char* _szSource, const char* _szDelimit, bool _bDoNotDropDelimit)
{
	std::set<std::string> tokenSet;
	strtokToSet(_szSource, _szDelimit, tokenSet, _bDoNotDropDelimit);
	return tokenSet;
}


void strtokToSet(char* _szSource, const char* _szDelimit, std::set<std::string> &_tokenSet)
{
	if (_szSource == NULL) return;

	char* endOfStr = _szSource + strlen(_szSource);
	char* p = _szSource;
	char* oldP = p;


	while (p<endOfStr)
	{
		// skip delimits
		p = hstrskip(p, _szDelimit, int(endOfStr - p));
		//for(; strchr(_szDelimit, *p) && p<endOfStr; p++ );		

		oldP = p;

		// skip nondelimits
		p = hstrpbrk(p, _szDelimit, int(endOfStr - p));

		if (oldP == p)	break;

		*p++ = 0;
		_tokenSet.insert(oldP);
	}

	return;
}

void strtokToSet(const char* _szSource, const char* _szDelimit, std::set<std::string> &_tokenSet, bool _bDoNotDropDelimit)
{
	if (_szSource == NULL) return;

	const char* endOfStr = _szSource + strlen(_szSource);
	const char* p = _szSource;
	const char* oldP = p;
	char* pBuf = NULL;
	int nSizeOfBuf = 0;


	while (*p)
	{
		oldP = p;	// delimit ���� ù ����		

					// skip delimits
		for (; strchr(_szDelimit, *p) && p<endOfStr; p++);

		if (p != _szSource)
		{
			if (oldP == p)	break;
			if (_bDoNotDropDelimit)	_tokenSet.insert(std::string(oldP, p - oldP));
		}

		oldP = p;

		// skip nondelimits
		for (; !strchr(_szDelimit, *p) && p<endOfStr; p++)
		{
			if (*p & 0x80) p++;
		}

		if (oldP == p)	break;

		// ���� ũ�� Ȯ��
		if (nSizeOfBuf < p - oldP)
		{
			nSizeOfBuf = int(p - oldP) * 2;
			if (pBuf)	delete[] pBuf;
			pBuf = new char[nSizeOfBuf + 1];
		}

		strncpy(pBuf, oldP, p - oldP);
		pBuf[p - oldP] = 0;
		//_tokenSet.insert(std::string(oldP, p-oldP));      
		_tokenSet.insert(pBuf);
	}

	if (pBuf)	delete[] pBuf;
	return;
}

// ���Ͽ��� �����ڸ� ���� �ϴ� ���ڿ��� �о� set�� �ֱ�
// �ӵ� �������� ����
void Read(std::set<std::string> &_set, const char* _szFileName, const char* _szDelimit, LineCommentInfo *_plci)
{
	std::vector<std::string> vec;

	Read(vec, _szFileName, _szDelimit, _plci);

	int i;
	for (i = 0; i<int(vec.size()); i++)
	{
		_set.insert(vec[i]);
	}
}

// ���Ͽ��� �����ڸ� ���� �ϴ� ���ڿ��� �о� list�� �ֱ�
// �ӵ� �������� ����
void Read(std::list<std::string> &_list, const char* _szFileName, const char* _szDelimit, LineCommentInfo *_plci)
{
	std::vector<std::string> vec;

	Read(vec, _szFileName, _szDelimit, _plci);

	int i;
	for (i = 0; i<int(vec.size()); i++)
	{
		_list.push_back(vec[i]);
	}
}

// ���Ͽ��� �����ڸ� ���� �ϴ� ���ڿ��� �о� vector�� �ֱ�
// �ӵ� �������� ����
void Read(std::vector<std::string> &_vector, const char* _szFileName, const char* _szDelimit, LineCommentInfo *_plci)
{
	DAssert(_szFileName);

	FullGetLine ifs;
	ifs.Open(_szFileName);
	if (!ifs)
	{
		printf("file open fail: %s\n", _szFileName);
		return;
	}

	while (!ifs.eof())
	{
		const char* szLine = ifs.GetLine();
		if (_plci)
		{
			char* szLC;
			if (_plci->info.semicolon)
			{
				szLC = (char*)strchr(szLine, ';');
				if (szLC)	*szLC = 0;
			}
			if (_plci->info.twoslish)
			{
				szLC = (char*)strstr(szLine, "//");
				if (szLC)	*szLC = 0;
			}
		}
		strtokToVector(szLine, _szDelimit, _vector);
	}
}

//////////////////////////////////////////////////////////////////////////
//	class StringSet
//////////////////////////////////////////////////////////////////////////

StringSet::StringSet(const char* _szFileName, const char* _szDelimit, LineCommentInfo *_plci)
{
	std::set<std::string> emptySet;
	std::vector<std::string> wholeVec;

	Read(wholeVec, _szFileName, _szDelimit, _plci);

	int i;
	for (i = 0; i<(int)wholeVec.size(); i++)
	{
		int len = (int)wholeVec[i].length();
		while ((int)m_sets.size() <= len)	m_sets.push_back(emptySet);
		m_sets[len].insert(wholeVec[i]);
	}
}

bool StringSet::find(const char* _key)
{
	int len = (int)strlen(_key);
	if (m_sets.size() <= (unsigned)len)	return false;
	return m_sets[len].find(_key) != m_sets[len].end();
}

int StringSet::LongestBackwardMatch(const char *_szSource)
{
	int lenLimit = (int)m_sets.size();
	int lenOfSource = (int)strlen(_szSource);
	int i;
	for (i = 0; i<lenOfSource; i++)
	{
		if (lenOfSource - i >= lenLimit)	continue;
		if (m_sets[lenOfSource - i].find(_szSource + i) != m_sets[lenOfSource - i].end())	return lenOfSource - i;
	}
	return 0;
}
int StringSet::LongestForwardMatch(const char *_szSource)
{
	int lenLimit = (int)m_sets.size();
	int lenOfSource = (int)strlen(_szSource);
	int len;
	for (len = 1; len<lenOfSource; len++)
	{
		if (len >= lenLimit)	return 0;
		if (m_sets[len].find(std::string(_szSource, len)) != m_sets[len].end())	return len;
	}
	return 0;
}


// �� substring �� �ռ� ������ substring ã��
char* strfstr(const char* source, const char* k1, const char* k2)
{
	char* fk1 = (char*)strstr(source, k1);
	char* fk2 = (char*)strstr(source, k2);

	char* key = min(fk1, fk2);
	if (!key)	key = max(fk1, fk2);

	if (!key)	return NULL;

	return key;
}

int getNumOfToken(const char* str, const char* delimits)
{
	int iNumOfToken = 0;
	char const * tmpstr = str;

	while (str)
	{
		int k = (int)strspn(tmpstr, delimits);
		if (*tmpstr != 0)
		{
			iNumOfToken++;
			tmpstr += k;
			tmpstr += strcspn(tmpstr, delimits);
			continue;
		}
		break;
	}
	return iNumOfToken;
}

//�ݺ��Ǵ� ���� ���� �� ���� ���ڿ��� �ڷ� ����
//���� �Ϸ�� �� ���ڿ��� ���� ����
char* RemoveRepeatedStr(char* source, const char* cpRepeatedStr, const char* endP)
{
	char* cpNewSource = source;
	char* cpStartOfRep = source;
	char* cpCur = source;

	for (;; cpCur++)
	{

		//���ӵ��� ���� ���ڿ� �߰�
		if (*cpCur != *cpStartOfRep || *cpCur == '\0' || cpCur == endP)
		{
			int iRepeatedLen = (int)(cpCur - cpStartOfRep);
			if (1 < iRepeatedLen)
			{
				int iHeadStrLen = (int)(cpStartOfRep - cpNewSource);
				memmove(cpNewSource + (iRepeatedLen - 1), cpNewSource, iHeadStrLen);
				//MemShift(cpNewSource, iHeadStrLen, iRepeatedLen-1);
				cpNewSource += (iRepeatedLen - 1);
			}
			cpStartOfRep = cpCur;
		}

		//���ӵ� ���ڿ��� ���
		else
		{
			//�����ϱ� ���ϴ� ��������
			int r;
			for (r = 0; r<(int)strlen(cpRepeatedStr); r++)
			{
				if (cpRepeatedStr[r] == *cpCur)	break;
			}

			//�����ϱ� ���ϴ� ���ڰ� �ƴ� ���
			if (r == strlen(cpRepeatedStr))
				cpStartOfRep = cpCur;
		}

		if (*cpCur == '\0' || cpCur == endP)	break;
	}

	return (cpNewSource);
}


//�κ� ���ڿ� ġȯ
// "00->0"�� �� '0000'�� '00'�� ��
bool strReplace(char* str, const char* from, const char* to, bool bWholeWord, bool bJustOneReplace)
{
	if (!strcmp(from, to)) return false;
	if (strlen(from) == 0)	return false;

	bool bChanged = false;

	//char* pEndStr = str + strlen(str);

	for (char* pNextFrom = str; *pNextFrom; )
	{
		//char* pFrom = strstr(pNextFrom, from);
		//if(pFrom==NULL)	break;
		if (strncmp(pNextFrom, from, strlen(from)))
		{
			if (*pNextFrom & 0x80)	pNextFrom++;
			pNextFrom++;
			continue;
		}

		char* pFrom = pNextFrom;

		//2����Ʈ ������ �� ����Ʈ�� �ɰԼ� ���ϴ� �� ����
		//if(pFrom!=from && *(pFrom-1)&0x80) continue;

		//��ü �ܾ� ��ġ
		if (bWholeWord)
		{
			//ã�� �ܾ ����� �����ϴµ� ã�� �ܾ� ���� ������ ���
			if (is_alpha_char(*pFrom) && is_alpha_char(*(pFrom - 1))) continue;

			//ã�� �ܾ ����� �����µ� ã�� �ܾ� �ڰ� ������ ���
			if (is_alpha_char(*(pFrom + strlen(from) - 1)) && is_alpha_char(*(pFrom + strlen(from))))	continue;
		}

		bChanged = true;

		char *pShifTo = pFrom + strlen(to);
		char *pShifToFrom = pFrom + strlen(from);
		int l = (int)strlen(pFrom) + 1;

		memmove(pShifTo, pShifToFrom, strlen(pShifToFrom) + 1);
		//char t = *(pFrom+strlen(to));
		if (pShifTo + strlen(pShifTo) < pFrom + strlen(to))	memcpy(pFrom, to, sizeof(char)*(strlen(to) + 1));
		else							memcpy(pFrom, to, sizeof(char)*strlen(to));
		//*(pFrom+strlen(to)) = t;

		pNextFrom = pFrom + strlen(to);

		if (bJustOneReplace) break;

	}
	return bChanged;
}

//�κ� ���ڿ� ġȯ(All): 2����Ʈ���ڸ� ���� ���������� ����
void strReplace(std::string& strOrg, std::string strFind, std::string _strReplace)
{
	size_t i = 0;

	i = strOrg.find(strFind);
	while (i != std::string::npos)
	{
		strOrg.replace(i, strFind.size(), _strReplace);
		i = strOrg.find(strFind, i + _strReplace.length());
	}
}


/*
//�κ� ���ڿ� �ϰ� ġȯ
void strReplace(char* str, char* convertingInfoTable, int tableCol, int tableRow)
{
bool bChanged = true;
while(bChanged)
{
bChanged = false;

//����
for(int i=0; i<tableRow; i+=2)
bChanged |= strReplace(str, convertingInfoTable+i*tableCol, convertingInfoTable+(i+1)*tableCol);
}
}
*/






#ifndef INT_HSTRLEN_CHAR_P
#define INT_HSTRLEN_CHAR_P

//�ѱ��� ������ ���� �� ����
int HStrlen(char* str)
{
	DAssert(str != NULL);

	int len = 0;

	int i;
	for (i = 0; str[i] != 0; i++, len++)
	{
		if (str[i] & 0x80)	i++;
	}

	return len;
}
#endif

// �ѱ��� _pos��ġ�� ������ ���
const char* HStrPos(const char* _hstr, int _pos)
{
	if (_hstr == NULL)	return NULL;

	int orgLen = (int)strlen(_hstr);
	if (orgLen <= _pos)	return _hstr + orgLen;

	int i;
	for (i = 0; i<_pos;)
	{
		if (i == _pos)	return _hstr + i;
		i += (_hstr[i] & 0x80) ? 2 : 1;
	}

	return _hstr + orgLen;
}

char* HStrPos(char* _hstr, int _pos)
{
	if (_hstr == NULL)	return NULL;

	int orgLen = (int)strlen(_hstr);
	if (orgLen <= _pos)	return _hstr + orgLen;

	int i, pos;
	for (i = 0, pos = 0; i<orgLen; pos++)
	{
		if (pos == _pos)	return _hstr + i;
		i += (_hstr[i] & 0x80) ? 2 : 1;
	}

	return _hstr + orgLen;
}

// �� ���ڿ��� ������ �κ� ����
size_t strMatchLen(const char* _sz1, const char* _sz2)
{
	if (_sz1 == NULL || _sz2 == NULL)	return 0;
	const char* sz1 = _sz1;
	const char* sz2 = _sz2;
	for (; *sz1 && *sz2 && *sz1 == *sz2; sz1++, sz2++);
	return size_t(sz1 - _sz1);
}


#define FORMATED_STRING_BUF_SIZE 1000
std::string GetFormatedString(const char* format, ...)
{
	//static 
	char* szResult = NULL;
	//static int nBufSize=0;
	char buffer[FORMATED_STRING_BUF_SIZE];
	//if(szResult!=NULL)	delete [] szResult;

#ifdef LINUX_PORTING
		va_list args;
#else
		va_list args = 0;
#endif
	int len = 0;

	va_start(args, format);


#ifdef	INCUBE_REMARK
	len = _vscprintf(format, args) + 1; // _vscprintf doesn't count terminating '\0'
#else
	//len = vfprintf( tmpfile(), format, args ) + 1;	// win2003���� tmpfile()�� 0�� ������. Ȥ�ó� �ؼ�.. ����
	len = 100000;
#endif	//INCUBE_REMARK

	if (len>FORMATED_STRING_BUF_SIZE)
	{
		//szResult = (char*)AtExitDelete(szResult, new char[ len * sizeof(char) ]);
		szResult = new char[len * sizeof(char)];
	}
	else
	{
		szResult = buffer;
	}

	vsprintf(szResult, format, args);

	//return szResult;

	std::string strResult = szResult;
	if (szResult != buffer)	delete[] szResult;

	return strResult;
}


std::string GenNStrings(const char* _szInput, int num)
{
	if (_szInput == NULL)	return "";

	std::string strResult;

	for (; num>0; num--)
	{
		strResult += _szInput;
	}

	return strResult;
}


// _szSource���� ���� �ּ� �κ�(_szCommentMark�� ����)�� _cFiller�� ü��ų� ����(\r\n�� ����)
// ���� 2����Ʈ ���ڸ� �������� ���� ����� ���� ó���� �ּ��� ó��.. �ӽ� ����
int FillLineComment(char* _szSource, const char* _szCommentMark, const char _cFiller)
{
	int nCommentCount = 0;
	char *pEndPos = _szSource + strlen(_szSource);
	char *pWorkPos = strstr(_szSource, _szCommentMark);
	char *pEOS;

	while (pWorkPos && pWorkPos<pEndPos)
	{
		pEOS = pWorkPos + strcspn(pWorkPos, "\r\n");

		//if(pWorkPos==_szSource || pWorkPos[-1]=='\r' || pWorkPos[-1]=='\n')	// ���� 2����Ʈ ���ڸ� �������� ���� ����� ���� ó���� �ּ��� ó��.. �ӽ� ����
		{
			nCommentCount++;
			if (_cFiller)
			{
				for (; pWorkPos<pEOS; pWorkPos++)	*pWorkPos = _cFiller;
			}
			else
			{
				memcpy(pWorkPos, pEOS, strlen(pEOS));
			}
		}

		pWorkPos = strstr(_szSource, _szCommentMark);
	}

	return nCommentCount;
}

//////////////////////////////////////////////////////////////////////////
//	class StringStack

StringStack::StringStack()
{
	m_szStr = new char[MAX_STRING_STACK_MSG];
	m_szStr[0] = 0;
}

StringStack::~StringStack()
{
	delete[] m_szStr;
}

void StringStack::Push(const char* _szStr)
{
	int oldStrLen = (int)strlen(m_szStr);
	if (oldStrLen + strlen(_szStr) >= MAX_STRING_STACK_MSG) return;

	m_StrLenStack.push_back(oldStrLen);	// 0���� ��
	strcat(m_szStr, _szStr);
}

void StringStack::Pop()
{
	if (m_StrLenStack.size() <= 0) return;

	m_szStr[m_StrLenStack.back()] = 0;
	m_StrLenStack.pop_back();
}

const char* StringStack::GetString(int nLastNString)
{
	if (m_StrLenStack.size() <= 0)
	{
		m_szStr[0] = 0;
		return m_szStr;
	}

	if (nLastNString>(int)m_StrLenStack.size() || nLastNString<1)	nLastNString = (int)m_StrLenStack.size();

	return m_szStr + m_StrLenStack[m_StrLenStack.size() - nLastNString];
}

//////////////////////////////////////////////////////////////////////////



//bool IsAlphaString(HCHAR* str)// , int len)
//{
//	int len = HCharUtil::HStrlen(str);
//
//	for(int i=0 ; i < len ; i++)
//	{
//		if( str[i].IsAlpha() || str[i].IsDigit() )
//			continue;
//		else
//			return false;
//	}
//
//	// ����� �����ϸ� true �ƴϸ� flase
//	if( str[0].IsAlpha() )
//		return true;
//
//	return false;
//}

//// ����� ���ڷθ� �����Ǿ��� ����� �����ϴ� ���ڿ����� �Ǵ�
//bool IsAlphaString(HCHAR* str , int len)
//{
//	if(!str) return false;
//
//	if(len<0)	len = HCharUtil::HStrlen(str);
//
//	for(int i=0 ; i < len ; i++)
//	{
//		if( str[i].IsAlpha() || str[i].IsDigit() )
//			continue;
//		else
//			return false;
//	}
//
//	// ����� �����ϸ� true �ƴϸ� flase
//	if( str[0].IsAlpha() )
//		return true;
//
//	return false;
//}


void writeLog(const char* msg, const char* path, const int i, bool bWithTime)
{
	if (!msg || !path) return;
#ifdef LINUX_PORTING
	printf("%s - %d: %s\n", GetCurrTimeStr(), i, msg);
#else // not LINUX_PORTING
	char tmppath[1000];
	sprintf(tmppath, "%slog.txt", path);
	std::ofstream ofs(tmppath, std::ios::app);

	if (bWithTime)	ofs << GetCurrTimeStr() << " - ";
	if (0 <= i)		ofs << i << ": ";
	ofs << msg << std::endl;
	ofs.flush();
#endif // not LINUX_PORTING
}


//////////////////////////////////////////////////////////////////////////
//	class BufferMng
//////////////////////////////////////////////////////////////////////////

BufferMng::BufferMng(const BufferMng &_oth)
{
	init();
	operator=(_oth);
}

BufferMng::BufferMng(unsigned int _nAllocSize)
{
	init(_nAllocSize);
}

BufferMng::~BufferMng()
{
	if (m_Buffer)
	{
		delete[] m_Buffer;
		m_Buffer = NULL;
	}
}

void BufferMng::init(unsigned int _nAllocSize)
{
	m_CurrUseSize = 0;

	if (_nAllocSize <= 0)
	{
		m_SizeOfMem = 0;
		m_Buffer = NULL;
	}
	else
	{
		m_SizeOfMem = _nAllocSize;
		m_Buffer = new char[m_SizeOfMem + 1];
		m_Buffer[m_SizeOfMem] = '\0';
	}
}

BufferMng& BufferMng::operator=(const BufferMng &_oth)
{
	if (m_SizeOfMem)	delete[] m_Buffer;
	m_Buffer = new char[_oth.m_SizeOfMem + 1];
	memcpy(m_Buffer, _oth.m_Buffer, _oth.m_CurrUseSize);
	m_SizeOfMem = _oth.m_SizeOfMem;
	m_CurrUseSize = _oth.m_CurrUseSize;
	m_UseHistory = _oth.m_UseHistory;
	return *this;
}

void BufferMng::Reset()
{
	m_CurrUseSize = 0;
}

// �޸� �� �Ҵ�
void BufferMng::ReAllocBuffer(size_t _newSize)
{
	if (m_SizeOfMem < DEFAULT_BUFFER_OF_BUFFERMNG * 3 && _newSize<m_SizeOfMem) return;	// �ҷ��� ����� ȣ��� ���� �ӵ� ���� ������ ����

																						// history update	
	m_UseHistory.push_back(_newSize);
	if (m_UseHistory.size()>MAX_USE_HISTORY)	m_UseHistory.pop_front();

	if (_newSize<0)	_newSize = 0;

	if (m_SizeOfMem<_newSize)
		IncreaseBuffer(_newSize);
	else
		DecreaseBuffer();

}

// �޸� (����) ����. �ʿ���� ������ ���� ���ؼ� m_CurrUseSize�� ���� ���õǾ� �־�� ��
void BufferMng::IncreaseBuffer(size_t _newSize)
{
	if (_newSize>0 && m_SizeOfMem>_newSize) return;

	size_t nNewSize = max(m_SizeOfMem * 2, _newSize * 2);
	char* szTempBuffer = new char[nNewSize + 1];
	memcpy(szTempBuffer, m_Buffer, m_CurrUseSize);
	delete[] m_Buffer;
	m_Buffer = szTempBuffer;
	m_SizeOfMem = nNewSize;
}

size_t max_element(std::list<size_t> &_list)
{
	size_t maxElement = -1;

	std::list<size_t>::iterator it = _list.begin();

	for (; it != _list.end(); it++)
	{
		if (it == _list.begin() || (*it)<maxElement)
		{
			maxElement = *it;
		}
	}

	return maxElement;
}

// �޸� ��� (���� ������ ����). ������ �ҽ��� ���� ���ؼ� m_CurrUseSize�� ���� ���õǾ� �־�� ��
void BufferMng::DecreaseBuffer()
{
	if (m_UseHistory.size()<MAX_USE_HISTORY) return;

	//#ifdef	INCUBE_REMARK	// linux������ <algorithm>���� ������ ��
	//#ifdef	LINUX_PORTING	// linux������ <algorithm>���� ������ ��
	//	size_t maxSize = *std::max_element(m_UseHistory.begin(), m_UseHistory.end());
	//#else
	size_t maxSize = max_element(m_UseHistory);
	//#endif	//INCUBE_REMARK

	if (m_SizeOfMem > DEFAULT_BUFFER_OF_BUFFERMNG * 2				// ���� ���� �޸� ũ�Ⱑ �⺻ �޸� ũ���� �ι躸�� ũ��
		&& maxSize < m_SizeOfMem / 4	// ���� MAX_GCOUNT_HISTORY���� �ִ� gcountũ�Ⱑ ���� �޸��� 1/4��
		)
	{
		size_t nNewSize = maxSize * 2;	// ���� MAX_GCOUNT_HISTORY���� �ִ� gcountũ���� �ι�� ����
		char* szTempBuffer = new char[nNewSize + 1];
		memcpy(szTempBuffer, m_Buffer, m_CurrUseSize);
		delete[] m_Buffer;
		m_Buffer = szTempBuffer;
		m_SizeOfMem = nNewSize;
	}
}

char* BufferMng::GetBuffer()
{
	return m_Buffer;
}

size_t BufferMng::GetBufferSize()
{
	return m_SizeOfMem;
}


//////////////////////////////////////////////////////////////////////////
//	class FullGetLine
//////////////////////////////////////////////////////////////////////////

//FullGetLine::FullGetLine(const char *_Filename, std::ios_base::openmode _Mode, int _Prot)
//: std::ifstream(_Filename, _Mode, _Prot)
//{
//	m_GCount=0;
//}
FullGetLine::FullGetLine(const char *_Filename, std::ios_base::open_mode _Mode)
#ifdef	LINUX_PORTING
	: std::ifstream(_Filename, _Ios_Openmode(_Mode))
#else
	: std::ifstream(_Filename, _Mode)
#endif
{
	m_GCount = 0;
}

FullGetLine::FullGetLine()
	: std::ifstream()
{
	m_GCount = 0;
}

FullGetLine::~FullGetLine()
{
	close();
}

bool FullGetLine::Open(const char *_Filename, std::ios_base::open_mode _Mode)
{
	m_GCount = 0;

#ifdef	LINUX_PORTING
	open(_Filename, _Ios_Openmode(_Mode));
#else
	open(_Filename, _Mode);
#endif

	return is_open();
}

const char* FullGetLine::GetLine()
{

	m_Buffer.Reset();
	m_Buffer.GetBuffer()[0] = 0;

	m_GCount = 0;

	if (eof())	return NULL;

	while (!eof())
	{
		size_t nBufferSize = m_Buffer.GetBufferSize();

		this->clear();
		this->getline(m_Buffer.GetBuffer() + m_GCount, (std::streamsize)nBufferSize - m_GCount);
		m_GCount += gcount();
		m_Buffer.m_CurrUseSize = (size_t)m_GCount + 1;

		if (this->fail() && m_GCount == nBufferSize - 1)	// �� ���� ���� �ƴϸ�
		{
			m_Buffer.ReAllocBuffer(nBufferSize * 2);
			continue;
		}

		break;
	}

	return m_Buffer.GetBuffer();
}

const char* FullGetLine::GetBuffer()
{
	return m_Buffer.GetBuffer();
}

std::streamsize FullGetLine::GCount()
{
	return m_GCount;
}




//////////////////////////////////////////////////////////////////////////
//	class ReleaseAssert
//////////////////////////////////////////////////////////////////////////

std::list<std::string> ReleaseAssert::m_strTitleStack;
bool ReleaseAssert::Assert(const void* condition, const char* szMsg, bool bExit, bool bOnlyWriteLog)
{
	return ReleaseAssert::Assert(condition != NULL, szMsg, bExit, bOnlyWriteLog);
}
bool ReleaseAssert::Assert(bool condition, const char* szMsg, bool bExit, bool bOnlyWriteLog)
{
	if (condition == false)
	{
		std::string strMsg = GetTitle(szMsg);

#ifdef INCUBE_REMARK
		//AfxMessageBox(strMsg.c_str());
		if (!bOnlyWriteLog)	MessageBox(NULL, strMsg.c_str(), "���", MB_OK);
#endif //INCUBE_REMARK

		writeLog(strMsg.c_str(), "ReleaseAssert.log", -1, true);

		if (bExit)
		{
			throw strMsg;
		}

		return false;
	}
	return true;
}

std::string ReleaseAssert::GetTitle(const char* szMsg)
{
	std::string strMsg;

	strMsg += "\n========================\n";

	std::list<std::string>::iterator it = m_strTitleStack.begin();
	for (; it != m_strTitleStack.end(); it++)
	{
		strMsg += "< ";
		strMsg += *it;
		strMsg += ">\n";
	}
	if (szMsg)	strMsg += szMsg;
	strMsg += "\n";

	return strMsg;
}

void ReleaseAssert::PushTitle(const char* _title)
{
	m_strTitleStack.push_back(_title);
}

void ReleaseAssert::PopTitle()
{
	m_strTitleStack.pop_back();
}


RATSMng::RATSMng(const char* _szTitle1, const char* _szTitle2)
{
	ReleaseAssert::PushTitle(GetFormatedString("%s - %s", _szTitle1, _szTitle2).c_str());
}

RATSMng::RATSMng(const std::string &_title)
{
	//#ifdef _DEBUG	// ���� �����ϴ� �κ��� �ð��� ���� ��ƸԾ _Debug������ ��	// �ܺο��� #ifdef�� ����
	ReleaseAssert::PushTitle(_title.c_str());
	//#endif
}

RATSMng::~RATSMng()
{
	//#ifdef _DEBUG
	ReleaseAssert::PopTitle();
	//#endif
}

std::string RATSMng::GetTitle()
{
	return ReleaseAssert::GetTitle("");
}


//////////////////////////////////////////////////////////////////////////
//	CheckIf
//////////////////////////////////////////////////////////////////////////

// ���� ���ǿ� �������� ���� �� break�� �ϱ� ���� �Լ�
// //DEBUG_CHECK_IF()�� �̿��� ȣ��
bool CheckIf(bool cond)
{
	if (cond)
	{
		int d = 0;
		d = 0;
		return true;
	}
	return false;
}


//////////////////////////////////////////////////////////////////////////
//	string ���� �Լ���
//////////////////////////////////////////////////////////////////////////

// �ð� ǥ��(�ð� �ƴ�)
std::string GetTimerStr(double seconds, TimeStringMode mode)
{
	char msg[100];
	int hour = (int)seconds / 3600;
	int min = (int)(seconds / 60) % 60;
	int sec = (int)seconds % 60;
	int msec = (int)(seconds * 1000) % 1000;

	switch (mode)
	{
	case TSM_HMSU:	sprintf(msg, "%02d:%02d:%02d:%03d", hour, min, sec, msec);	break;
	case TSM_HMS:	sprintf(msg, "%02d:%02d:%02d", hour, min, sec);		break;
	case TSM_HM:	sprintf(msg, "%02d:%02d", hour, min);				break;
	case TSM_MSU:	sprintf(msg, "%02d:%02d:%02d", hour * 60 + min, sec, msec);		break;
	case TSM_MS:	sprintf(msg, "%02d:%02d", hour * 60 + min, sec);				break;
	case TSM_M:		sprintf(msg, "%02d", hour * 60 + min);				break;
	case TSM_SU:	sprintf(msg, "%02d:%02d", hour * 3600 + min * 60 + sec, msec);				break;
	case TSM_S:		sprintf(msg, "%02d", hour * 3600 + min * 60 + sec);				break;

	}

	return msg;
}



char* GetCurrTimeStr(const char *format)
{
	char defaultFormat[] = { "<%y.%m.%d-%H:%M:%S>" };
	//if(!format) goto HELP_FORMATTED_TIME_MSG;
	if (!format) format = defaultFormat;

	time_t timer;
	struct tm *t;

	timer = time(NULL); // ���� �ð��� �� ������ ���

	t = localtime(&timer); // �� ������ �ð��� �и��Ͽ� ����ü�� �ֱ�

	const char* pStr = format;

#define MAX_TIME_STR 1000	
	static char strResultStr[MAX_TIME_STR];
	strResultStr[0] = 0;

	while (pStr && *pStr)
	{
		const char *pToken = strchr(pStr, '%');
		if (!pToken)
		{
			if (strlen(strResultStr) + strlen(pStr) + 1 > MAX_TIME_STR) break;

			strcat(strResultStr, pStr);
			break;
		}

		int lenResultStr = (int)strlen(strResultStr);
		int addedLen = (int)(pToken - pStr);
		strncat(strResultStr + lenResultStr, pStr, addedLen);
		strResultStr[lenResultStr + addedLen] = 0;

		*pToken++;

		if (strlen(strResultStr) + 20 > MAX_TIME_STR) break;	// ����.. �˳���

		switch (*pToken)
		{
		case 'Y':
			sprintf(strResultStr + strlen(strResultStr), "%04d", t->tm_year + 1900);
			break;
		case 'y':
			sprintf(strResultStr + strlen(strResultStr), "%02d", (t->tm_year + 1900) % 100);
			break;
		case 'm':
			sprintf(strResultStr + strlen(strResultStr), "%02d", t->tm_mon + 1);
			break;
		case 'd':
			sprintf(strResultStr + strlen(strResultStr), "%02d", t->tm_mday);
			break;
		case 'H':
			sprintf(strResultStr + strlen(strResultStr), "%02d", t->tm_hour);
			break;
		case 'I':
		{
			int ti = t->tm_hour % 12;
			if (ti == 0)	ti = 12;
			sprintf(strResultStr + strlen(strResultStr), "%02d", ti);
		}
		break;
		case 'p':
			if (t->tm_hour - 12<0)
				strcat(strResultStr, "����");
			else
				strcat(strResultStr, "����");
			break;
		case 'M':
			sprintf(strResultStr + strlen(strResultStr), "%02d", t->tm_min);
			break;
		case 'S':
			sprintf(strResultStr + strlen(strResultStr), "%02d", t->tm_sec);
			break;
		case 'a':
			switch (t->tm_wday)
			{
			case 0:	strcat(strResultStr, "��");	break;
			case 1:	strcat(strResultStr, "��");	break;
			case 2:	strcat(strResultStr, "ȭ");	break;
			case 3:	strcat(strResultStr, "��");	break;
			case 4:	strcat(strResultStr, "��");	break;
			case 5:	strcat(strResultStr, "��");	break;
			case 6:	strcat(strResultStr, "��");	break;
			}
			break;

		case 'A':
			switch (t->tm_wday)
			{
			case 0:	strcat(strResultStr, "�Ͽ���");	break;
			case 1:	strcat(strResultStr, "������");	break;
			case 2:	strcat(strResultStr, "ȭ����");	break;
			case 3:	strcat(strResultStr, "������");	break;
			case 4:	strcat(strResultStr, "�����");	break;
			case 5:	strcat(strResultStr, "�ݿ���");	break;
			case 6:	strcat(strResultStr, "�����");	break;
			}
			break;
		case 'j':
			sprintf(strResultStr + strlen(strResultStr), "%2d", t->tm_yday + 1);
			break;
		default:
			sprintf(strResultStr + strlen(strResultStr), "%c", *pToken);
			break;
		}

		pToken++;
		pStr = pToken;

	}

	return strResultStr;

	//HELP_FORMATTED_TIME_MSG:
	//	return 
	//		"	%a 	\n"
	//		"	Abbreviated weekday name 	\n"
	//		"	%A 	\n"
	//		"	Full weekday name 	\n"
	//		"	%b 	\n"
	//		"	Abbreviated month name 	\n"
	//		"	%B 	\n"
	//		"	Full month name 	\n"
	//		"	%c 	\n"
	//		"	Date and time representation appropriate for locale 	\n"
	//		"	%d 	\n"
	//		"	Day of month as decimal number (01 ? 31) 	\n"
	//		"	%H 	\n"
	//		"	Hour in 24-hour format (00 ? 23) 	\n"
	//		"	%I 	\n"
	//		"	Hour in 12-hour format (01 ? 12) 	\n"
	//		"	%j 	\n"
	//		"	Day of year as decimal number (001 ? 366) 	\n"
	//		"	%m 	\n"
	//		"	Month as decimal number (01 ? 12) 	\n"
	//		"	%M 	\n"
	//		"	Minute as decimal number (00 ? 59) 	\n"
	//		"	%p 	\n"
	//		"	Current locale's A.M./P.M. indicator for 12-hour clock 	\n"
	//		"	%S 	\n"
	//		"	Second as decimal number (00 ? 59) 	\n"
	//		"	%U 	\n"
	//		"	Week of year as decimal number, with Sunday as first day of week (00 ? 53) 	\n"
	//		"	%w 	\n"
	//		"	Weekday as decimal number (0 ? 6; Sunday is 0) 	\n"
	//		"	%W 	\n"
	//		"	Week of year as decimal number, with Monday as first day of week (00 ? 53) 	\n"
	//		"	%x 	\n"
	//		"	Date representation for current locale 	\n"
	//		"	%X 	\n"
	//		"	Time representation for current locale 	\n"
	//		"	%y 	\n"
	//		"	Year without century, as decimal number (00 ? 99) 	\n"
	//		"	%Y 	\n"
	//		"	Year with century, as decimal number 	\n"
	//		"	%z, %Z 	\n"
	//		"	Either the time-zone name or time zone abbreviation, depending on registry settings; no characters if time zone is unknown 	\n"
	//		"	%% 	\n"
	//		"	Percent sign 	\n"
	//		"	As in the printf function	\n"
	//		;
}



// ��ġ�ϴ� substring�� �� �� �ִ���
int strstrCount(const char* strOrg, const char* substr)
{
	if (!strOrg || !substr) return 0;

	const char* pTokenOrg = strOrg;
	const char* pToken = strstr(pTokenOrg, substr);

	int count = 0;

	while (pToken)
	{
		count++;

		pTokenOrg = pToken + strlen(substr);

		pToken = strstr(pTokenOrg, substr);
	}

	return count;
}

// �ѱ� ����
char* hstrstr(char* _szOrg, const char* _szSubstr)
{
	char* pEndPos = _szOrg + strlen(_szOrg);
	size_t nSubStrLen = strlen(_szSubstr);

	for (; _szOrg<pEndPos; )
	{
		if (strncmp(_szOrg, _szSubstr, nSubStrLen) == 0)	return _szOrg;
		if (0x80 & *_szOrg)	_szOrg += 2;
		else				_szOrg++;
	}

	return NULL;
}

const char* hstrstr(const char* _szOrg, const char* _szSubstr)
{
	const char* pEndPos = _szOrg + strlen(_szOrg);
	size_t nSubStrLen = strlen(_szSubstr);

	for (; _szOrg<pEndPos; )
	{
		if (strncmp(_szOrg, _szSubstr, nSubStrLen) == 0)	return _szOrg;
		if (0x80 & *_szOrg)	_szOrg += 2;
		else				_szOrg++;
	}

	return NULL;
}


// i��° ��ġ�ϴ� substr ������
char* strstr(char* strOrg, const char* substr, int i)
{
	if (!strOrg || !substr) return NULL;

	char* pTokenOrg = strOrg;
	char* pToken = strstr(pTokenOrg, substr);

	int count = 0;

	while (pToken)
	{
		count++;

		if (count == i)	return pToken;

		pTokenOrg = pToken + strlen(substr);

		pToken = strstr(pTokenOrg, substr);
	}

	return NULL;
}

// sub1�� sub2 ������ ���� ����
const char* strstr(const char* _strOrg, const char* _substr1, const char* _substr2, int &_lenOfResult)
{
	assert(_strOrg && _substr1 && _substr2);

	const char* substr = strstr(_strOrg, _substr1);
	if (substr == NULL)	return NULL;

	substr += strlen(_substr1);

	const char* eosubstr = strstr(substr, _substr2);
	if (eosubstr == NULL)	return NULL;

	_lenOfResult = (int)(eosubstr - substr);
	return substr;
}

// str�� �Ϻ�(s���� e����)�� temp_str�� �����Ͽ� �ѱ�
char* Get_PartOfStr(char* temp_str, char* str, int s, int e)
{
	int i, j;
	int cur;
	int len;
	int real_len; //2byte���ڵ� 1�ڷ� ����� ����

	len = (int)strlen(str);
	temp_str[0] = '\0';

	real_len = 0;

	for (i = 0; i<len; i++)
	{
		if (str[i] & 0x80)
			real_len++;
		else
		{
			i++;
			real_len++;
		}
	}

	if (real_len < s)
		return temp_str;

	for (i = 0, j = 0, cur = 0; cur < s + e; i++)
	{
		if (str[i] & 0x80)
		{
			if (cur >= s)
			{
				temp_str[j++] = str[i];
			}
			cur++;
		}
		else
		{
			if (cur >= s)
			{
				temp_str[j++] = str[i];
				temp_str[j++] = str[i + 1];
			}
			cur++;
			i++;
		}
	}
	temp_str[j] = '\0';

	return temp_str;
}

// str �ݺ� ���
size_t sprintsn(char* _buf, const char* str, int cnt)
{
	int i;
	for (i = 0; i<cnt; i++)	sprintf(_buf, str);

	return strlen(_buf);
}

char* GetOptionFromFile(const char* dicPath, const char* optFileName, const char* group, const char* variable, char* _szValue)
{
	char optFullFileName[1000];
	sprintf(optFullFileName, "%s%s", dicPath, optFileName);

	static const char NoOption = 0;
	*_szValue = NoOption;

	std::ifstream ifs(optFullFileName);

	// ������ �� ���� �ɼǵ� ����
	if (!ifs)	return _szValue;


	bool bFindGroup = false;
	char linebuf[1000];

	while (!ifs.eof())
	{
		ifs.getline(linebuf, 999);
		if (ifs.fail() && !ifs.eof())	break;

		// group ����? ��?
		if (linebuf[0] == '[')
		{
			// group ��
			if (bFindGroup)
				return _szValue;

			// group ����?
			else
			{
				// �ش� group ã��. '[', ']'�� ���� ��
				if (0 == strnicmp(group, linebuf + 1, strlen(group)))
				{
					bFindGroup = true;
					continue;
				}
			}
		}

		if (!bFindGroup)
			continue;


		// variable ã��
		do
		{
			char* pComment = strchr(linebuf, ';');
			if (pComment) *pComment = 0;

			char* equlSymbol = hstrpbrk(linebuf, "=");

			// "="�� ������
			if (equlSymbol != NULL)
			{
				// variable�� value �и�
				*equlSymbol = 0;


				// variable ����
				char* pTempVariable = hstrTruncate(linebuf, "\t\r\n ");
				if (strcmp(variable, pTempVariable) != 0)	break;

				// value ���				
				strcpy(_szValue, hstrTruncate(equlSymbol + 1, "\t\r\n "));
				return _szValue;
			}

		} while (false);
	}

	// ��ã����
	return _szValue;
}

std::string GetOptionFromFile(const char* dicPath, const char* optFileName, const char* group, const char* variable)
{
	static char buf[500];
	GetOptionFromFile(dicPath, optFileName, group, variable, buf);
	return buf;
}

bool ExistSameOptionFromFile(const char* dicPath, const char* optFileName, const char* group, const char* variable, const char* value)
{
	char buf[500];
	if (0 == strcmp(value, GetOptionFromFile(dicPath, optFileName, group, variable, buf)))
		return true;

	return false;
}


//////////////////////////////////////////////////////////////////////////
//	���Ϸκ��� �ֱ� �� ���� ��� ���
//////////////////////////////////////////////////////////////////////////
//#include <iostream>
//#include <fstream>
std::list<std::string> GetLine(const char* _filename)
{

	std::list<std::string> resultList;

	if (_filename[0] == 0)
	{
		std::string strErrMsg = "empty file name.";
		std::cerr << strErrMsg.c_str() << std::endl;
		//AfxMessageBox(strErrMsg.c_str());  
		return resultList;
	}

	FullGetLine ifs(_filename);
	if (!ifs)
	{
		std::string strErrMsg = "file open err. : ";
		strErrMsg += _filename;
		std::cerr << strErrMsg.c_str() << std::endl;
		//AfxMessageBox(strErrMsg.c_str());  
		return resultList;
	}

	while (!ifs.eof())
	{
		const char* szLine = ifs.GetLine();
		if (szLine == NULL) break;

		resultList.push_back(szLine);
	}

	return resultList;
}

void UpdateRecentDocu(const char* _filename, const char* _szNewPath, int _nMaxHistory)
{
	const int nMaxFilePath = 1024;

	if (_nMaxHistory <= 0)	_nMaxHistory = 6;

	std::list<std::string> history = GetLine(_filename);

	// �ߺ� ����
	std::list<std::string>::iterator it = history.begin();
	for (; it != history.end(); it++)
	{
		if ((*it) == _szNewPath)
		{
			history.erase(it);
			break;	// �ߺ��� ���� �ִ� �ϳ��� ������
		}
	}

	history.push_front(_szNewPath);

	// ���� ����
	while ((int)history.size()>_nMaxHistory)	history.pop_back();

	// ���Ͽ� ����
	{
		std::ofstream ofs(_filename);
		if (!ofs)
		{
			std::string strErrMsg = "�ֱ� ���� ����� ������ ������ �� �� �����ϴ�. : ";
			strErrMsg += _filename;
			std::cerr << strErrMsg.c_str() << std::endl;
			//AfxMessageBox(strErrMsg.c_str());  
			return;
		}

		while (history.size()>0)
		{
			ofs << history.front().c_str() << std::endl;
			history.pop_front();
		}
	}
}



//
//StrProgress::StrProgress(__int64 range)
//{
//	reset(range);
//}
//
//void StrProgress::reset(__int64 range)
//{
//	if(0<range)
//	{
//		m_range = range;
//	}
//
//	m_startClock = clock();
//	m_oldClock = m_startClock;
//}
//
//const char* StrProgress::GetProgressString(int currPos, char* result)
//{
//	static char buf[100];
//	char* msg = buf;
//
//	if(result)	msg=result;
//	msg[0]=0;
//
//	clock_t currClock = clock();
//
//	if(m_oldClock/CLOCKS_PER_SEC < currClock/CLOCKS_PER_SEC)
//	{	
//		//sprintf(buf, "�����Ȳ: %d/%d (%5.2f%%), ���� �ð�(%d��), ���� �ð�(%d��), ��ü �ð�(%d��)", currPos, sizeOfInputFile, double(currPos)*100/sizeOfInputFile, int(spenTime/CLOCKS_PER_SEC), int(remainTime/CLOCKS_PER_SEC), int(totalTime/CLOCKS_PER_SEC));
//		sprintf(msg, "�����Ȳ: %5.2f%%, ���� �ð�(%d��), ���� �ð�(%d��)", GetProgressPercent(currPos), GetSpendSeconds(), GetRemainSeconds(currPos));
//
//		m_oldClock = clock();
//	}
//
//	return msg;
//}
//
//// %5.2f%%
//double StrProgress::GetProgressPercent(int currPos)
//{
//	return double(currPos)*100/m_range;
//}
//
//int StrProgress::GetSpendSeconds()
//{
//	return int((clock()-m_startClock)/CLOCKS_PER_SEC);
//}
//
//int StrProgress::GetRemainSeconds(int currPos)
//{
//	clock_t currClock = clock();
//	double spenTime = (currClock-m_startClock);
//	double totalTime = m_range*spenTime/currPos;
//	double remainTime = totalTime - spenTime;
//	return int(remainTime/CLOCKS_PER_SEC);
//}
//


//////////////////////////////////////////////////////////////////////////
//	PrintWindowConsole2
//////////////////////////////////////////////////////////////////////////


#ifdef _PRINT_WINDOW_CONSOLE_

void PrintWindowConsole2(const char* msg, bool bResetPosition)
{
	static bool bSetCOORD = false;
	static COORD oldCRD;

	if (msg == NULL)
	{
		oldCRD = PrintWindowConsole("");
		bSetCOORD = true;
		return;
	}

	// ���� ����ص� ������ �ٽ� ����
	else if (bResetPosition)
	{
		if (bSetCOORD)
		{
			PrintWindowConsole(msg, oldCRD.X, oldCRD.Y);
		}
		else
		{
			oldCRD = PrintWindowConsole(msg);
			bSetCOORD = true;
		}
	}

	// �տ� �� �Ϳ� ���̾
	else
	{
		if (bSetCOORD)
		{
			PrintWindowConsole(msg);
		}
		else
		{
			oldCRD = PrintWindowConsole(msg);
			bSetCOORD = true;
		}
	}
}

COORD PrintWindowConsole(const char* strLog, int x, int y)
{
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
	COORD crd;
	crd.X = 0;
	crd.Y = 0;

	if (!GetConsoleScreenBufferInfo(hConsole, &csbiInfo))
	{
#ifdef _CONSOLE
		printf("GetConsoleScreenBufferInfo::Console Error\n");
#else
		MessageBox(NULL, "GetConsoleScreenBufferInfo", "Console Error", MB_OK);
#endif
		return crd;
	}


	if (y<0)	y = csbiInfo.dwCursorPosition.Y;
	if (x<0)	x = csbiInfo.dwCursorPosition.X;

	DWORD dwWrite;

	crd.X = x; crd.Y = y;

	SetConsoleCursorPosition(hConsole, crd);
	WriteFile(hConsole, strLog, (DWORD)strlen(strLog), &dwWrite, NULL);

	return crd;
};
#endif //_PRINT_WINDOW_CONSOLE_


//////////////////////////////////////////////////////////////////////////
//	ProgressData
//////////////////////////////////////////////////////////////////////////


ProgressData::ProgressData()
{
	m_globalClock = clock();



	Reset();
	m_caProgressMsg[0] = 0;
	m_bStop = true;
}


//void ProgressData::SetRange(__int64 range)
//{
//	m_curPos = 0;
//	m_numOfProcessedUnit = 0;
//	m_range = range;
//}

bool ProgressData::SetRange(const char* fileName)
{
	std::ifstream file(fileName);
	if (!file)
	{
		return false;
	}


	// ���� ���� ����
	file.seekg(0, std::ios_base::end);
	int fileLen = (int)file.tellg();

	m_range = fileLen;

	return true;
}

bool ProgressData::Reset(const char* fileName)
{
	if (!SetRange(fileName)) return false;
	Reset(m_range);
	return true;
}

void ProgressData::Reset(__int64 range)
{
	m_bStop = false;
	m_curPos = 0;
	m_range = range;
	m_numOfProcessedUnit = 0;
	//m_caProgressMsg[0]=0;


	m_startClock = clock();
	m_oldClock = m_startClock;


	int s = sizeof(timeStampHistory);
	memset(timeStampHistory, 0x00, sizeof(timeStampHistory));
	timeStampHistory[0].pos = 0;
	timeStampHistory[0].clock = m_startClock;
	m_sizeOfTimeStampHistory = 0;

}

void ProgressData::Stop()
{
	m_bStop = true;
	if (*m_caProgressMsg != 0)
		sprintf(m_caProgressMsg + strlen(m_caProgressMsg), "[%s]\n", GetTimerStr((clock() - m_startClock) / CLOCKS_PER_SEC).c_str());
}

void ProgressData::SetMsg(const char* msg)
{
	strncpy(m_caProgressMsg, msg, PROGRESSDLG2_REGULAR_MSG);
	m_caProgressMsg[PROGRESSDLG2_REGULAR_MSG] = 0;
}

const char* ProgressData::GetMsg()
{
	return m_caProgressMsg;
}

void ProgressData::AttachtMsg(const char* msg)
{
	if (msg == NULL)	return;

	// ���� ���¸� ��Ÿ���� ���ڿ�, �ִ� 4���常 ��Ÿ���� �� �� ���� ����
	{
		int numOfline = strstrCount(m_caProgressMsg, "\n");
		if (3<numOfline)
		{
			strcpy(m_caProgressMsg, strstr(m_caProgressMsg, "\n") + 1);
		}
		//if(m_caProgressMsg[0]!=0 && m_caProgressMsg[0]!='\n' && m_caProgressMsg[strlen(m_caProgressMsg)-1]!='\n'  )	strcat(m_caProgressMsg,"\n");
		int len = (int)strlen(m_caProgressMsg);
		strcat(m_caProgressMsg, msg);
		strTruncWithEndStr(m_caProgressMsg + len, PROGRESSDLG2_REGULAR_MSG, "...");
	}
}

std::string ProgressData::GetGlogalSpenStr()
{
	return GetTimerStr((clock() - m_globalClock) / CLOCKS_PER_SEC);
}

std::string ProgressData::GetProgressString(char* result, bool bUseUnitSpeed, int _nFor)
{
	static char buf[1000];
	char* msg = buf;

	if (result)	msg = result;
	msg[0] = 0;

	clock_t currClock = clock();

	//if(m_oldClock/CLOCKS_PER_SEC < currClock/CLOCKS_PER_SEC)
	{
		//sprintf(buf, "�����Ȳ: %d/%d (%5.2f%%), ���� �ð�(%d��), ���� �ð�(%d��), ��ü �ð�(%d��)", currPos, sizeOfInputFile, double(currPos)*100/sizeOfInputFile, int(spenTime/CLOCKS_PER_SEC), int(remainTime/CLOCKS_PER_SEC), int(totalTime/CLOCKS_PER_SEC));
		sprintf(msg, "�����Ȳ:%5.2f%%, Pass_%s, Remain_%s, Whole_%s", GetProgressPercent(), GetTimerStr(GetSpendSeconds(), TSM_MS).c_str(), GetTimerStr(GetRemainSeconds(), TSM_MS).c_str(), GetTimerStr(GetSpendSeconds() + GetRemainSeconds(), TSM_MS).c_str());
		if (bUseUnitSpeed)	sprintf(msg + strlen(msg), ", %dU/s", (int)GetSpeed().unitsPerSec);
		if (bUseUnitSpeed)	sprintf(msg + strlen(msg), ", ���� %dU/s", (int)GetMomentSpeed(_nFor).unitsPerSec);

		m_oldClock = clock();
	}

	return msg;
}

// %5.2f%%
double ProgressData::GetProgressPercent()
{
	return double(m_curPos) * 100 / m_range;
}

double ProgressData::GetSpendSeconds()
{
	return double((clock() - m_startClock)) / CLOCKS_PER_SEC;
}

double ProgressData::GetRemainSeconds()
{

	// �ð� = �Ÿ�/�ӵ�
	//return int((m_range-m_curPos)/GetSpeed());

	return  (m_range - m_curPos) / GetMomentSpeed(MAX_TIME_STAMP_HISTORY).posPerSec;
	//printf("range:	%d,	cur:	%d,	spd:	%d,	rSec:	%d\n", (int)m_range, (int)m_curPos, (int)GetMomentSpeed(MAX_TIME_STAMP_HISTORY).posPerSec, remainSeconds);
	//return remainSeconds;

	//clock_t currClock = clock();
	//double spenTime = (currClock-m_startClock);
	//double totalTime = m_range*spenTime/m_curPos;
	//double remainTime = totalTime - spenTime;
	//return int(remainTime/CLOCKS_PER_SEC);
}


double ProgressData::GetNoRefreshSeconds()
{
	return double(clock() - m_oldClock) / CLOCKS_PER_SEC;
}
PosAndUnitsPerSec ProgressData::GetSpeed()
{
	double spendSeconds = max(GetSpendSeconds(), 1);
	return PosAndUnitsPerSec(m_curPos / spendSeconds, m_numOfProcessedUnit / spendSeconds);
}

// nFor�� ������ ���� ó�� �ӵ�
PosAndUnitsPerSec ProgressData::GetMomentSpeed(int nFor)
{
	nFor = min(nFor, m_sizeOfTimeStampHistory - 1);

	if (nFor<0)
	{
		nFor = 0;
		timeStampHistory[0].numOfProcessedUnit = 0;
		timeStampHistory[0].pos = 0;
	}

	while (nFor>0 && timeStampHistory[0].numOfProcessedUnit == 0 && timeStampHistory[0].pos == 0) nFor--;

	// �Ʒ��� m_sizeOfTimeStampHistory-1�� �׻� ���� �����Ƿ� �Ʒ��� �� �ʿ� ����.
	// ��, m_sizeOfTimeStampHistory==0�� �� ������ ������ ������
	//while(nFor>0 && timeStampHistory[nFor].clock==0) nFor--;	//�ʱ⿡�� timeStampHistory �� �� ���� ������ �ž� �����Ƿ�, ���� �� ���� �����

	int procUnitsCount = (int)(timeStampHistory[0].numOfProcessedUnit - timeStampHistory[nFor].numOfProcessedUnit);
	int procSpendRange = (int)(timeStampHistory[0].pos - timeStampHistory[nFor].pos);
	int spenClocks = timeStampHistory[0].clock - timeStampHistory[nFor].clock;
	double spendSeconds = double(max(spenClocks, 1)) / CLOCKS_PER_SEC;

	return PosAndUnitsPerSec(procSpendRange / spendSeconds, procUnitsCount / spendSeconds);
}

// Ÿ�̸Ӱ� ������ �Ŀ��� �� �Լ��� ȣ���ϸ� ��
void ProgressData::SetTimeStamp(__int64 currPos, __int64 numOfProcessedUnit, bool _bMustPress)
{
	clock_t curClock = clock();
	static clock_t oldClock = curClock;

	if (!_bMustPress && currPos>0 && (curClock - oldClock) / CLOCKS_PER_SEC<1) return;
	if (currPos == -1)	currPos = m_range;
	if (timeStampHistory[0].pos > currPos) return;

	oldClock = curClock;

	m_curPos = currPos;
	m_numOfProcessedUnit = numOfProcessedUnit;
	m_sizeOfTimeStampHistory = min(m_sizeOfTimeStampHistory + 1, MAX_TIME_STAMP_HISTORY);

	memmove(timeStampHistory + 1, timeStampHistory, sizeof(TimeStampForProgressData)*(MAX_TIME_STAMP_HISTORY - 1));
	timeStampHistory[0].pos = m_curPos;
	timeStampHistory[0].clock = curClock;
	timeStampHistory[0].numOfProcessedUnit = numOfProcessedUnit;
	//timeStampHistory[0].momentSpeed = GetMomentSpeed();

}


//////////////////////////////////////////////////////////////////////////
//	AtExitDelete
//////////////////////////////////////////////////////////////////////////

#ifdef	INCUBE_REMARK
// delObj	: ������ �޸�
// newObj	: ����� �޸�
// delObj==NULL && newObj==NULL	: ��ϵ� ��� ���� �Ҵ� �޸� ����
void* AtExitDelete(void*delObj, void* newObj)
{
	static std::set<void*> allocSet;
	std::set<void*>::iterator it;

	if (delObj == NULL&&newObj == NULL)
	{
		it = allocSet.begin();
		while (it != allocSet.end())
		{
			delete[] * it;
			it++;
		}
	}

	if (delObj)
	{
		it = allocSet.find(delObj);
		if (it != allocSet.end())
		{
			allocSet.erase(it);
			delete[] delObj;
		}
	}

	if (newObj)
	{
		allocSet.insert(newObj);
	}

	return newObj;
}

void AtExitDelete()
{
	AtExitDelete(NULL, NULL);
}
#endif	//INCUBE_REMARK



//   �⿵21���⸮��ũ������, 20, "..."
// ->�⿵21���⸮��ũ��...
int strTruncWithEndStr(char* source, int truncWithLen, const char* _endStr)
{
	if (source == NULL) return 0;

	char tempEndStr = 0;
	const char* endStr = _endStr;
	if (endStr == NULL) endStr = &tempEndStr;	// endStr�� null�̸� ���� 0�� ���ڿ��� ��ġ

	int lenOfSource = (int)strlen(source);
	int lenOfEndStr = (int)strlen(endStr);

	// ������ ���ڿ� ����(truncWithLen)�� �ʰ��ϴ� ��츸 �ǵ帲
	if (lenOfSource <= truncWithLen) return lenOfSource;

	// �߶� ���� ������� ����(truncWithLen)���� ���� �� ���ڿ�(endStr)�� �� ��� �� ��
	if (truncWithLen < lenOfEndStr)	return lenOfSource;


	{
		// endStr�� ���� ��ġ ã��
		char* pCandCpyPos = source + truncWithLen - lenOfEndStr;	// ������ ��ġ
		char* pRealCpyPos;										// �ѱ� �� 2����Ʈ ������ ��� ����
		for (pRealCpyPos = source; pRealCpyPos<pCandCpyPos; pRealCpyPos++)
		{
			if (*pRealCpyPos & 0x80) pRealCpyPos++;
		}

		// pRealInsPos�� ������ ���� ��ġ�� �ٸ��� ��, ���������� 2����Ʈ�� �������� ����
		// ���� 1����Ʈ¥�������� for������ pCandCpyPos==pRealCpyPos�� �������� ����
		if (pCandCpyPos<pRealCpyPos)	pRealCpyPos -= 2;

		// ���� ���̱�
		strcpy(pRealCpyPos, endStr);
	}

	return (int)strlen(source);
}

// 20,  �⿵21���⸮��ũ������
// ->...21���⸮��ũ������
int strTruncWithStartStr(int lenOfLimit, char* szSource, int _nOrgSourceLen, const char* _szEllipsis)
{
	DAssert(szSource != NULL);

	const char szDefaultEllipsis[] = { "��" };
	const char* szEllipsis = _szEllipsis;
	if (szEllipsis == NULL)	szEllipsis = szDefaultEllipsis;

	int nOrgSourceLen = (int)strlen(szSource);
	if (_nOrgSourceLen>0 && _nOrgSourceLen<nOrgSourceLen)	nOrgSourceLen = _nOrgSourceLen;

	// set token.Str
	int newStrLen = min(lenOfLimit, nOrgSourceLen);
	{
		// ������ ��� ���ʿ� EllipsisStr�� �ְ� �� �κ��� �ڸ�		
		strncpy(szSource, szSource + nOrgSourceLen - newStrLen, newStrLen);
		szSource[newStrLen] = 0;
	}

	// ������ ��� ���ʿ� EllipsisStr�� �ְ� �� �κ��� �ڸ�
	if (nOrgSourceLen>lenOfLimit)
	{
		memcpy(szSource, szEllipsis, strlen(szEllipsis));	// lenOfToken(nOrgSourceLen?) �� �� ������ �ʿ����. �̹� �˸��� ����
	}

	return newStrLen;
}

std::string GetTruncedStrWithStartStr(int lenOfLimit, const std::string &strSource, const char* _szEllipsis)
{
	char* szLineBuf = new char[strSource.length() + 1];
	strcpy(szLineBuf, strSource.c_str());
	strTruncWithStartStr(lenOfLimit, szLineBuf, -1, _szEllipsis);
	std::string strResult = szLineBuf;
	delete[] szLineBuf;
	return strResult;
}


//////////////////////////////////////////////////////////////////////
// ��θ� ��Ÿ���� ���ڿ����� ..\�� ������ �������ֱ�

std::string removeUpperDir(const char* _orgPath)
{
	std::vector<std::string> vOrgPath = strtokToVector(_orgPath, STR_DIR_DELIMIT, true);
	std::vector<std::string> vNewPath;

	int i;
	for (i = 0; i<(int)vOrgPath.size(); i++)
	{
		if (vOrgPath[i] == STR_DIR_DELIMIT)	continue;

		if (vOrgPath[i] == ".." && vNewPath.size()>1)
		{
			std::string *pstrPrevDir = &vNewPath[vNewPath.size() - 2];
			if ((*pstrPrevDir) != ".."
				&& (*pstrPrevDir).at((*pstrPrevDir).length() - 1) != ':'
				)
			{
				vNewPath.pop_back();	// "\\"
				vNewPath.pop_back();
				i++;
				continue;
			}
		}

		vNewPath.push_back(vOrgPath[i++]);
		if (i<(int)vOrgPath.size())	vNewPath.push_back(vOrgPath[i]);		// "\\"
	}

	std::string strResult;
	for (i = 0; i<(int)vNewPath.size(); i++)
	{
		strResult += vNewPath[i];
	}

	return strResult;
}


void FileNameNumbering(char* filename, int idx)
{
	char ext[200];

	char* pDot = strrchr(filename, '.');
	if (pDot)	strcpy(ext, pDot);
	else		pDot = filename + strlen(filename);

	strcat(pDot, ".");
	itoa(idx, pDot + 1, 10);
	strcat(filename, ext);
}

int strcmp(const char* str1, const char* str2, bool bIgnoreBlank)
{
	if (!bIgnoreBlank) return strcmp(str1, str2);

	size_t nLenStr1 = strlen(str1);
	size_t nLenStr2 = strlen(str2);

	char* buf1 = new char[nLenStr1 + 1];
	char* buf2 = new char[nLenStr2 + 1];

	strcpy(buf1, str1);
	strcpy(buf2, str2);

	while (strReplace(buf1, " ", ""));
	while (strReplace(buf1, "\t", ""));
	while (strReplace(buf1, "\r", ""));
	while (strReplace(buf1, "\n", ""));

	while (strReplace(buf2, " ", ""));
	while (strReplace(buf2, "\t", ""));
	while (strReplace(buf2, "\r", ""));
	while (strReplace(buf2, "\n", ""));

	int cmpResult = strcmp(buf1, buf2);

	delete[] buf1;
	delete[] buf2;

	return cmpResult;

}


// _szOrgWord�� _nRotStep ��ŭ ���������� ȸ�����Ѽ� _szResultBuf�� ����. _szOrgWord!=_szResultBuf
char* strrot(const char* _szOrgWord, char* _szResultBuf, int _nLen, int _nRightRotStep)
{
	size_t nOrgLen = (_nLen<0 ? strlen(_szOrgWord) : (size_t)_nLen);
	int nRotStep = _nRightRotStep % int(nOrgLen);
	if (nRotStep<0)	nRotStep += int(nOrgLen);
	memcpy(_szResultBuf + nRotStep, _szOrgWord, nOrgLen - nRotStep);	// �� �κ��� �ڷ�
	memcpy(_szResultBuf, _szOrgWord + nOrgLen - nRotStep, nRotStep);	// �޺κ��� ������	    
	_szResultBuf[nOrgLen] = 0;
	return _szResultBuf;
}

// orgstr �� ���� delimit���� ���� ��� ����
char* hstrTruncate(char* orgstr, const char* delimits)
{

	char* pNewStr = hstrskip(orgstr, delimits);
	if (pNewStr == NULL)	pNewStr = orgstr;

	char* pEndNewStr = hstrrskip(pNewStr, delimits);
	*pEndNewStr = 0;

	return pNewStr;
}

std::string hstrTruncate(const char* orgstr, const char* delimits)
{
	const char* pNewStr;
	//hstrskip(orgstr, delimits, &pNewStr);
	pNewStr = hstrskip(orgstr, delimits);
	if (pNewStr == NULL)	pNewStr = orgstr;

	const char* pEndNewStr = pNewStr + hstrcspn(pNewStr, delimits);

	std::string strResult(pNewStr, pEndNewStr - pNewStr);
	return strResult;
}


///*
//std::vector<std::string> strtok(char* _szSource, const char* _szDelimit)
//{
//	std::vector<std::string> tokenVec;
//
//	char* szWork = hstrskip(_szSource, _szDelimit);
//	char* szEndToken = hstrrpbrk(szWork, _szDelimit);
//	std::string strToken(szWork, szEndToken-szWork);
//
//
//    return tokenVec;
//}
//*/

// ��� ��� ���
std::string GetRelativePath(const char* _szCurrentPath, const char* _szAbsolutePath, bool _bAbleCaseFolding)
{
	DAssert(_szCurrentPath && _szAbsolutePath);
	if (strlen(_szCurrentPath) == 0) return "";
	if (strlen(_szAbsolutePath) == 0) return "";

	char szCurrentPath[2000] = { "" };
	char szAbsolutePath[2000] = { "" };

	strcpy(szCurrentPath, _szCurrentPath);
	strcpy(szAbsolutePath, _szAbsolutePath);



	std::vector<std::string> vCurrentPath = strtokToVector(szCurrentPath, STR_DIR_DELIMIT);
	std::vector<std::string> vAbsolutePath = strtokToVector(szAbsolutePath, STR_DIR_DELIMIT);


	int i;

	// �б��� ã��
	for (i = 0; i<(signed)vCurrentPath.size() && i<(signed)vAbsolutePath.size(); i++)
	{
		if (_bAbleCaseFolding)
		{
			if (0 != stricmp(vCurrentPath[i].c_str(), vAbsolutePath[i].c_str()))	break;
		}
		else
		{
			if (vCurrentPath[i] != vAbsolutePath[i])	break;
		}
	}

	int idxOfMissMatch = i;	// �� ��ΰ� ó������ ����ġ�ϴ� ��
	int nBacktraceDepth = (signed)vCurrentPath.size() - idxOfMissMatch;	// �θ�� �ö󰡾� �� ����

																		// ��� ����
	std::string strResultPath;
	{
		// ���� ���
		if (vAbsolutePath.size() == vCurrentPath.size())
		{
			// szAbsolutePath�� ���� ���������� ���ϸ�����
			if (szAbsolutePath[strlen(szAbsolutePath) - 1] == C_DIR_DELIMIT)	return STR_CURRENT_DIR_DELIMIT;
			return GetOnlyFileName(szAbsolutePath);
		}

		// ÷���� Ʋ���� �����θ� �״�� ��
		if (idxOfMissMatch == 0)	return szAbsolutePath;

		// �ö� ��� ����
		for (i = 0; i<nBacktraceDepth; i++)
		{
			strResultPath += STR_UPPER_DIR_DELIMIT;
		}

		// ������ ��� ����
		for (i = idxOfMissMatch; i<(signed)vAbsolutePath.size(); i++)
		{
			strResultPath += vAbsolutePath[i];
			if (i + 1 != vAbsolutePath.size())	strResultPath += STR_DIR_DELIMIT;
		}

		// szAbsolutePath�� ���� ���������� ���ϸ�����
		if (szAbsolutePath[strlen(szAbsolutePath) - 1] == C_DIR_DELIMIT && strResultPath.at(strResultPath.length() - 1) != C_DIR_DELIMIT)
		{
			strResultPath += STR_DIR_DELIMIT;
		}
	}

	return strResultPath;
}

std::string GetUpperPath(const char* _szSourcetPath)
{
	return removeUpperDir((GetOnlyDir(_szSourcetPath) + STR_UPPER_DIR_DELIMIT + GetOnlyFileName(_szSourcetPath)).c_str());
}

void BusyWait(int nMiliSec)
{
	clock_t sTime = clock() * 1000 / CLOCKS_PER_SEC;
	while (sTime + nMiliSec > clock() * 1000 / CLOCKS_PER_SEC);
}

void RunBatchCmd(const char* cmds)
{
	std::ofstream ofs("MyBatchCmd.bat");
	ofs << cmds;
	ofs.close();
	system("MyBatchCmd.bat");
#ifdef LINUX_PORTING
	sleep(1);
#else
	BusyWait(500);	// Sleep(500)�� �ᵵ �ǳ� windows.h�� afxwin.h���ϱ� ����
#endif
}

//////////////////////////////////////////////////////////////////////////
//	class ListFileMng
//////////////////////////////////////////////////////////////////////////
// ������ ���е� ������ ���������� �о ����Ʈ�� ���ͷ� ����


ListFileMng::ListFileMng(int _nMinLength, int _nMaxLength)
{
	m_nMinLength = _nMinLength;
	m_nMaxLength = _nMaxLength;
}

bool ListFileMng::Open(const char* _filename)
{
	bool isOK = m_ifsInput.Open(_filename);
	Buffering(m_nMaxLength);
	return isOK;
}

bool ListFileMng::IsOpen()
{
	return m_ifsInput.is_open();
}

void ListFileMng::Buffering(int _size)
{
	if ((int)m_RearList.size() > m_nMinLength) return;

	if (_size<0)	_size = m_nMaxLength;

	const char* szLine;
	while ((int)m_RearList.size()<_size && !m_ifsInput.eof())
	{
		szLine = m_ifsInput.GetLine();
		m_RearList.push_back(strtokToVector(szLine, "\t"));
	}
}

bool ListFileMng::MoveNext()
{

	// m_RearList ���� ����
	Buffering(m_nMaxLength + 1);

	// �̵� ����?
	if (m_RearList.size() == 0)	 return false;

	// �̵�
	m_PostList.push_front(m_RearList.front());
	m_RearList.pop_front();

	// m_PostList ���� ����
	if ((int)m_PostList.size()>m_nMaxLength)	m_PostList.pop_back();

	return true;
}

void ListFileMng::Erase(int _idxOfAround)
{
	std::list<std::vector<std::string> >::iterator it = GetAround(_idxOfAround);

	if (_idxOfAround<0)
	{
		if (it == m_PostList.end())	return;
		m_PostList.erase(it);
	}
	else
	{
		if (it == m_RearList.end())	return;
		m_RearList.erase(it);
	}

	Buffering(m_nMaxLength);
}

// idxOfAround == 0 ���� ����
bool ListFileMng::GetAround(int _idxOfAround, std::vector<std::string> &_OutVec)
{
	std::list<std::vector<std::string> >::iterator it = GetAround(_idxOfAround);
	if (it == m_PostList.end())	return false;
	if (it == m_RearList.end())	return false;

	_OutVec = (*it);

	return true;
}

// �����ϸ� m_PostList.end()
std::list<std::vector<std::string> >::iterator ListFileMng::GetAround(int _idxOfAround)
{
	//if(m_nMaxLength*-1>_idxOfAround)	return m_PostList.end();
	//if(m_nMaxLength<_idxOfAround)		return m_PostList.end();

	std::list<std::vector<std::string> >::iterator it;
	int i;

	if (_idxOfAround<0)
	{
		if (_idxOfAround*-1 - 1 >= (int)m_PostList.size())	return m_PostList.end();

		it = m_PostList.begin();
		//if(it==m_PostList.end())	return m_PostList.end();

		for (i = -1; i>_idxOfAround; i--, it++)
		{
			if (it == m_PostList.end())	break;
		}
		//if(it==m_PostList.end())	return m_PostList.end();

		return it;
	}
	else
	{
		if (_idxOfAround >= (int)m_RearList.size())
		{
			Buffering();
			if (_idxOfAround >= (int)m_RearList.size()) return m_RearList.end();
		}

		it = m_RearList.begin();
		//if(it==m_RearList.end())	return m_PostList.end();

		for (i = 0; i<_idxOfAround; i++, it++)
		{
			if (it == m_RearList.end())	break;
		}
		//if(it==m_RearList.end())	return m_PostList.end();

		return it;
	}
}



#define FILECMP_MAX_BUF 1000
int FileCmp(const char* _szFileName1, const char* _szFileName2)
{
	assert(_szFileName1 && _szFileName2);
	std::ifstream ifs1(_szFileName1);
	assert(ifs1);
	if (!ifs1)	return -1;

	std::ifstream ifs2(_szFileName1);
	assert(ifs2);
	if (!ifs2)	return 1;

	char szBuf1[FILECMP_MAX_BUF];
	char szBuf2[FILECMP_MAX_BUF];

	while (!ifs1.eof() && !ifs2.eof())
	{
		ifs1.getline(szBuf1, FILECMP_MAX_BUF);
		ifs2.getline(szBuf2, FILECMP_MAX_BUF);

		int cmp = strncmp(szBuf1, szBuf2, (size_t)max(ifs1.gcount(), ifs2.gcount()));
		if (cmp != 0)	return cmp;

		ifs1.clear();
		ifs2.clear();
	}

	if (ifs1.eof() && ifs2.eof())	return 0;
	if (ifs1.eof())	return -1;
	return 1;
}

#include <sys/types.h>
#include <sys/stat.h>

// return : ������ 0, _szFileName1�� ũ�� 1, _szFileName2�� ũ�� 2, _szFileName1�� ������ -1, _szFileName2�� ������ -2
int FileCreationCmp(const char* _szFileName1, const char* _szFileName2)
{
	struct _stat stat1, stat2;
	int err = _stat(_szFileName1, &stat1);
	if (err)	return -1;
	_stat(_szFileName2, &stat2);
	if (err)	return -2;

	if (stat1.st_ctime > stat2.st_ctime)	return 1;
	if (stat1.st_ctime < stat2.st_ctime)	return 2;
	return 0;
}