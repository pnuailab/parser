#pragma once



#ifdef CONTAINER_EXPORTS
#		ifndef PNU_CONTAINER_LIB_API
#		define PNU_CONTAINER_LIB_API __declspec(dllexport)
#		endif
#else
#		ifndef PNU_CONTAINER_LIB_API
#		define PNU_CONTAINER_LIB_API __declspec(dllimport)
#		endif
#endif

#ifdef	LINUX_PORTING
#		undef	PNU_CONTAINER_LIB_API
#		define	PNU_CONTAINER_LIB_API
#endif



#include "SimpleDicFormat.h"
#include <vector>
#include <string>
#include <queue>
#include <set>
 
using namespace std;

size_t PNU_CONTAINER_LIB_API DefaultNodeDataAnalysisMain(const char* _szLineBuf, SimpleNodeVector &_vecData, set<string> &_strKeySet, int _nLineCount);
size_t DefaultNodeDataAnalysisSub(const vector<string> &_strTokenVec, SimpleNodeVector &_vecData, set<string> &_strKeySet, int _nLineCount, const char* _szLineBuf);
bool PNU_CONTAINER_LIB_API DefaultCheckDic(const char* _szSourceFileName, const char* _szOutputDicFileName);

int PNU_CONTAINER_LIB_API MakeSimpleDic
(
 const char* _szSourceFileName,   
 const char* _szOutputDicFileName, 
 size_t (*_NodeDataAnalysis)(const char* _szLineBuf, SimpleNodeVector &_vecData, set<string> &_strKeySet, int _nLineCount), 
 bool (*_CheckDic)(const char* _szSourceFileName, const char* _szOutputDicFileName), 	
 bool _bSZDataMode
 );


