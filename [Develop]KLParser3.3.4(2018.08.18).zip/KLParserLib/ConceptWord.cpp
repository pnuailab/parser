#include "ConceptWord.h"

using namespace std;

void ConceptWord::setCW(string _word)
{
	string conceptWord = "";
	string targetWord = "";
	string tmp = "";

	int pos = 0;
	
	conceptWord = _word;
	if ((pos = conceptWord.find("(")) != string::npos)
	{
		conceptWord.erase(pos, conceptWord.length() - pos);
	}
#ifdef LINUX_PORTING

	strncpy(m_szConceptWord, conceptWord.c_str(), MAX_MORP_LEN);

#else

	strcpy_s(m_szConceptWord, MAX_MORP_LEN, conceptWord.c_str());

#endif

	targetWord = _word;
	tmp = targetWord;
	if ((pos = targetWord.find("(")) != string::npos)
	{
		// front tokenize
		targetWord.erase(0, pos + 1);
		if ((pos = targetWord.find(")")) != string::npos)
		{
			// rear tokenize
			targetWord.erase(pos, pos + 1);
			tmp = targetWord;
			while ((pos = targetWord.find("|")) != string::npos)
			{
				char* inputWord = new char[MAX_MORP_LEN];
				targetWord.erase(pos, targetWord.length() - pos);
				tmp.erase(0, pos + 1);
#ifdef LINUX_PORTING

				strncpy(inputWord, targetWord.c_str(), MAX_MORP_LEN);

#else

				strcpy_s(inputWord, MAX_MORP_LEN, targetWord.c_str());

#endif
				m_szTargetWordList.push_back(inputWord);
			}
			char* inputWord = new char[MAX_MORP_LEN];

#ifdef LINUX_PORTING

				strncpy(inputWord, targetWord.c_str(), MAX_MORP_LEN);

#else

			strcpy_s(inputWord, MAX_MORP_LEN, targetWord.c_str());

#endif
			m_szTargetWordList.push_back(inputWord);
		}
	}
}

bool ConceptWord::isEmpty()
{
	if (m_szConceptWord != NULL
		|| m_szConceptWord != ""
		|| m_szTargetWordList.size() > 0)
	{
		return false;
	}
	else
	{
		return true;
	}
}

ConceptWord::ConceptWord()
{

}

ConceptWord::~ConceptWord()
{

}