#pragma once

class MorphemeIndex
{
public:
	MorphemeIndex();
	int m_TokenIndex;
	int m_MAIndex;
	int m_MorphemeIndex;

	bool operator==(MorphemeIndex& _b);

	void set(MorphemeIndex& _b);

	void clear();
};