#pragma once
#pragma warning(disable : 4251)
#pragma warning(disable : 4786)

#include <vector>

class ParsingElement;
class ParsingElementList;
class Element;

#ifdef KLPARSERLIB_EXPORTS
#	define KLPARSERLIB_API __declspec(dllexport)
#else
#	define KLPARSERLIB_API __declspec(dllimport)
#endif

#ifdef	LINUX_PORTING
#		undef	KLPARSERLIB_API
#		define	KLPARSERLIB_API
#endif
