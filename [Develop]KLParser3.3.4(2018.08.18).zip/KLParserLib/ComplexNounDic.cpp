#include "ComplexNounDic.h"
#include <iostream>

ComplexNounDic::ComplexNounDic(void)
{
}

ComplexNounDic::~ComplexNounDic(void)
{
}

// ���ո����� ó�� �ܾ �ִ��� Ȯ���غ���.
bool ComplexNounDic::isThereFirstNoun(CString& _strFirst)
{
	return false;

	set<CString>::iterator itDic;

	itDic = m_DicFirstNoun.find( _strFirst );

	if( itDic == m_DicFirstNoun.end() ) return false;
	else return true;
}

// _strNoun�� ��ϵ� ���ո����̸� true�� ��ȯ.
bool ComplexNounDic::isComplexNoun(CString& _strFull)
{
	set<CString>::iterator itDic;

	itDic = m_DicComplexNoun.find( _strFull );

	if( itDic == m_DicComplexNoun.end() ) return false;
	else return true;
}

// �־��� �̸��� ���Ϸκ��� ������ �о���δ�.
bool ComplexNounDic::loadDicFromFile(CString& _strFilename)
{
	ifstream fin(_strFilename.GetBuffer());

	if( !fin ) return false;

	m_DicComplexNoun.clear();
	m_DicFirstNoun.clear();

	const int MaxStrSize = 1024;
	CString strFull, strFirst;
	char szTemp[MaxStrSize];

	while( !fin.eof() )
	{
		fin >> szTemp;
		strFull = szTemp;
#ifdef LINUX_PORTING
		strFull.Remove('\r');
		strFirst.Remove('\r');
#endif

		if( strFull == "" ) continue;
		
		fin >> szTemp;
		strFirst = szTemp;
		if( strFirst == "" ) continue;

		m_DicComplexNoun.insert( strFull );
		m_DicFirstNoun.insert( strFirst );
	}

	return true;
}



#ifdef LINUX_PORTING
// �־��� �̸��� ���Ϸκ��� ������ �о���δ�.
bool ComplexNounDic::loadDicFromFile(char* _strFilename)
{
	ifstream fin(_strFilename);

	if (!fin) return false;

	m_DicComplexNoun.clear();
	m_DicFirstNoun.clear();

	const int MaxStrSize = 1024;
	CString strFull, strFirst;
	char szTemp[MaxStrSize];

	while (!fin.eof())
	{
		fin >> szTemp;
		strFull = szTemp;
#ifdef LINUX_PORTING
		strFull.Remove('\r');
		strFirst.Remove('\r');
#endif

		if (strFull == "") continue;

		fin >> szTemp;
		strFirst = szTemp;
		if (strFirst == "") continue;

		m_DicComplexNoun.insert(strFull);
		m_DicFirstNoun.insert(strFirst);
	}

	return true;
}
#endif