#include "Util.h"

Util::Util(void)
{
}

Util::~Util(void)
{
}


char* Util::getStr(HCHAR* _hstr, char* _str)
{
	HString hsWan(_hstr);
	hsWan.ToPrintJongsung();
	hsWan.ConvertToString( _str );
	CodeMng::_JohabToWansung(_str);
	return _str;
}
