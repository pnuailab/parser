#include "DependencyElement.h"

DependencyElement::DependencyElement(void)
: m_nFlag(0)
, m_PM(0)
{
}

DependencyElement::~DependencyElement(void)
{
}

bool DependencyElement::isSame(DependencyElement* _DE)
{
	if( !m_PM ) return true;
	if( !_DE ) return false;
	
	if( m_nFlag == _DE->m_nFlag 
		&& m_PM == _DE->m_PM )
		return true;

	return false;
}

void DependencyElement::printThis(ostream& _out)
{
	_out << "m_nFlag(" << m_nFlag << "),";
	if( isParsingMorpheme() )
	{
		_out << "m_PM(";
		m_PM->printThis(_out);
		_out << ")";
	}
	else if( isParsingElement() )
	{
		_out << "m_PE(";
		m_PE->printThis(_out);
		_out << ")";
	}
	else
	{
		_out << "�߸��� m_nFlag ���Դϴ�.";
	}
}