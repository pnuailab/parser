#include "MorphemeIndex.h"

MorphemeIndex::MorphemeIndex()
{
	clear();
}

bool MorphemeIndex::operator==(MorphemeIndex& _b)
{
	if( m_TokenIndex == _b.m_TokenIndex
		&& m_MAIndex == _b.m_MAIndex
		&& m_MorphemeIndex == _b.m_MorphemeIndex )
		return true;
	return false;
}

void MorphemeIndex::set(MorphemeIndex& _b)
{
	m_TokenIndex = _b.m_TokenIndex;
	m_MAIndex = _b.m_MAIndex;
	m_MorphemeIndex = _b.m_MorphemeIndex;
}

void MorphemeIndex::clear()
{
	m_TokenIndex=0; m_MAIndex=0; m_MorphemeIndex=0;
}