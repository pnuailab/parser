#include "DicCommunicationVerb.h"

DicCommunicationVerb::DicCommunicationVerb(void)
{
}

DicCommunicationVerb::~DicCommunicationVerb(void)
{
}

bool DicCommunicationVerb::loadDic(CString& _Filename)
{
	ifstream fin(_Filename.GetBuffer());

	if( !fin ) return false;

	m_Dic.clear();
	
	const int MaxStrSize = 1024;
	CString strFull;
	char szTemp[MaxStrSize];

	while( !fin.eof() )
	{
		fin >> szTemp;
		strFull = szTemp;
#ifdef LINUX_PORTING

		strFull.Remove('\r');

#endif
		if( strFull == "" ) continue;
		
		m_Dic.insert( strFull );
	}

	return true;
}


#ifdef LINUX_PORTING
bool DicCommunicationVerb::loadDic(char* _Filename)
{
	ifstream fin(_Filename);

	if (!fin) return false;

	m_Dic.clear();

	const int MaxStrSize = 1024;
	CString strFull;
	char szTemp[MaxStrSize];

	while (!fin.eof())
	{
		fin >> szTemp;
		strFull = szTemp;
#ifdef LINUX_PORTING

		strFull.Remove('\r');

#endif
		if (strFull == "") continue;

		m_Dic.insert(strFull);
	}

	return true;
}
#endif

bool DicCommunicationVerb::isCommunicationVerb(CString& _verb)
{
	set<CString>::iterator itDic;

	itDic = m_Dic.find( _verb );

	if( itDic == m_Dic.end() ) return false;
	else return true;
}