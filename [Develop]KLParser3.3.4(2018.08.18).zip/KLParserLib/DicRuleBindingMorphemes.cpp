#include "DicRuleBindingMorphemes.h"

DicRuleBindingMorphemes::DicRuleBindingMorphemes(ElementList *_ElementList)
{
	m_ElementList = _ElementList;
	m_Dic = NULL;
}

DicRuleBindingMorphemes::~DicRuleBindingMorphemes(void)
{
}

bool DicRuleBindingMorphemes::loadDic(char* _szFilename)	// ���Ϸκ��� ������ �о�´�.
{
	if( !_szFilename ) return false;

	ifstream fin(_szFilename);
	if( !fin ) return false;

	freeMemory();

	m_Dic = new vector<RuleBindingMorphemes*>;

	const int MAX_LENGTH_LINE = 1024;
	char szLineBuffer[MAX_LENGTH_LINE];
	CString strLineBuffer, strLineWithComment;
	int nStartComment = 0;	// �ּ� ���� ��ȣ

	while( !fin.eof() )
	{
		fin.getline( szLineBuffer, MAX_LENGTH_LINE );
		strLineWithComment = szLineBuffer;
#ifdef LINUX_PORTING

		strLineWithComment.Remove('\r');

#endif
		if( strLineWithComment == "" ) continue;

		
		// "//" ��ȣ�� �޺κ��� ������
		nStartComment = strLineWithComment.Find("//");
		if( nStartComment >= 0 )
			strLineBuffer = strLineWithComment.GetBufferSetLength(nStartComment);
		else
			strLineBuffer = strLineWithComment;
		
		if( strLineBuffer == "" ) continue;

		RuleBindingMorphemes *rbm = new RuleBindingMorphemes(m_ElementList);

		rbm->setRule(strLineBuffer);

		m_Dic->push_back( rbm );
	}

	fin.close();

	return true;
}

void DicRuleBindingMorphemes::freeMemory()					// �����Ҵ�� �޸𸮸� ����
{
	if( m_Dic )
	{
		for(unsigned int i=0; i<m_Dic->size(); i++)	// 2016.10.16. (int �� unsigned int) : Ryu
		{
			if( m_Dic->at(i) )
			{
				m_Dic->at(i)->freeMemory();
				if(m_Dic->at(i))
					delete m_Dic->at(i);
			}
		}

		m_Dic->clear();
		if(m_Dic)
			delete m_Dic;
	}
}

// Ŭ������ �ν��Ͻ��� ���� ������ �ʱ�ȭ
void DicRuleBindingMorphemes::init()
{
	freeMemory();
	m_Dic = new vector<RuleBindingMorphemes*>;
}