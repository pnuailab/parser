#include "RuleSubCondition.h"

RuleSubCondition::RuleSubCondition(void)
{
	m_GovConditionList = new vector<ConditionElement*>;
	m_DepConditionList = new vector<ConditionElement*>;

	m_Rule = 0;
	m_isExceptionRule = true;
}

RuleSubCondition::~RuleSubCondition(void)
{
}

void RuleSubCondition::freeMemory()
{
	unsigned int i;	// (int �� unsigned) : 161016 : �����

	for( i=0; i<m_GovConditionList->size(); i++ )
	{
		m_GovConditionList->at(i)->freeMemory();
		if(m_GovConditionList->at(i))
			delete m_GovConditionList->at(i);
	}
	delete m_GovConditionList;

	for( i=0; i<m_DepConditionList->size(); i++ )
	{
		m_DepConditionList->at(i)->freeMemory();
		if(m_DepConditionList->at(i))
			delete m_DepConditionList->at(i);
	}
	if(m_DepConditionList)
		delete m_DepConditionList;
}