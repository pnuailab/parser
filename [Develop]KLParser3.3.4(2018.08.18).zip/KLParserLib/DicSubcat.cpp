#include "DicSubcat.h"
#include <fstream>

using namespace std;

// Constructor
DicSubcat::DicSubcat(void)
{
	m_Subcat = new vector<Subcat*>;
}

// Destructor
DicSubcat::~DicSubcat(void)
{

}

// ���Ϸκ��� ������ �о�´�
bool DicSubcat::loadDicFromFile(char* _szFilename)
{
	// ��ο� ������ �������� ������ false
	if (!_szFilename) return false;

	// ���Ͽ���, ���� �� false
	ifstream fin(_szFilename);
	if (!fin) return false;

	freeMemory();
	Subcat* Subcat_;

	const int MAX_LENGTH_LINE = 1024;
	char szLineBuffer[MAX_LENGTH_LINE];
	CString strLineBuffer, strLineWithComment;
	int nStartComment = 0;
	vector<CString> strLineBufferList;

	CString prev_verb = "";

	while (!fin.eof())
	{
		// �� ���� �б�
		fin.getline(szLineBuffer, MAX_LENGTH_LINE);
		strLineWithComment = szLineBuffer;
#ifdef LINUX_PORTING

		strLineWithComment.Remove('\r');

#endif
		if (strLineWithComment == "")
		{
			if (prev_verb != strLineBufferList.at(0))
			{
				prev_verb = strLineBufferList.at(0);
				Subcat_ = new Subcat;
				Subcat_->setSubcat(strLineBufferList);
				m_Subcat->push_back(Subcat_);
				strLineBufferList.clear();
			}
			else
			{
				m_Subcat->at(m_Subcat->size() - 1)->setSubcat(strLineBufferList);
				strLineBufferList.clear();
			}
		}

		nStartComment = strLineWithComment.Find("//");
		if (nStartComment >= 0)
			strLineBuffer = strLineWithComment.GetBufferSetLength(nStartComment);
		else
			strLineBuffer = strLineWithComment;

		if (strLineBuffer == "") continue;

		strLineBufferList.push_back(strLineBuffer);
	}

	return true;
}


// �Ҵ�� ���� �޸𸮸� ����
void DicSubcat::freeMemory()
{
	/*if (&m_Subcat)
	{
		for (unsigned int i = 0; i < m_Subcat->size(); i++)
		{
			if (m_Subcat->at(i))
			{
				delete m_Subcat->at(i);
			}
		}
		m_Subcat->clear();
		if (m_Subcat)
			delete m_Subcat;
	}*/
}


// Ŭ������ �ν��Ͻ��� ����� ������ �ʱ�ȭ�Ѵ�.
void DicSubcat::init()
{
	freeMemory();
	//m_Subcat = new vector<Subcat*>;
}