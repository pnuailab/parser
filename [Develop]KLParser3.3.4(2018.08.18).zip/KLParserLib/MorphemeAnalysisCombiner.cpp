#ifdef LINUX_PORTING
#include "MorphemeAnalysisCombiner.h"
#else
#include ".\MorphemeAnalysisCombiner.h"
#endif

MorphemeAnalysisCombiner::MorphemeAnalysisCombiner(TagString &tagString)
{
	m_nNumOfCombination = 0;
	int temp;
	for( int i=0; i<tagString.GetSize(); i++ )
	{
		if( i==0 ) m_nNumOfCombination = 1;
		temp = tagString.GetToken(i)->NumOfMA;
		m_NumOfMorphemeAnalysis.push_back( temp );
		m_IndexOfMorphemeAnalysis.push_back( 0 );
		m_nNumOfCombination *= temp;
	}
}

MorphemeAnalysisCombiner::~MorphemeAnalysisCombiner(void)
{
	m_IndexOfMorphemeAnalysis.clear();
	m_NumOfMorphemeAnalysis.clear();
}

int MorphemeAnalysisCombiner::GetTotalNumOfCombination()
{
	return m_nNumOfCombination;
}

void MorphemeAnalysisCombiner::InitCombinationIndex()
{	
	for( unsigned int i=0; i<m_IndexOfMorphemeAnalysis.size(); i++ )
	{
		m_IndexOfMorphemeAnalysis[i] = 1;
	}
}

void MorphemeAnalysisCombiner::SetNextIndex(int depth)
{
	if( depth < 0 ) return;

	m_IndexOfMorphemeAnalysis[depth]++;

	if( m_IndexOfMorphemeAnalysis[depth] >= m_NumOfMorphemeAnalysis[depth] )
	{
		m_IndexOfMorphemeAnalysis[depth] = 0;
		SetNextIndex( depth-1 );
	}
}


void MorphemeAnalysisCombiner::GetNextCombination(TagString &TagResult, TagString &NextCombination)
{
	NextCombination.clear();
	for( int i=0; i<TagResult.GetSize(); i++ )
	{
		NextCombination.AttachTailToken();
		CopyTokenInformation( TagResult.GetToken(i), m_IndexOfMorphemeAnalysis[i], NextCombination.GetToken(i) );
		
	}
	SetNextIndex( TagResult.GetSize()-1 );
}

void MorphemeAnalysisCombiner::GetCurrentIndex(vector<int> &out_IndexOfMorphemeAnalysis)
{
	out_IndexOfMorphemeAnalysis.clear();

	for( unsigned int i=0; i<m_IndexOfMorphemeAnalysis.size(); i++ )
	{
		out_IndexOfMorphemeAnalysis.push_back( m_IndexOfMorphemeAnalysis[i] );
	}
}

void MorphemeAnalysisCombiner::GetCombination(vector<int> &in_IndexOfMorphemeAnalysis, TagString &in_TagResult, TagString &out_Combination)
{	
	out_Combination.clear();
	for( int i=0; i<in_TagResult.GetSize(); i++ )
	{
		out_Combination.AttachTailToken();
		CopyTokenInformation( in_TagResult.GetToken(i), in_IndexOfMorphemeAnalysis[i], out_Combination.GetToken(i) );
	}	
}	

void MorphemeAnalysisCombiner::CopyTokenInformation(Token *in_Token, int in_IndexOfMorphemeAnalysis, Token *out_Token)
{
	/* ��ū�� ���� ���� */
#ifdef LINUX_PORTING
	strcpy(out_Token->Str, in_Token->Str);	// ���� token(����)�� ����
#else
	strcpy_s(out_Token->Str, in_Token->Str);	// ���� token(����)�� ����
#endif
	out_Token->MALists[0].Set(in_Token->MALists[ in_IndexOfMorphemeAnalysis ]);	// MAList�� ����.
	out_Token->NumOfMA = 1;									// NumOfMa�� ����
	out_Token->Rank[0] = &(out_Token->MALists[0]);	// Rank�� ���� ó������ ����
	// �� �� ��� ������
	out_Token->TokenFlags = in_Token->TokenFlags;
	out_Token->_printInfo = in_Token->_printInfo;
	out_Token->bCompoundNoun = in_Token->bCompoundNoun;
	out_Token->boundary = in_Token->boundary;
//	out_Token->sub = in_Token->sub;
}

MorphemeAnalysisCombiner::MorphemeAnalysisCombiner(ParseString& _ParseString)
{
	m_nNumOfCombination = 0;
	int temp;
	for( int i=0; i<_ParseString.m_ListOfParseToken->size(); i++ )
	{
		if( i==0 ) m_nNumOfCombination = 1;
		temp = _ParseString.m_ListOfParseToken->at(i)->m_ListOfPMList->size();
		m_NumOfMorphemeAnalysis.push_back( temp );
		m_IndexOfMorphemeAnalysis.push_back( 0 );
		m_nNumOfCombination *= temp;
	}
}

void MorphemeAnalysisCombiner::GetNextCombination(ParseString& _ParseString, ParsingMorphemeList& _PMList)
{
	_PMList.clear();
	int i, j;
	for( i=0; i<_ParseString.m_ListOfParseToken->size(); i++ )
	{
		//CopyTokenInformation( TagResult.GetToken(i), m_IndexOfMorphemeAnalysis[i], NextCombination.GetToken(i) );
		for( j=0; j<_ParseString.m_ListOfParseToken->at(i)->m_ListOfPMList->at(m_IndexOfMorphemeAnalysis[i])->m_PMList->size(); j++ )
		{
			_PMList.m_PMList->push_back( _ParseString.m_ListOfParseToken->at(i)->m_ListOfPMList->at(m_IndexOfMorphemeAnalysis[i])->m_PMList->at(j) );

			

		}
	}

	SetNextIndex( _ParseString.m_ListOfParseToken->size()-1 );
}