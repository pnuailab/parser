#include "FrameElement.h"


using namespace std;

void FrameElement::setFrameElement(CString _frameToken)
{
	// CString Ÿ���� ������ �޾ƿ� string Ÿ������ ��ȯ
	// CString Ÿ������ ���ڿ� ��ūȭ�� ����..
#ifdef LINUX_PORTING

	const char* frameToken_ch = _frameToken;

	string frameToken = frameToken_ch;

#else

	string frameToken = _frameToken;

#endif
	//CT2CA(_frameToken.operator LPCWSTR());

	string semArg = "";	// �ǹ̳��� (ex. X, Y, Z...)
	string synArg = "";	// ������ (ex. N0, N1...)
	string josa = "";
	string tmp = "";	// Tokenize�� ���� temporary ����

	int pos = 0;	// tokenize�� ã�� ���ڿ��� ��ġ
	int pos2 = 0;	// tokenize�� ã�� ���ڿ��� ��ġ

	// �ǹ̳��� ����
	semArg = frameToken;
	if ((pos = semArg.find("����:")) != string::npos)
	{
		// front tokenize
		semArg.erase(0, 5);
		if ((pos = semArg.find("=")) != string::npos)
		{
			// rear tokenize
			semArg.erase(pos, semArg.length() - pos);
#ifdef LINUX_PORTING

			strncpy(m_szSemanticArg, semArg.c_str(), MAX_SEMARG_LEN);

#else

			strcpy_s(m_szSemanticArg, MAX_SEMARG_LEN, semArg.c_str());

#endif
		}
		else
		{
			if ((pos = semArg.find("-")) != string::npos)
			{
				// rear tokenize
				semArg.erase(pos, semArg.length() - pos);
#ifdef LINUX_PORTING

				strncpy(m_szSemanticArg, semArg.c_str(), MAX_SEMARG_LEN);

#else

				strcpy_s(m_szSemanticArg, MAX_SEMARG_LEN, semArg.c_str());

#endif
			}
		}
	}
	else
	{
		if ((pos = semArg.find("=")) != string::npos)
		{
			// rear tokenize
			semArg.erase(pos, semArg.length() - pos);
#ifdef LINUX_PORTING

			strncpy(m_szSemanticArg, semArg.c_str(), MAX_SEMARG_LEN);

#else

			strcpy_s(m_szSemanticArg, MAX_SEMARG_LEN, semArg.c_str());

#endif
		}
		else
		{
			if ((pos = semArg.find("-")) != string::npos)
			{
				// rear tokenize
				semArg.erase(pos, semArg.length() - pos);
#ifdef LINUX_PORTING

				strncpy(m_szSemanticArg, semArg.c_str(), MAX_SEMARG_LEN);

#else

				strcpy_s(m_szSemanticArg, MAX_SEMARG_LEN, semArg.c_str());

#endif
			}
		}
	}

	// ������ ����
	synArg = frameToken;
	if ((pos = synArg.find("=")) != string::npos)
	{
		// front tokenize
		synArg.erase(0, pos + 1);
		if ((pos = synArg.find("-")) != string::npos)
		{
			// rear tokenize
			synArg.erase(pos, synArg.length() - pos);
			tmp = synArg;
			while ((pos = synArg.find(124)) != string::npos)
			{
				char* inputToken = new char[MAX_SYNARG_LEN];

				synArg.erase(pos, synArg.length() - pos);
				tmp.erase(0, pos + 1);
				
#ifdef LINUX_PORTING

				strncpy(inputToken, synArg.c_str(), MAX_SYNARG_LEN);

#else

				strcpy_s(inputToken, MAX_SYNARG_LEN, synArg.c_str());

#endif
				m_szSyntacticArg.push_back(inputToken);
				synArg = tmp;
			}
			char* inputToken = new char[MAX_SYNARG_LEN];
#ifdef LINUX_PORTING

			strncpy(inputToken, synArg.c_str(), MAX_SYNARG_LEN);

#else

			strcpy_s(inputToken, MAX_SYNARG_LEN, synArg.c_str());

#endif
			m_szSyntacticArg.push_back(inputToken);
		}
		else
		{
			if ((pos = synArg.find(" ")) != string::npos)
			{
				tmp = synArg;
				while ((pos = synArg.find("|") != string::npos))
				{
					char* inputToken = new char[MAX_SYNARG_LEN];

					synArg.erase(pos, synArg.length() - pos);
					tmp.erase(0, pos + 1);

#ifdef LINUX_PORTING

					strncpy(inputToken, synArg.c_str(), MAX_SYNARG_LEN);

#else

					strcpy_s(inputToken, MAX_SYNARG_LEN, synArg.c_str());

#endif
					m_szSyntacticArg.push_back(inputToken);
					synArg = tmp;
				}
				char* inputToken = new char[MAX_SYNARG_LEN];
#ifdef LINUX_PORTING

				strncpy(inputToken, synArg.c_str(), MAX_SYNARG_LEN);

#else

				strcpy_s(inputToken, MAX_SYNARG_LEN, synArg.c_str());

#endif
				m_szSyntacticArg.push_back(inputToken);
			}
		}
	}
	else
	{
		synArg = "";
	}

	// �������� ����
	josa = frameToken;
	if ((pos = josa.find("-")) != string::npos)
	{
		// front tokenize
		josa.erase(0, pos + 1);
		tmp = josa;
		while ((pos = josa.find("|")) != string::npos)
		{			
			char* inputToken = new char[MAX_JOSA_LEN];

			josa.erase(pos, josa.length() - pos);
			tmp.erase(0, pos + 1);
#ifdef LINUX_PORTING

			strncpy(inputToken, josa.c_str(), MAX_JOSA_LEN);

#else

			strcpy_s(inputToken, MAX_JOSA_LEN, josa.c_str());

#endif
			m_szJosaList.push_back(inputToken);
			josa = tmp;
		}
		char* inputToken = new char[MAX_JOSA_LEN];
#ifdef LINUX_PORTING

		strncpy(inputToken, josa.c_str(), MAX_JOSA_LEN);

#else

		strcpy_s(inputToken, MAX_JOSA_LEN, josa.c_str());

#endif
		m_szJosaList.push_back(inputToken);
	}
	else
	{
		josa = "";
	}
}

/*	�ǹ̳��� ���� */
char* FrameElement::getSemanticArg()
{
	return m_szSemanticArg;
}

void FrameElement::setSelRst(string _semArg, string _mr, string _content, int _type)
{
	SelectionRestriction* SR = new SelectionRestriction;
	SR->setSemanticArg(_semArg);
	SR->setMeaningRole(_mr);
	SR->setSelectionRestriction(_content, _type);
	m_SelectionRestrictionList.push_back(SR);
}

FrameElement::FrameElement()
{

}

FrameElement::~FrameElement()
{

}