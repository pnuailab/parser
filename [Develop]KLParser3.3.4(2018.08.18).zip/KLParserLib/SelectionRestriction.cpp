#include "SelectionRestriction.h"

using namespace std;

void SelectionRestriction::setSemanticArg(string _semanticArgument)
{
#ifdef LINUX_PORTING
	strncpy(m_szArgument, _semanticArgument.c_str(), MAX_SEMARG_LEN);
#else
	strcpy_s(m_szArgument, MAX_SEMARG_LEN, _semanticArgument.c_str());
#endif
}

void SelectionRestriction::setMeaningRole(string _meaningRole)
{
#ifdef LINUX_PORTING
	strncpy(m_szMeaningRole, _meaningRole.c_str(), MAX_MEANINGROLE_LEN);
#else
	strcpy_s(m_szMeaningRole, MAX_MEANINGROLE_LEN, _meaningRole.c_str());
#endif
}

void SelectionRestriction::setSelectionRestriction(string _content, int _type)
{
	// ������������
	if (_type == 1)
	{
		ConceptWord* CW = new ConceptWord;

		string content = _content;

		int pos_bracket = 0;	// ��ȣ ��ġ
		int pos_bar = 0;	// �� ��ġ

		string tmp = "";	// tokenize�� ���� temporary ����

		while (1)
		{
			// ��ȣ �ִ� case
			tmp = content;
			if ((pos_bracket = content.find(")")) != string::npos)
			{
				if ((pos_bar = content.find("|")) != string::npos)
				{
					if (pos_bracket > pos_bar)
					{
						content.erase(pos_bracket + 1, content.length() - pos_bracket - 1);
						tmp.erase(0, pos_bracket + 2);
						CW->setCW(content);
					}
					else
					{
						content.erase(pos_bar, content.length() - pos_bar);
						tmp.erase(0, pos_bar + 1);
						CW->setCW(content);
					}
					content = tmp;
				}
				else
				{
					CW->setCW(content);
					break;
				}
			}
			// ��ȣ ���� case
			else
			{
				tmp = content;
				while ((pos_bar = content.find("|")) != string::npos)
				{
					content.erase(pos_bar, content.length() - pos_bar);
					tmp.erase(0, pos_bar + 1);
					CW->setCW(content);
					content = tmp;
				}
				CW->setCW(content);
				break;
			}
		}


		if (!CW->isEmpty())
		{
			m_ConceptWordList.push_back(CW);
		}
	}




	// ��������
	else if (_type == 2)
	{
		string content = _content;
		int pos_bar = 0;	// �� ��ġ
		string tmp = "";	// tokenize�� ���� temporary ����

		tmp = content;
		while ((pos_bar = content.find("|")) != string::npos)
		{
			char* inputWord = new char[MAX_MORP_LEN];
			content.erase(pos_bar, content.length() - pos_bar);
			tmp.erase(0, pos_bar + 1);
#ifdef LINUX_PORTING
			strncpy(inputWord, content.c_str(), MAX_MORP_LEN);
#else
			strcpy_s(inputWord, MAX_MORP_LEN, content.c_str());
#endif
			m_szTargetWordList.push_back(inputWord);
		}
		char* inputWord = new char[MAX_MORP_LEN];
#ifdef LINUX_PORTING
		strncpy(inputWord, content.c_str(), MAX_MORP_LEN);
#else
		strcpy_s(inputWord, MAX_MORP_LEN, content.c_str());
#endif
		m_szTargetWordList.push_back(inputWord);
	}

}

SelectionRestriction::SelectionRestriction()
{

}

SelectionRestriction::~SelectionRestriction()
{

}