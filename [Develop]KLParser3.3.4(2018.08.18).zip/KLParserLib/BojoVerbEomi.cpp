#include "BojoVerbEomi.h"


BojoVerbEomi::BojoVerbEomi(ElementList* _PCList)
{
	m_PCList = _PCList;
	m_Dic.clear();
}

BojoVerbEomi::~BojoVerbEomi(void)
{
}

bool BojoVerbEomi::loadDic(CString& _Filename)
{
	if( !m_PCList ) return false;

	ifstream fin( _Filename.GetBuffer() );

	if( !fin ) return false;

	int curPos1, curPos2;
	int startComment;
	char szLineBuffer[255];
	CString strLineWithComment;
	CString strLine;
	CString BojoVerb;
	CString EomiList;
	CString Eomi;

	while( !fin.eof() )
	{
		curPos1 = 0;

		fin.getline( szLineBuffer, 255 );
		strLineWithComment = szLineBuffer;
#ifdef LiNUX_PORTING
		strLineWithComment.Remove('\r');
#endif

		// "//" ��ȣ�� �޺κ��� ������
		startComment = strLineWithComment.Find("//");
		if( startComment >= 0 )
			strLine = strLineWithComment.GetBufferSetLength(startComment);
		else
			strLine = strLineWithComment;
		if( strLine == "" ) continue;

		// ��������� ����
		BojoVerb = strLine.Tokenize(":", curPos1);
		if( BojoVerb == "" ) continue;
		
		// ���list�� ����
		EomiList = strLine.Tokenize(":", curPos1);
		if( EomiList == "" ) continue;

		// ���list���� �� ��̵��� ����, ������ �߰��Ѵ�.
		curPos2 = 0;
		Eomi = "";
		while(1)
		{
			Eomi = EomiList.Tokenize(",", curPos2);
			if( Eomi == "" ) break;

			m_Dic.insert( MapType( BojoVerb, Eomi ) );
		}

	}

	return true;
}
#ifdef LINUX_PORTING
bool BojoVerbEomi::loadDic(char* _Filename)
{
	if (!m_PCList) return false;

	ifstream fin(_Filename);

	if (!fin) return false;

	int curPos1, curPos2;
	int startComment;
	char szLineBuffer[255];
	CString strLineWithComment;
	CString strLine;
	CString BojoVerb;
	CString EomiList;
	CString Eomi;

	while (!fin.eof())
	{
		curPos1 = 0;

		fin.getline(szLineBuffer, 255);
		strLineWithComment = szLineBuffer;
#ifdef LINUX_PORTING
		strLineWithComment.Remove('\r');
#endif

		// "//" ��ȣ�� �޺κ��� ������
		startComment = strLineWithComment.Find("//");
		if (startComment >= 0)
			strLine = strLineWithComment.GetBufferSetLength(startComment);
		else
			strLine = strLineWithComment;
		if (strLine == "") continue;

		// ��������� ����
		BojoVerb = strLine.Tokenize(":", curPos1);
		if (BojoVerb == "") continue;

		// ���list�� ����
		EomiList = strLine.Tokenize(":", curPos1);
		if (EomiList == "") continue;

		// ���list���� �� ��̵��� ����, ������ �߰��Ѵ�.
		curPos2 = 0;
		Eomi = "";
		while (1)
		{
			Eomi = EomiList.Tokenize(",", curPos2);
			if (Eomi == "") break;

			m_Dic.insert(MapType(BojoVerb, Eomi));
		}

	}

	return true;
}
#endif


bool BojoVerbEomi::isHarmonicBojoVerbAndEomi(CString& _BojoVerb, Element* _EomiCategory, CString& _Eomi)
{
	multimap<CString, CString>::iterator itLow, itUpper;
	itLow = m_Dic.lower_bound(_BojoVerb);
	itUpper = m_Dic.upper_bound(_BojoVerb);
	CString EomiCategory = "&";
	EomiCategory.Append(_EomiCategory->m_szElementName);

	if( itLow == m_Dic.end() ) return true;	// ������� ���� ������ ����

	while(1)
	{
		if( itLow == itUpper ) break;
		if( itLow->second == _Eomi || itLow->second == EomiCategory ) return true;	// ���� �� �߰�
		itLow++;
	}

	return false;
}