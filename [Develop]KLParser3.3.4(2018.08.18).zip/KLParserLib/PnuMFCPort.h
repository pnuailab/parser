#ifndef __MFCPORT_H
#define	__MFCPORT_H


///////////////////////////////////////////////////////////////////////////
// MFC Porting\C0\BB \C0\A7\C7\D1 header

#define AFX_CDECL
#define AFXAPI	 
#define PASCAL	 
#define FASTCALL	 
#define AFX_DATA	
#define AFX_DATADEF		
#define AFX_STATIC_DATA	static
//#define AFX_COMDAT __declspec(selectany)
#define AFX_COMDAT	 
#define AFX_INLINE	inline
#define _AFX_INLINE	inline

#ifdef _DEBUG
#define ASSERT	assert
#else
#define ASSERT(f)	((void)0)
#endif

#define WCE_FCTN(fctn) fctn
#define WCE_IF(wce,base) base
#define WCE_DEL /##/

struct __POSITION { int unused; };
typedef __POSITION* POSITION;

#define BEFORE_START_POSITION ((POSITION)-1L)

#define ASSERT_KINDOF(x,y)	((void)0)
#define ASSERT_VALID(x)	((void)0)

#define LOWORD(l)           ((WORD)(l))
#define HIWORD(l)           ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))

#define InterlockedIncrement(x)	(*x = *x+1)
#define InterlockedDecrement(x) (*x = *x-1)

#define CONST	const
typedef void*	LPVOID;
typedef unsigned char	_TUCHAR;
#ifndef  LINUX_PORTING
typedef unsigned long       DWORD;
#endif // ! LINUX_PORTING
typedef int                 BOOL;
#define	TRUE	1
#define FALSE	0
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef float               FLOAT;

typedef int                 INT;
typedef unsigned int        UINT;
typedef unsigned int        *PUINT;

typedef char CHAR;
typedef short SHORT;
typedef long LONG;

typedef CHAR *PCHAR;
typedef CHAR *LPCH, *PCH;

typedef CONST CHAR *LPCCH, *PCCH;
typedef CHAR *NPSTR;
typedef CHAR *LPSTR, *PSTR;
typedef CONST CHAR *LPCSTR, *PCSTR;

typedef char TCHAR, *PTCHAR;
typedef LPSTR LPTCH, PTCH;
typedef LPSTR PTSTR, LPTSTR;
typedef LPCSTR PCTSTR, LPCTSTR;

#define AfxIsValidString(x)	TRUE
#define TRACE	printf
#define TRACE0	printf
#define TRACE1	printf
#define lstrlen(x)	strlen(x)
#define lstrlenA(x)	strlen(x)

#define _tcspbrk(x,y)	strpbrk(x,y)
#define _tcschr(x,y)	strchr(x,y)
#define _tcsupr(x)	strupr(x)
#define _tcslwr(x)	strlwr(x)
#define _tcsrev(x)	strrev(x)

#define _tcscmp(x,y)	strcmp(x,y)
#define _tcsicmp(x,y)	_stricmp(x,y)
#define _tcsstr(x,y)	strstr(x,y)
#define _strinc(_pc)    ((_pc)+1)
#define _tcsinc(_pc)	((_pc)+1)
#define _tclen(x)		mblen(x,1)
#define _ttoi(x)		atoi(x)
#define _istdigit(x)	isdigit(x)
#define _tcsncmp(x,y,z)		strncmp(x,y,z)
#define _tcslen(x)	strlen(x)
#define _stprintf	sprintf
#define _vstprintf	vsprintf

#define _tprintf	printf
#define _T(x)		x
#define TEXT(x)		x
#define	_wfopen fopen
#define wsprintf	printf
#define fwprintf	fprintf
#define fputws		fputs
#define fgetws		fgets

#define Sleep(x)	usleep(x*1000)
//#define AfxBeginThread(x,y)	pthread_create(NULL,NULL,x,y)

#endif


