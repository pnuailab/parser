#pragma once
#include "KLParserLib/Parser.h"
#include <cliext/adapter>
#include <cliext/vector>

using namespace cliext;
using namespace System;
using namespace System::Collections::Generic;


namespace managed_Pasrser {

	public ref class Parser_CLR
	{
	protected:
		Parser* m_parser;

	public:
		Parser_CLR();
		virtual ~Parser_CLR();

		//Load dic �߰�
		void loadDic();
		void loadDLLDic();
		void loadModule();

		//get Parse Tree		
		int getParseTree(String^ _szSentence, bool _isFile, bool spell);		
	};
}